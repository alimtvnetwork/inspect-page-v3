var _=function(Hi){"use strict";var xe=(e=>(e.Ping="Ping",e.RunFullPageExport="RunFullPageExport",e.RunElementExport="RunElementExport",e.EnterPickerMode="EnterPickerMode",e.ExitPickerMode="ExitPickerMode",e.MountFloatingPanel="MountFloatingPanel",e.CollectPageArtifacts="CollectPageArtifacts",e.BeginScrollCapture="BeginScrollCapture",e.RestoreAfterCapture="RestoreAfterCapture",e.CaptureViewport="CaptureViewport",e.OffscreenAddFrame="OffscreenAddFrame",e.OffscreenStitchFinish="OffscreenStitchFinish",e.OffscreenRenderIsolated="OffscreenRenderIsolated",e.OffscreenInit="OffscreenInit",e.OffscreenDispose="OffscreenDispose",e.StatusUpdate="StatusUpdate",e.GetSettings="GetSettings",e.SetSettings="SetSettings",e.GetPanelPosition="GetPanelPosition",e.SetPanelPosition="SetPanelPosition",e.GetShareSettings="GetShareSettings",e.SetShareSettings="SetShareSettings",e.CreateShareSession="CreateShareSession",e.CheckShareAuth="CheckShareAuth",e.OpenLoginPopup="OpenLoginPopup",e.RevokeShareSession="RevokeShareSession",e.CollectInspectSnapshot="CollectInspectSnapshot",e.LocateColor="LocateColor",e))(xe||{}),de=(e=>(e.Idle="Idle",e.Collecting="Collecting",e.Capturing="Capturing",e.Stitching="Stitching",e.Bundling="Bundling",e.Downloading="Downloading",e.PickerActive="PickerActive",e.Selecting="Selecting",e.Success="Success",e.Error="Error",e))(de||{}),ve=(e=>(e.Capture="Capture",e.CssCollect="CssCollect",e.JsCollect="JsCollect",e.HtmlSerialize="HtmlSerialize",e.Picker="Picker",e.Element="Element",e.Stitch="Stitch",e.Zip="Zip",e.Download="Download",e.Messaging="Messaging",e.Offscreen="Offscreen",e.Storage="Storage",e.Settings="Settings",e.Lifecycle="Lifecycle",e.Billing="Billing",e))(ve||{}),Yt=(e=>(e.Debug="Debug",e.Info="Info",e.Warn="Warn",e.Error="Error",e))(Yt||{}),co=(e=>(e.FullPage="FullPage",e.Element="Element",e))(co||{}),ke=(e=>(e.E_HTML_SERIALIZE="E_HTML_SERIALIZE",e.W_CSS_FETCH_FAILED="W_CSS_FETCH_FAILED",e.W_CSS_INLINE_UNREADABLE="W_CSS_INLINE_UNREADABLE",e.W_CSS_PARSE_FAILED="W_CSS_PARSE_FAILED",e.W_JS_FETCH_FAILED="W_JS_FETCH_FAILED",e.E_PAGE_TOO_LARGE="E_PAGE_TOO_LARGE",e.E_CAPTURE_FAILED="E_CAPTURE_FAILED",e.E_SCROLL_TIMEOUT="E_SCROLL_TIMEOUT",e.E_STITCH_FAILED="E_STITCH_FAILED",e.W_STICKY_SCAN_TRUNCATED="W_STICKY_SCAN_TRUNCATED",e.W_ANIMATED_CONTENT="W_ANIMATED_CONTENT",e.E_OFFSCREEN_BUSY="E_OFFSCREEN_BUSY",e.E_ISOLATED_TIMEOUT="E_ISOLATED_TIMEOUT",e.E_ISOLATED_FAILED="E_ISOLATED_FAILED",e.E_ELEMENT_ZERO_SIZE="E_ELEMENT_ZERO_SIZE",e.W_SELECTOR_INVALID="W_SELECTOR_INVALID",e.W_AT_RULE_SKIPPED="W_AT_RULE_SKIPPED",e.W_MD_TRUNCATED="W_MD_TRUNCATED",e.E_ZIP_FAILED="E_ZIP_FAILED",e.E_DOWNLOAD_FAILED="E_DOWNLOAD_FAILED",e.E_COLLECT_TIMEOUT="E_COLLECT_TIMEOUT",e.E_EXPORT_TIMEOUT="E_EXPORT_TIMEOUT",e.E_STORAGE_PARSE="E_STORAGE_PARSE",e.E_NOT_AVAILABLE_HERE="E_NOT_AVAILABLE_HERE",e.E_PERMISSION_DENIED="E_PERMISSION_DENIED",e.E_ROUTE_CHANGED="E_ROUTE_CHANGED",e.E_PANEL_MOUNT_FAILED="E_PANEL_MOUNT_FAILED",e.E_EXPORT_INTERRUPTED="E_EXPORT_INTERRUPTED",e.W_IFRAME_NOT_TRAVERSED="W_IFRAME_NOT_TRAVERSED",e.W_SHADOW_CLOSED="W_SHADOW_CLOSED",e.W_SHADOW_OPEN_SKIPPED="W_SHADOW_OPEN_SKIPPED",e.W_FONT_NOT_BUNDLED="W_FONT_NOT_BUNDLED",e.W_WEB_COMPONENT_SKIPPED="W_WEB_COMPONENT_SKIPPED",e.W_BLANK_PAGE_SUSPECTED="W_BLANK_PAGE_SUSPECTED",e.E_SHARE_AUTH="E_SHARE_AUTH",e.E_SHARE_NETWORK="E_SHARE_NETWORK",e.E_SHARE_UPSTREAM="E_SHARE_UPSTREAM",e.E_SHARE_BAD_INPUT="E_SHARE_BAD_INPUT",e.E_SHARE_QUOTA="E_SHARE_QUOTA",e.E_SHARE_QUOTA_FREE="E_SHARE_QUOTA_FREE",e.E_SHARE_BAD_TOKEN="E_SHARE_BAD_TOKEN",e.E_SHARE_NOT_FOUND="E_SHARE_NOT_FOUND",e.E_IFRAME_CROSS_ORIGIN="E_IFRAME_CROSS_ORIGIN",e.W_FONT_UNREACHABLE="W_FONT_UNREACHABLE",e))(ke||{});const Md=2,Bd=16,$d=250,Wi=5e3,Ud=12,_s=80,Qt=2147483647,Cs=2147483646,Es="inspect-page.share",Hd="[inspect-page]",Ns="",js="https://inspectpage.app",Wd=`${js}/#pricing`,Vd=`${js}/docs`;function uo(e){const t=`${Hd} [${e.level}] [${e.category}]`,n=e.code?`${e.code} ${e.message}`:e.message;if(e.level===Yt.Error){console.error(t,n,e.error??"");return}if(e.level===Yt.Warn){console.warn(t,n,e.error??"");return}if(e.level===Yt.Info){console.info(t,n);return}console.debug(t,n)}const be={debug(e,t){uo({level:Yt.Debug,category:e,message:t})},info(e,t){uo({level:Yt.Info,category:e,message:t})},warn(e,t,n,r){uo({level:Yt.Warn,category:e,code:t,message:n,error:r})},error(e,t,n,r){uo({level:Yt.Error,category:e,code:t,message:n,error:r})}};class He extends Error{constructor(t,n,r){super(n),this.code=t,this.detail=r,this.name="MessageError"}toWire(){return{code:this.code,message:this.message,detail:this.detail}}}function Gd(){const e=globalThis.crypto;return e?.randomUUID?e.randomUUID():`req_${Date.now()}_${Math.random().toString(36).slice(2,10)}`}function Zd(e,t,n=Gd()){return{kind:e,requestId:n,payload:t}}class Yd{constructor(){this.handlers=new Map,this.listener=(t,n,r)=>{if(!Qd(t))return!1;const o=t,i=this.handlers.get(o.kind);return i?(Promise.resolve().then(()=>i(o.payload,n)).then(a=>r({ok:!0,data:a})).catch(a=>{const l=Xd(a);be.error(ve.Messaging,l.code,`${o.kind} failed`,a),r({ok:!1,error:l})}),!0):!1}}on(t,n){this.handlers.has(t)&&be.warn(ve.Messaging,"ROUTER_DUP",`replacing handler ${t}`),this.handlers.set(t,n)}attach(t=chrome.runtime.onMessage){t.addListener(this.listener)}}function Qd(e){if(typeof e!="object"||e===null)return!1;const t=e;return typeof t.kind=="string"&&typeof t.requestId=="string"&&"payload"in t&&Object.values(xe).includes(t.kind)}function Xd(e){if(e instanceof He)return e.toWire();const t=e instanceof Error?e.message:String(e);return{code:ke.E_PERMISSION_DENIED,message:t}}async function Me(e,t){const n=Zd(e,t),r=await chrome.runtime.sendMessage(n);if(!r||r.ok!==!0){const o=r?.error??{code:ke.E_PERMISSION_DENIED,message:"no response"};throw new He(o.code,o.message,o.detail)}return r.data}var po=typeof globalThis<"u"?globalThis:typeof window<"u"?window:typeof global<"u"?global:typeof self<"u"?self:{};function Kd(e){return e&&e.__esModule&&Object.prototype.hasOwnProperty.call(e,"default")?e.default:e}var Fs={exports:{}},fo={},Ts={exports:{}},he={};/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var fr=Symbol.for("react.element"),Jd=Symbol.for("react.portal"),qd=Symbol.for("react.fragment"),ef=Symbol.for("react.strict_mode"),tf=Symbol.for("react.profiler"),nf=Symbol.for("react.provider"),rf=Symbol.for("react.context"),of=Symbol.for("react.forward_ref"),af=Symbol.for("react.suspense"),lf=Symbol.for("react.memo"),sf=Symbol.for("react.lazy"),As=Symbol.iterator;function cf(e){return e===null||typeof e!="object"?null:(e=As&&e[As]||e["@@iterator"],typeof e=="function"?e:null)}var Ps={isMounted:function(){return!1},enqueueForceUpdate:function(){},enqueueReplaceState:function(){},enqueueSetState:function(){}},Is=Object.assign,zs={};function Ln(e,t,n){this.props=e,this.context=t,this.refs=zs,this.updater=n||Ps}Ln.prototype.isReactComponent={},Ln.prototype.setState=function(e,t){if(typeof e!="object"&&typeof e!="function"&&e!=null)throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");this.updater.enqueueSetState(this,e,t,"setState")},Ln.prototype.forceUpdate=function(e){this.updater.enqueueForceUpdate(this,e,"forceUpdate")};function Rs(){}Rs.prototype=Ln.prototype;function Vi(e,t,n){this.props=e,this.context=t,this.refs=zs,this.updater=n||Ps}var Gi=Vi.prototype=new Rs;Gi.constructor=Vi,Is(Gi,Ln.prototype),Gi.isPureReactComponent=!0;var Ls=Array.isArray,Ds=Object.prototype.hasOwnProperty,Zi={current:null},Os={key:!0,ref:!0,__self:!0,__source:!0};function Ms(e,t,n){var r,o={},i=null,a=null;if(t!=null)for(r in t.ref!==void 0&&(a=t.ref),t.key!==void 0&&(i=""+t.key),t)Ds.call(t,r)&&!Os.hasOwnProperty(r)&&(o[r]=t[r]);var l=arguments.length-2;if(l===1)o.children=n;else if(1<l){for(var s=Array(l),u=0;u<l;u++)s[u]=arguments[u+2];o.children=s}if(e&&e.defaultProps)for(r in l=e.defaultProps,l)o[r]===void 0&&(o[r]=l[r]);return{$$typeof:fr,type:e,key:i,ref:a,props:o,_owner:Zi.current}}function uf(e,t){return{$$typeof:fr,type:e.type,key:t,ref:e.ref,props:e.props,_owner:e._owner}}function Yi(e){return typeof e=="object"&&e!==null&&e.$$typeof===fr}function pf(e){var t={"=":"=0",":":"=2"};return"$"+e.replace(/[=:]/g,function(n){return t[n]})}var Bs=/\/+/g;function Qi(e,t){return typeof e=="object"&&e!==null&&e.key!=null?pf(""+e.key):t.toString(36)}function ho(e,t,n,r,o){var i=typeof e;(i==="undefined"||i==="boolean")&&(e=null);var a=!1;if(e===null)a=!0;else switch(i){case"string":case"number":a=!0;break;case"object":switch(e.$$typeof){case fr:case Jd:a=!0}}if(a)return a=e,o=o(a),e=r===""?"."+Qi(a,0):r,Ls(o)?(n="",e!=null&&(n=e.replace(Bs,"$&/")+"/"),ho(o,t,n,"",function(u){return u})):o!=null&&(Yi(o)&&(o=uf(o,n+(!o.key||a&&a.key===o.key?"":(""+o.key).replace(Bs,"$&/")+"/")+e)),t.push(o)),1;if(a=0,r=r===""?".":r+":",Ls(e))for(var l=0;l<e.length;l++){i=e[l];var s=r+Qi(i,l);a+=ho(i,t,n,s,o)}else if(s=cf(e),typeof s=="function")for(e=s.call(e),l=0;!(i=e.next()).done;)i=i.value,s=r+Qi(i,l++),a+=ho(i,t,n,s,o);else if(i==="object")throw t=String(e),Error("Objects are not valid as a React child (found: "+(t==="[object Object]"?"object with keys {"+Object.keys(e).join(", ")+"}":t)+"). If you meant to render a collection of children, use an array instead.");return a}function mo(e,t,n){if(e==null)return e;var r=[],o=0;return ho(e,r,"","",function(i){return t.call(n,i,o++)}),r}function df(e){if(e._status===-1){var t=e._result;t=t(),t.then(function(n){(e._status===0||e._status===-1)&&(e._status=1,e._result=n)},function(n){(e._status===0||e._status===-1)&&(e._status=2,e._result=n)}),e._status===-1&&(e._status=0,e._result=t)}if(e._status===1)return e._result.default;throw e._result}var Ye={current:null},go={transition:null},ff={ReactCurrentDispatcher:Ye,ReactCurrentBatchConfig:go,ReactCurrentOwner:Zi};function $s(){throw Error("act(...) is not supported in production builds of React.")}he.Children={map:mo,forEach:function(e,t,n){mo(e,function(){t.apply(this,arguments)},n)},count:function(e){var t=0;return mo(e,function(){t++}),t},toArray:function(e){return mo(e,function(t){return t})||[]},only:function(e){if(!Yi(e))throw Error("React.Children.only expected to receive a single React element child.");return e}},he.Component=Ln,he.Fragment=qd,he.Profiler=tf,he.PureComponent=Vi,he.StrictMode=ef,he.Suspense=af,he.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=ff,he.act=$s,he.cloneElement=function(e,t,n){if(e==null)throw Error("React.cloneElement(...): The argument must be a React element, but you passed "+e+".");var r=Is({},e.props),o=e.key,i=e.ref,a=e._owner;if(t!=null){if(t.ref!==void 0&&(i=t.ref,a=Zi.current),t.key!==void 0&&(o=""+t.key),e.type&&e.type.defaultProps)var l=e.type.defaultProps;for(s in t)Ds.call(t,s)&&!Os.hasOwnProperty(s)&&(r[s]=t[s]===void 0&&l!==void 0?l[s]:t[s])}var s=arguments.length-2;if(s===1)r.children=n;else if(1<s){l=Array(s);for(var u=0;u<s;u++)l[u]=arguments[u+2];r.children=l}return{$$typeof:fr,type:e.type,key:o,ref:i,props:r,_owner:a}},he.createContext=function(e){return e={$$typeof:rf,_currentValue:e,_currentValue2:e,_threadCount:0,Provider:null,Consumer:null,_defaultValue:null,_globalName:null},e.Provider={$$typeof:nf,_context:e},e.Consumer=e},he.createElement=Ms,he.createFactory=function(e){var t=Ms.bind(null,e);return t.type=e,t},he.createRef=function(){return{current:null}},he.forwardRef=function(e){return{$$typeof:of,render:e}},he.isValidElement=Yi,he.lazy=function(e){return{$$typeof:sf,_payload:{_status:-1,_result:e},_init:df}},he.memo=function(e,t){return{$$typeof:lf,type:e,compare:t===void 0?null:t}},he.startTransition=function(e){var t=go.transition;go.transition={};try{e()}finally{go.transition=t}},he.unstable_act=$s,he.useCallback=function(e,t){return Ye.current.useCallback(e,t)},he.useContext=function(e){return Ye.current.useContext(e)},he.useDebugValue=function(){},he.useDeferredValue=function(e){return Ye.current.useDeferredValue(e)},he.useEffect=function(e,t){return Ye.current.useEffect(e,t)},he.useId=function(){return Ye.current.useId()},he.useImperativeHandle=function(e,t,n){return Ye.current.useImperativeHandle(e,t,n)},he.useInsertionEffect=function(e,t){return Ye.current.useInsertionEffect(e,t)},he.useLayoutEffect=function(e,t){return Ye.current.useLayoutEffect(e,t)},he.useMemo=function(e,t){return Ye.current.useMemo(e,t)},he.useReducer=function(e,t,n){return Ye.current.useReducer(e,t,n)},he.useRef=function(e){return Ye.current.useRef(e)},he.useState=function(e){return Ye.current.useState(e)},he.useSyncExternalStore=function(e,t,n){return Ye.current.useSyncExternalStore(e,t,n)},he.useTransition=function(){return Ye.current.useTransition()},he.version="18.3.1",Ts.exports=he;var G=Ts.exports;/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var hf=G,mf=Symbol.for("react.element"),gf=Symbol.for("react.fragment"),xf=Object.prototype.hasOwnProperty,vf=hf.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,yf={key:!0,ref:!0,__self:!0,__source:!0};function Us(e,t,n){var r,o={},i=null,a=null;n!==void 0&&(i=""+n),t.key!==void 0&&(i=""+t.key),t.ref!==void 0&&(a=t.ref);for(r in t)xf.call(t,r)&&!yf.hasOwnProperty(r)&&(o[r]=t[r]);if(e&&e.defaultProps)for(r in t=e.defaultProps,t)o[r]===void 0&&(o[r]=t[r]);return{$$typeof:mf,type:e,key:i,ref:a,props:o,_owner:vf.current}}fo.Fragment=gf,fo.jsx=Us,fo.jsxs=Us,Fs.exports=fo;var c=Fs.exports,Hs={exports:{}},ot={},Ws={exports:{}},Vs={};/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */(function(e){function t(Z,$){var O=Z.length;Z.push($);e:for(;0<O;){var P=O-1>>>1,I=Z[P];if(0<o(I,$))Z[P]=$,Z[O]=I,O=P;else break e}}function n(Z){return Z.length===0?null:Z[0]}function r(Z){if(Z.length===0)return null;var $=Z[0],O=Z.pop();if(O!==$){Z[0]=O;e:for(var P=0,I=Z.length,re=I>>>1;P<re;){var te=2*(P+1)-1,J=Z[te],fe=te+1,ee=Z[fe];if(0>o(J,O))fe<I&&0>o(ee,J)?(Z[P]=ee,Z[fe]=O,P=fe):(Z[P]=J,Z[te]=O,P=te);else if(fe<I&&0>o(ee,O))Z[P]=ee,Z[fe]=O,P=fe;else break e}}return $}function o(Z,$){var O=Z.sortIndex-$.sortIndex;return O!==0?O:Z.id-$.id}if(typeof performance=="object"&&typeof performance.now=="function"){var i=performance;e.unstable_now=function(){return i.now()}}else{var a=Date,l=a.now();e.unstable_now=function(){return a.now()-l}}var s=[],u=[],y=1,x=null,w=3,h=!1,b=!1,f=!1,v=typeof setTimeout=="function"?setTimeout:null,p=typeof clearTimeout=="function"?clearTimeout:null,d=typeof setImmediate<"u"?setImmediate:null;typeof navigator<"u"&&navigator.scheduling!==void 0&&navigator.scheduling.isInputPending!==void 0&&navigator.scheduling.isInputPending.bind(navigator.scheduling);function g(Z){for(var $=n(u);$!==null;){if($.callback===null)r(u);else if($.startTime<=Z)r(u),$.sortIndex=$.expirationTime,t(s,$);else break;$=n(u)}}function S(Z){if(f=!1,g(Z),!b)if(n(s)!==null)b=!0,ce(C);else{var $=n(u);$!==null&&Q(S,$.startTime-Z)}}function C(Z,$){b=!1,f&&(f=!1,p(R),R=-1),h=!0;var O=w;try{for(g($),x=n(s);x!==null&&(!(x.expirationTime>$)||Z&&!ie());){var P=x.callback;if(typeof P=="function"){x.callback=null,w=x.priorityLevel;var I=P(x.expirationTime<=$);$=e.unstable_now(),typeof I=="function"?x.callback=I:x===n(s)&&r(s),g($)}else r(s);x=n(s)}if(x!==null)var re=!0;else{var te=n(u);te!==null&&Q(S,te.startTime-$),re=!1}return re}finally{x=null,w=O,h=!1}}var A=!1,T=null,R=-1,L=5,M=-1;function ie(){return!(e.unstable_now()-M<L)}function F(){if(T!==null){var Z=e.unstable_now();M=Z;var $=!0;try{$=T(!0,Z)}finally{$?B():(A=!1,T=null)}}else A=!1}var B;if(typeof d=="function")B=function(){d(F)};else if(typeof MessageChannel<"u"){var k=new MessageChannel,H=k.port2;k.port1.onmessage=F,B=function(){H.postMessage(null)}}else B=function(){v(F,0)};function ce(Z){T=Z,A||(A=!0,B())}function Q(Z,$){R=v(function(){Z(e.unstable_now())},$)}e.unstable_IdlePriority=5,e.unstable_ImmediatePriority=1,e.unstable_LowPriority=4,e.unstable_NormalPriority=3,e.unstable_Profiling=null,e.unstable_UserBlockingPriority=2,e.unstable_cancelCallback=function(Z){Z.callback=null},e.unstable_continueExecution=function(){b||h||(b=!0,ce(C))},e.unstable_forceFrameRate=function(Z){0>Z||125<Z?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):L=0<Z?Math.floor(1e3/Z):5},e.unstable_getCurrentPriorityLevel=function(){return w},e.unstable_getFirstCallbackNode=function(){return n(s)},e.unstable_next=function(Z){switch(w){case 1:case 2:case 3:var $=3;break;default:$=w}var O=w;w=$;try{return Z()}finally{w=O}},e.unstable_pauseExecution=function(){},e.unstable_requestPaint=function(){},e.unstable_runWithPriority=function(Z,$){switch(Z){case 1:case 2:case 3:case 4:case 5:break;default:Z=3}var O=w;w=Z;try{return $()}finally{w=O}},e.unstable_scheduleCallback=function(Z,$,O){var P=e.unstable_now();switch(typeof O=="object"&&O!==null?(O=O.delay,O=typeof O=="number"&&0<O?P+O:P):O=P,Z){case 1:var I=-1;break;case 2:I=250;break;case 5:I=1073741823;break;case 4:I=1e4;break;default:I=5e3}return I=O+I,Z={id:y++,callback:$,priorityLevel:Z,startTime:O,expirationTime:I,sortIndex:-1},O>P?(Z.sortIndex=O,t(u,Z),n(s)===null&&Z===n(u)&&(f?(p(R),R=-1):f=!0,Q(S,O-P))):(Z.sortIndex=I,t(s,Z),b||h||(b=!0,ce(C))),Z},e.unstable_shouldYield=ie,e.unstable_wrapCallback=function(Z){var $=w;return function(){var O=w;w=$;try{return Z.apply(this,arguments)}finally{w=O}}}})(Vs),Ws.exports=Vs;var bf=Ws.exports;/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var wf=G,it=bf;function K(e){for(var t="https://reactjs.org/docs/error-decoder.html?invariant="+e,n=1;n<arguments.length;n++)t+="&args[]="+encodeURIComponent(arguments[n]);return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."}var Gs=new Set,hr={};function wn(e,t){Dn(e,t),Dn(e+"Capture",t)}function Dn(e,t){for(hr[e]=t,e=0;e<t.length;e++)Gs.add(t[e])}var Lt=!(typeof window>"u"||typeof window.document>"u"||typeof window.document.createElement>"u"),Xi=Object.prototype.hasOwnProperty,kf=/^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,Zs={},Ys={};function Sf(e){return Xi.call(Ys,e)?!0:Xi.call(Zs,e)?!1:kf.test(e)?Ys[e]=!0:(Zs[e]=!0,!1)}function _f(e,t,n,r){if(n!==null&&n.type===0)return!1;switch(typeof t){case"function":case"symbol":return!0;case"boolean":return r?!1:n!==null?!n.acceptsBooleans:(e=e.toLowerCase().slice(0,5),e!=="data-"&&e!=="aria-");default:return!1}}function Cf(e,t,n,r){if(t===null||typeof t>"u"||_f(e,t,n,r))return!0;if(r)return!1;if(n!==null)switch(n.type){case 3:return!t;case 4:return t===!1;case 5:return isNaN(t);case 6:return isNaN(t)||1>t}return!1}function Qe(e,t,n,r,o,i,a){this.acceptsBooleans=t===2||t===3||t===4,this.attributeName=r,this.attributeNamespace=o,this.mustUseProperty=n,this.propertyName=e,this.type=t,this.sanitizeURL=i,this.removeEmptyString=a}var Be={};"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(e){Be[e]=new Qe(e,0,!1,e,null,!1,!1)}),[["acceptCharset","accept-charset"],["className","class"],["htmlFor","for"],["httpEquiv","http-equiv"]].forEach(function(e){var t=e[0];Be[t]=new Qe(t,1,!1,e[1],null,!1,!1)}),["contentEditable","draggable","spellCheck","value"].forEach(function(e){Be[e]=new Qe(e,2,!1,e.toLowerCase(),null,!1,!1)}),["autoReverse","externalResourcesRequired","focusable","preserveAlpha"].forEach(function(e){Be[e]=new Qe(e,2,!1,e,null,!1,!1)}),"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(e){Be[e]=new Qe(e,3,!1,e.toLowerCase(),null,!1,!1)}),["checked","multiple","muted","selected"].forEach(function(e){Be[e]=new Qe(e,3,!0,e,null,!1,!1)}),["capture","download"].forEach(function(e){Be[e]=new Qe(e,4,!1,e,null,!1,!1)}),["cols","rows","size","span"].forEach(function(e){Be[e]=new Qe(e,6,!1,e,null,!1,!1)}),["rowSpan","start"].forEach(function(e){Be[e]=new Qe(e,5,!1,e.toLowerCase(),null,!1,!1)});var Ki=/[\-:]([a-z])/g;function Ji(e){return e[1].toUpperCase()}"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(e){var t=e.replace(Ki,Ji);Be[t]=new Qe(t,1,!1,e,null,!1,!1)}),"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(e){var t=e.replace(Ki,Ji);Be[t]=new Qe(t,1,!1,e,"http://www.w3.org/1999/xlink",!1,!1)}),["xml:base","xml:lang","xml:space"].forEach(function(e){var t=e.replace(Ki,Ji);Be[t]=new Qe(t,1,!1,e,"http://www.w3.org/XML/1998/namespace",!1,!1)}),["tabIndex","crossOrigin"].forEach(function(e){Be[e]=new Qe(e,1,!1,e.toLowerCase(),null,!1,!1)}),Be.xlinkHref=new Qe("xlinkHref",1,!1,"xlink:href","http://www.w3.org/1999/xlink",!0,!1),["src","href","action","formAction"].forEach(function(e){Be[e]=new Qe(e,1,!1,e.toLowerCase(),null,!0,!0)});function qi(e,t,n,r){var o=Be.hasOwnProperty(t)?Be[t]:null;(o!==null?o.type!==0:r||!(2<t.length)||t[0]!=="o"&&t[0]!=="O"||t[1]!=="n"&&t[1]!=="N")&&(Cf(t,n,o,r)&&(n=null),r||o===null?Sf(t)&&(n===null?e.removeAttribute(t):e.setAttribute(t,""+n)):o.mustUseProperty?e[o.propertyName]=n===null?o.type===3?!1:"":n:(t=o.attributeName,r=o.attributeNamespace,n===null?e.removeAttribute(t):(o=o.type,n=o===3||o===4&&n===!0?"":""+n,r?e.setAttributeNS(r,t,n):e.setAttribute(t,n))))}var Dt=wf.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,xo=Symbol.for("react.element"),On=Symbol.for("react.portal"),Mn=Symbol.for("react.fragment"),ea=Symbol.for("react.strict_mode"),ta=Symbol.for("react.profiler"),Qs=Symbol.for("react.provider"),Xs=Symbol.for("react.context"),na=Symbol.for("react.forward_ref"),ra=Symbol.for("react.suspense"),oa=Symbol.for("react.suspense_list"),ia=Symbol.for("react.memo"),Xt=Symbol.for("react.lazy"),Ks=Symbol.for("react.offscreen"),Js=Symbol.iterator;function mr(e){return e===null||typeof e!="object"?null:(e=Js&&e[Js]||e["@@iterator"],typeof e=="function"?e:null)}var je=Object.assign,aa;function gr(e){if(aa===void 0)try{throw Error()}catch(n){var t=n.stack.trim().match(/\n( *(at )?)/);aa=t&&t[1]||""}return`
`+aa+e}var la=!1;function sa(e,t){if(!e||la)return"";la=!0;var n=Error.prepareStackTrace;Error.prepareStackTrace=void 0;try{if(t)if(t=function(){throw Error()},Object.defineProperty(t.prototype,"props",{set:function(){throw Error()}}),typeof Reflect=="object"&&Reflect.construct){try{Reflect.construct(t,[])}catch(u){var r=u}Reflect.construct(e,[],t)}else{try{t.call()}catch(u){r=u}e.call(t.prototype)}else{try{throw Error()}catch(u){r=u}e()}}catch(u){if(u&&r&&typeof u.stack=="string"){for(var o=u.stack.split(`
`),i=r.stack.split(`
`),a=o.length-1,l=i.length-1;1<=a&&0<=l&&o[a]!==i[l];)l--;for(;1<=a&&0<=l;a--,l--)if(o[a]!==i[l]){if(a!==1||l!==1)do if(a--,l--,0>l||o[a]!==i[l]){var s=`
`+o[a].replace(" at new "," at ");return e.displayName&&s.includes("<anonymous>")&&(s=s.replace("<anonymous>",e.displayName)),s}while(1<=a&&0<=l);break}}}finally{la=!1,Error.prepareStackTrace=n}return(e=e?e.displayName||e.name:"")?gr(e):""}function Ef(e){switch(e.tag){case 5:return gr(e.type);case 16:return gr("Lazy");case 13:return gr("Suspense");case 19:return gr("SuspenseList");case 0:case 2:case 15:return e=sa(e.type,!1),e;case 11:return e=sa(e.type.render,!1),e;case 1:return e=sa(e.type,!0),e;default:return""}}function ca(e){if(e==null)return null;if(typeof e=="function")return e.displayName||e.name||null;if(typeof e=="string")return e;switch(e){case Mn:return"Fragment";case On:return"Portal";case ta:return"Profiler";case ea:return"StrictMode";case ra:return"Suspense";case oa:return"SuspenseList"}if(typeof e=="object")switch(e.$$typeof){case Xs:return(e.displayName||"Context")+".Consumer";case Qs:return(e._context.displayName||"Context")+".Provider";case na:var t=e.render;return e=e.displayName,e||(e=t.displayName||t.name||"",e=e!==""?"ForwardRef("+e+")":"ForwardRef"),e;case ia:return t=e.displayName||null,t!==null?t:ca(e.type)||"Memo";case Xt:t=e._payload,e=e._init;try{return ca(e(t))}catch{}}return null}function Nf(e){var t=e.type;switch(e.tag){case 24:return"Cache";case 9:return(t.displayName||"Context")+".Consumer";case 10:return(t._context.displayName||"Context")+".Provider";case 18:return"DehydratedFragment";case 11:return e=t.render,e=e.displayName||e.name||"",t.displayName||(e!==""?"ForwardRef("+e+")":"ForwardRef");case 7:return"Fragment";case 5:return t;case 4:return"Portal";case 3:return"Root";case 6:return"Text";case 16:return ca(t);case 8:return t===ea?"StrictMode":"Mode";case 22:return"Offscreen";case 12:return"Profiler";case 21:return"Scope";case 13:return"Suspense";case 19:return"SuspenseList";case 25:return"TracingMarker";case 1:case 0:case 17:case 2:case 14:case 15:if(typeof t=="function")return t.displayName||t.name||null;if(typeof t=="string")return t}return null}function Kt(e){switch(typeof e){case"boolean":case"number":case"string":case"undefined":return e;case"object":return e;default:return""}}function qs(e){var t=e.type;return(e=e.nodeName)&&e.toLowerCase()==="input"&&(t==="checkbox"||t==="radio")}function jf(e){var t=qs(e)?"checked":"value",n=Object.getOwnPropertyDescriptor(e.constructor.prototype,t),r=""+e[t];if(!e.hasOwnProperty(t)&&typeof n<"u"&&typeof n.get=="function"&&typeof n.set=="function"){var o=n.get,i=n.set;return Object.defineProperty(e,t,{configurable:!0,get:function(){return o.call(this)},set:function(a){r=""+a,i.call(this,a)}}),Object.defineProperty(e,t,{enumerable:n.enumerable}),{getValue:function(){return r},setValue:function(a){r=""+a},stopTracking:function(){e._valueTracker=null,delete e[t]}}}}function vo(e){e._valueTracker||(e._valueTracker=jf(e))}function ec(e){if(!e)return!1;var t=e._valueTracker;if(!t)return!0;var n=t.getValue(),r="";return e&&(r=qs(e)?e.checked?"true":"false":e.value),e=r,e!==n?(t.setValue(e),!0):!1}function yo(e){if(e=e||(typeof document<"u"?document:void 0),typeof e>"u")return null;try{return e.activeElement||e.body}catch{return e.body}}function ua(e,t){var n=t.checked;return je({},t,{defaultChecked:void 0,defaultValue:void 0,value:void 0,checked:n??e._wrapperState.initialChecked})}function tc(e,t){var n=t.defaultValue==null?"":t.defaultValue,r=t.checked!=null?t.checked:t.defaultChecked;n=Kt(t.value!=null?t.value:n),e._wrapperState={initialChecked:r,initialValue:n,controlled:t.type==="checkbox"||t.type==="radio"?t.checked!=null:t.value!=null}}function nc(e,t){t=t.checked,t!=null&&qi(e,"checked",t,!1)}function pa(e,t){nc(e,t);var n=Kt(t.value),r=t.type;if(n!=null)r==="number"?(n===0&&e.value===""||e.value!=n)&&(e.value=""+n):e.value!==""+n&&(e.value=""+n);else if(r==="submit"||r==="reset"){e.removeAttribute("value");return}t.hasOwnProperty("value")?da(e,t.type,n):t.hasOwnProperty("defaultValue")&&da(e,t.type,Kt(t.defaultValue)),t.checked==null&&t.defaultChecked!=null&&(e.defaultChecked=!!t.defaultChecked)}function rc(e,t,n){if(t.hasOwnProperty("value")||t.hasOwnProperty("defaultValue")){var r=t.type;if(!(r!=="submit"&&r!=="reset"||t.value!==void 0&&t.value!==null))return;t=""+e._wrapperState.initialValue,n||t===e.value||(e.value=t),e.defaultValue=t}n=e.name,n!==""&&(e.name=""),e.defaultChecked=!!e._wrapperState.initialChecked,n!==""&&(e.name=n)}function da(e,t,n){(t!=="number"||yo(e.ownerDocument)!==e)&&(n==null?e.defaultValue=""+e._wrapperState.initialValue:e.defaultValue!==""+n&&(e.defaultValue=""+n))}var xr=Array.isArray;function Bn(e,t,n,r){if(e=e.options,t){t={};for(var o=0;o<n.length;o++)t["$"+n[o]]=!0;for(n=0;n<e.length;n++)o=t.hasOwnProperty("$"+e[n].value),e[n].selected!==o&&(e[n].selected=o),o&&r&&(e[n].defaultSelected=!0)}else{for(n=""+Kt(n),t=null,o=0;o<e.length;o++){if(e[o].value===n){e[o].selected=!0,r&&(e[o].defaultSelected=!0);return}t!==null||e[o].disabled||(t=e[o])}t!==null&&(t.selected=!0)}}function fa(e,t){if(t.dangerouslySetInnerHTML!=null)throw Error(K(91));return je({},t,{value:void 0,defaultValue:void 0,children:""+e._wrapperState.initialValue})}function oc(e,t){var n=t.value;if(n==null){if(n=t.children,t=t.defaultValue,n!=null){if(t!=null)throw Error(K(92));if(xr(n)){if(1<n.length)throw Error(K(93));n=n[0]}t=n}t==null&&(t=""),n=t}e._wrapperState={initialValue:Kt(n)}}function ic(e,t){var n=Kt(t.value),r=Kt(t.defaultValue);n!=null&&(n=""+n,n!==e.value&&(e.value=n),t.defaultValue==null&&e.defaultValue!==n&&(e.defaultValue=n)),r!=null&&(e.defaultValue=""+r)}function ac(e){var t=e.textContent;t===e._wrapperState.initialValue&&t!==""&&t!==null&&(e.value=t)}function lc(e){switch(e){case"svg":return"http://www.w3.org/2000/svg";case"math":return"http://www.w3.org/1998/Math/MathML";default:return"http://www.w3.org/1999/xhtml"}}function ha(e,t){return e==null||e==="http://www.w3.org/1999/xhtml"?lc(t):e==="http://www.w3.org/2000/svg"&&t==="foreignObject"?"http://www.w3.org/1999/xhtml":e}var bo,sc=function(e){return typeof MSApp<"u"&&MSApp.execUnsafeLocalFunction?function(t,n,r,o){MSApp.execUnsafeLocalFunction(function(){return e(t,n,r,o)})}:e}(function(e,t){if(e.namespaceURI!=="http://www.w3.org/2000/svg"||"innerHTML"in e)e.innerHTML=t;else{for(bo=bo||document.createElement("div"),bo.innerHTML="<svg>"+t.valueOf().toString()+"</svg>",t=bo.firstChild;e.firstChild;)e.removeChild(e.firstChild);for(;t.firstChild;)e.appendChild(t.firstChild)}});function vr(e,t){if(t){var n=e.firstChild;if(n&&n===e.lastChild&&n.nodeType===3){n.nodeValue=t;return}}e.textContent=t}var yr={animationIterationCount:!0,aspectRatio:!0,borderImageOutset:!0,borderImageSlice:!0,borderImageWidth:!0,boxFlex:!0,boxFlexGroup:!0,boxOrdinalGroup:!0,columnCount:!0,columns:!0,flex:!0,flexGrow:!0,flexPositive:!0,flexShrink:!0,flexNegative:!0,flexOrder:!0,gridArea:!0,gridRow:!0,gridRowEnd:!0,gridRowSpan:!0,gridRowStart:!0,gridColumn:!0,gridColumnEnd:!0,gridColumnSpan:!0,gridColumnStart:!0,fontWeight:!0,lineClamp:!0,lineHeight:!0,opacity:!0,order:!0,orphans:!0,tabSize:!0,widows:!0,zIndex:!0,zoom:!0,fillOpacity:!0,floodOpacity:!0,stopOpacity:!0,strokeDasharray:!0,strokeDashoffset:!0,strokeMiterlimit:!0,strokeOpacity:!0,strokeWidth:!0},Ff=["Webkit","ms","Moz","O"];Object.keys(yr).forEach(function(e){Ff.forEach(function(t){t=t+e.charAt(0).toUpperCase()+e.substring(1),yr[t]=yr[e]})});function cc(e,t,n){return t==null||typeof t=="boolean"||t===""?"":n||typeof t!="number"||t===0||yr.hasOwnProperty(e)&&yr[e]?(""+t).trim():t+"px"}function uc(e,t){e=e.style;for(var n in t)if(t.hasOwnProperty(n)){var r=n.indexOf("--")===0,o=cc(n,t[n],r);n==="float"&&(n="cssFloat"),r?e.setProperty(n,o):e[n]=o}}var Tf=je({menuitem:!0},{area:!0,base:!0,br:!0,col:!0,embed:!0,hr:!0,img:!0,input:!0,keygen:!0,link:!0,meta:!0,param:!0,source:!0,track:!0,wbr:!0});function ma(e,t){if(t){if(Tf[e]&&(t.children!=null||t.dangerouslySetInnerHTML!=null))throw Error(K(137,e));if(t.dangerouslySetInnerHTML!=null){if(t.children!=null)throw Error(K(60));if(typeof t.dangerouslySetInnerHTML!="object"||!("__html"in t.dangerouslySetInnerHTML))throw Error(K(61))}if(t.style!=null&&typeof t.style!="object")throw Error(K(62))}}function ga(e,t){if(e.indexOf("-")===-1)return typeof t.is=="string";switch(e){case"annotation-xml":case"color-profile":case"font-face":case"font-face-src":case"font-face-uri":case"font-face-format":case"font-face-name":case"missing-glyph":return!1;default:return!0}}var xa=null;function va(e){return e=e.target||e.srcElement||window,e.correspondingUseElement&&(e=e.correspondingUseElement),e.nodeType===3?e.parentNode:e}var ya=null,$n=null,Un=null;function pc(e){if(e=$r(e)){if(typeof ya!="function")throw Error(K(280));var t=e.stateNode;t&&(t=Ho(t),ya(e.stateNode,e.type,t))}}function dc(e){$n?Un?Un.push(e):Un=[e]:$n=e}function fc(){if($n){var e=$n,t=Un;if(Un=$n=null,pc(e),t)for(e=0;e<t.length;e++)pc(t[e])}}function hc(e,t){return e(t)}function mc(){}var ba=!1;function gc(e,t,n){if(ba)return e(t,n);ba=!0;try{return hc(e,t,n)}finally{ba=!1,($n!==null||Un!==null)&&(mc(),fc())}}function br(e,t){var n=e.stateNode;if(n===null)return null;var r=Ho(n);if(r===null)return null;n=r[t];e:switch(t){case"onClick":case"onClickCapture":case"onDoubleClick":case"onDoubleClickCapture":case"onMouseDown":case"onMouseDownCapture":case"onMouseMove":case"onMouseMoveCapture":case"onMouseUp":case"onMouseUpCapture":case"onMouseEnter":(r=!r.disabled)||(e=e.type,r=!(e==="button"||e==="input"||e==="select"||e==="textarea")),e=!r;break e;default:e=!1}if(e)return null;if(n&&typeof n!="function")throw Error(K(231,t,typeof n));return n}var wa=!1;if(Lt)try{var wr={};Object.defineProperty(wr,"passive",{get:function(){wa=!0}}),window.addEventListener("test",wr,wr),window.removeEventListener("test",wr,wr)}catch{wa=!1}function Af(e,t,n,r,o,i,a,l,s){var u=Array.prototype.slice.call(arguments,3);try{t.apply(n,u)}catch(y){this.onError(y)}}var kr=!1,wo=null,ko=!1,ka=null,Pf={onError:function(e){kr=!0,wo=e}};function If(e,t,n,r,o,i,a,l,s){kr=!1,wo=null,Af.apply(Pf,arguments)}function zf(e,t,n,r,o,i,a,l,s){if(If.apply(this,arguments),kr){if(kr){var u=wo;kr=!1,wo=null}else throw Error(K(198));ko||(ko=!0,ka=u)}}function kn(e){var t=e,n=e;if(e.alternate)for(;t.return;)t=t.return;else{e=t;do t=e,t.flags&4098&&(n=t.return),e=t.return;while(e)}return t.tag===3?n:null}function xc(e){if(e.tag===13){var t=e.memoizedState;if(t===null&&(e=e.alternate,e!==null&&(t=e.memoizedState)),t!==null)return t.dehydrated}return null}function vc(e){if(kn(e)!==e)throw Error(K(188))}function Rf(e){var t=e.alternate;if(!t){if(t=kn(e),t===null)throw Error(K(188));return t!==e?null:e}for(var n=e,r=t;;){var o=n.return;if(o===null)break;var i=o.alternate;if(i===null){if(r=o.return,r!==null){n=r;continue}break}if(o.child===i.child){for(i=o.child;i;){if(i===n)return vc(o),e;if(i===r)return vc(o),t;i=i.sibling}throw Error(K(188))}if(n.return!==r.return)n=o,r=i;else{for(var a=!1,l=o.child;l;){if(l===n){a=!0,n=o,r=i;break}if(l===r){a=!0,r=o,n=i;break}l=l.sibling}if(!a){for(l=i.child;l;){if(l===n){a=!0,n=i,r=o;break}if(l===r){a=!0,r=i,n=o;break}l=l.sibling}if(!a)throw Error(K(189))}}if(n.alternate!==r)throw Error(K(190))}if(n.tag!==3)throw Error(K(188));return n.stateNode.current===n?e:t}function yc(e){return e=Rf(e),e!==null?bc(e):null}function bc(e){if(e.tag===5||e.tag===6)return e;for(e=e.child;e!==null;){var t=bc(e);if(t!==null)return t;e=e.sibling}return null}var wc=it.unstable_scheduleCallback,kc=it.unstable_cancelCallback,Lf=it.unstable_shouldYield,Df=it.unstable_requestPaint,Pe=it.unstable_now,Of=it.unstable_getCurrentPriorityLevel,Sa=it.unstable_ImmediatePriority,Sc=it.unstable_UserBlockingPriority,So=it.unstable_NormalPriority,Mf=it.unstable_LowPriority,_c=it.unstable_IdlePriority,_o=null,jt=null;function Bf(e){if(jt&&typeof jt.onCommitFiberRoot=="function")try{jt.onCommitFiberRoot(_o,e,void 0,(e.current.flags&128)===128)}catch{}}var bt=Math.clz32?Math.clz32:Hf,$f=Math.log,Uf=Math.LN2;function Hf(e){return e>>>=0,e===0?32:31-($f(e)/Uf|0)|0}var Co=64,Eo=4194304;function Sr(e){switch(e&-e){case 1:return 1;case 2:return 2;case 4:return 4;case 8:return 8;case 16:return 16;case 32:return 32;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return e&4194240;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return e&130023424;case 134217728:return 134217728;case 268435456:return 268435456;case 536870912:return 536870912;case 1073741824:return 1073741824;default:return e}}function No(e,t){var n=e.pendingLanes;if(n===0)return 0;var r=0,o=e.suspendedLanes,i=e.pingedLanes,a=n&268435455;if(a!==0){var l=a&~o;l!==0?r=Sr(l):(i&=a,i!==0&&(r=Sr(i)))}else a=n&~o,a!==0?r=Sr(a):i!==0&&(r=Sr(i));if(r===0)return 0;if(t!==0&&t!==r&&!(t&o)&&(o=r&-r,i=t&-t,o>=i||o===16&&(i&4194240)!==0))return t;if(r&4&&(r|=n&16),t=e.entangledLanes,t!==0)for(e=e.entanglements,t&=r;0<t;)n=31-bt(t),o=1<<n,r|=e[n],t&=~o;return r}function Wf(e,t){switch(e){case 1:case 2:case 4:return t+250;case 8:case 16:case 32:case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:return t+5e3;case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:return-1;case 134217728:case 268435456:case 536870912:case 1073741824:return-1;default:return-1}}function Vf(e,t){for(var n=e.suspendedLanes,r=e.pingedLanes,o=e.expirationTimes,i=e.pendingLanes;0<i;){var a=31-bt(i),l=1<<a,s=o[a];s===-1?(!(l&n)||l&r)&&(o[a]=Wf(l,t)):s<=t&&(e.expiredLanes|=l),i&=~l}}function _a(e){return e=e.pendingLanes&-1073741825,e!==0?e:e&1073741824?1073741824:0}function Cc(){var e=Co;return Co<<=1,!(Co&4194240)&&(Co=64),e}function Ca(e){for(var t=[],n=0;31>n;n++)t.push(e);return t}function _r(e,t,n){e.pendingLanes|=t,t!==536870912&&(e.suspendedLanes=0,e.pingedLanes=0),e=e.eventTimes,t=31-bt(t),e[t]=n}function Gf(e,t){var n=e.pendingLanes&~t;e.pendingLanes=t,e.suspendedLanes=0,e.pingedLanes=0,e.expiredLanes&=t,e.mutableReadLanes&=t,e.entangledLanes&=t,t=e.entanglements;var r=e.eventTimes;for(e=e.expirationTimes;0<n;){var o=31-bt(n),i=1<<o;t[o]=0,r[o]=-1,e[o]=-1,n&=~i}}function Ea(e,t){var n=e.entangledLanes|=t;for(e=e.entanglements;n;){var r=31-bt(n),o=1<<r;o&t|e[r]&t&&(e[r]|=t),n&=~o}}var we=0;function Ec(e){return e&=-e,1<e?4<e?e&268435455?16:536870912:4:1}var Nc,Na,jc,Fc,Tc,ja=!1,jo=[],Jt=null,qt=null,en=null,Cr=new Map,Er=new Map,tn=[],Zf="mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");function Ac(e,t){switch(e){case"focusin":case"focusout":Jt=null;break;case"dragenter":case"dragleave":qt=null;break;case"mouseover":case"mouseout":en=null;break;case"pointerover":case"pointerout":Cr.delete(t.pointerId);break;case"gotpointercapture":case"lostpointercapture":Er.delete(t.pointerId)}}function Nr(e,t,n,r,o,i){return e===null||e.nativeEvent!==i?(e={blockedOn:t,domEventName:n,eventSystemFlags:r,nativeEvent:i,targetContainers:[o]},t!==null&&(t=$r(t),t!==null&&Na(t)),e):(e.eventSystemFlags|=r,t=e.targetContainers,o!==null&&t.indexOf(o)===-1&&t.push(o),e)}function Yf(e,t,n,r,o){switch(t){case"focusin":return Jt=Nr(Jt,e,t,n,r,o),!0;case"dragenter":return qt=Nr(qt,e,t,n,r,o),!0;case"mouseover":return en=Nr(en,e,t,n,r,o),!0;case"pointerover":var i=o.pointerId;return Cr.set(i,Nr(Cr.get(i)||null,e,t,n,r,o)),!0;case"gotpointercapture":return i=o.pointerId,Er.set(i,Nr(Er.get(i)||null,e,t,n,r,o)),!0}return!1}function Pc(e){var t=Sn(e.target);if(t!==null){var n=kn(t);if(n!==null){if(t=n.tag,t===13){if(t=xc(n),t!==null){e.blockedOn=t,Tc(e.priority,function(){jc(n)});return}}else if(t===3&&n.stateNode.current.memoizedState.isDehydrated){e.blockedOn=n.tag===3?n.stateNode.containerInfo:null;return}}}e.blockedOn=null}function Fo(e){if(e.blockedOn!==null)return!1;for(var t=e.targetContainers;0<t.length;){var n=Ta(e.domEventName,e.eventSystemFlags,t[0],e.nativeEvent);if(n===null){n=e.nativeEvent;var r=new n.constructor(n.type,n);xa=r,n.target.dispatchEvent(r),xa=null}else return t=$r(n),t!==null&&Na(t),e.blockedOn=n,!1;t.shift()}return!0}function Ic(e,t,n){Fo(e)&&n.delete(t)}function Qf(){ja=!1,Jt!==null&&Fo(Jt)&&(Jt=null),qt!==null&&Fo(qt)&&(qt=null),en!==null&&Fo(en)&&(en=null),Cr.forEach(Ic),Er.forEach(Ic)}function jr(e,t){e.blockedOn===t&&(e.blockedOn=null,ja||(ja=!0,it.unstable_scheduleCallback(it.unstable_NormalPriority,Qf)))}function Fr(e){function t(o){return jr(o,e)}if(0<jo.length){jr(jo[0],e);for(var n=1;n<jo.length;n++){var r=jo[n];r.blockedOn===e&&(r.blockedOn=null)}}for(Jt!==null&&jr(Jt,e),qt!==null&&jr(qt,e),en!==null&&jr(en,e),Cr.forEach(t),Er.forEach(t),n=0;n<tn.length;n++)r=tn[n],r.blockedOn===e&&(r.blockedOn=null);for(;0<tn.length&&(n=tn[0],n.blockedOn===null);)Pc(n),n.blockedOn===null&&tn.shift()}var Hn=Dt.ReactCurrentBatchConfig,To=!0;function Xf(e,t,n,r){var o=we,i=Hn.transition;Hn.transition=null;try{we=1,Fa(e,t,n,r)}finally{we=o,Hn.transition=i}}function Kf(e,t,n,r){var o=we,i=Hn.transition;Hn.transition=null;try{we=4,Fa(e,t,n,r)}finally{we=o,Hn.transition=i}}function Fa(e,t,n,r){if(To){var o=Ta(e,t,n,r);if(o===null)Za(e,t,r,Ao,n),Ac(e,r);else if(Yf(o,e,t,n,r))r.stopPropagation();else if(Ac(e,r),t&4&&-1<Zf.indexOf(e)){for(;o!==null;){var i=$r(o);if(i!==null&&Nc(i),i=Ta(e,t,n,r),i===null&&Za(e,t,r,Ao,n),i===o)break;o=i}o!==null&&r.stopPropagation()}else Za(e,t,r,null,n)}}var Ao=null;function Ta(e,t,n,r){if(Ao=null,e=va(r),e=Sn(e),e!==null)if(t=kn(e),t===null)e=null;else if(n=t.tag,n===13){if(e=xc(t),e!==null)return e;e=null}else if(n===3){if(t.stateNode.current.memoizedState.isDehydrated)return t.tag===3?t.stateNode.containerInfo:null;e=null}else t!==e&&(e=null);return Ao=e,null}function zc(e){switch(e){case"cancel":case"click":case"close":case"contextmenu":case"copy":case"cut":case"auxclick":case"dblclick":case"dragend":case"dragstart":case"drop":case"focusin":case"focusout":case"input":case"invalid":case"keydown":case"keypress":case"keyup":case"mousedown":case"mouseup":case"paste":case"pause":case"play":case"pointercancel":case"pointerdown":case"pointerup":case"ratechange":case"reset":case"resize":case"seeked":case"submit":case"touchcancel":case"touchend":case"touchstart":case"volumechange":case"change":case"selectionchange":case"textInput":case"compositionstart":case"compositionend":case"compositionupdate":case"beforeblur":case"afterblur":case"beforeinput":case"blur":case"fullscreenchange":case"focus":case"hashchange":case"popstate":case"select":case"selectstart":return 1;case"drag":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"mousemove":case"mouseout":case"mouseover":case"pointermove":case"pointerout":case"pointerover":case"scroll":case"toggle":case"touchmove":case"wheel":case"mouseenter":case"mouseleave":case"pointerenter":case"pointerleave":return 4;case"message":switch(Of()){case Sa:return 1;case Sc:return 4;case So:case Mf:return 16;case _c:return 536870912;default:return 16}default:return 16}}var nn=null,Aa=null,Po=null;function Rc(){if(Po)return Po;var e,t=Aa,n=t.length,r,o="value"in nn?nn.value:nn.textContent,i=o.length;for(e=0;e<n&&t[e]===o[e];e++);var a=n-e;for(r=1;r<=a&&t[n-r]===o[i-r];r++);return Po=o.slice(e,1<r?1-r:void 0)}function Io(e){var t=e.keyCode;return"charCode"in e?(e=e.charCode,e===0&&t===13&&(e=13)):e=t,e===10&&(e=13),32<=e||e===13?e:0}function zo(){return!0}function Lc(){return!1}function at(e){function t(n,r,o,i,a){this._reactName=n,this._targetInst=o,this.type=r,this.nativeEvent=i,this.target=a,this.currentTarget=null;for(var l in e)e.hasOwnProperty(l)&&(n=e[l],this[l]=n?n(i):i[l]);return this.isDefaultPrevented=(i.defaultPrevented!=null?i.defaultPrevented:i.returnValue===!1)?zo:Lc,this.isPropagationStopped=Lc,this}return je(t.prototype,{preventDefault:function(){this.defaultPrevented=!0;var n=this.nativeEvent;n&&(n.preventDefault?n.preventDefault():typeof n.returnValue!="unknown"&&(n.returnValue=!1),this.isDefaultPrevented=zo)},stopPropagation:function(){var n=this.nativeEvent;n&&(n.stopPropagation?n.stopPropagation():typeof n.cancelBubble!="unknown"&&(n.cancelBubble=!0),this.isPropagationStopped=zo)},persist:function(){},isPersistent:zo}),t}var Wn={eventPhase:0,bubbles:0,cancelable:0,timeStamp:function(e){return e.timeStamp||Date.now()},defaultPrevented:0,isTrusted:0},Pa=at(Wn),Tr=je({},Wn,{view:0,detail:0}),Jf=at(Tr),Ia,za,Ar,Ro=je({},Tr,{screenX:0,screenY:0,clientX:0,clientY:0,pageX:0,pageY:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,getModifierState:La,button:0,buttons:0,relatedTarget:function(e){return e.relatedTarget===void 0?e.fromElement===e.srcElement?e.toElement:e.fromElement:e.relatedTarget},movementX:function(e){return"movementX"in e?e.movementX:(e!==Ar&&(Ar&&e.type==="mousemove"?(Ia=e.screenX-Ar.screenX,za=e.screenY-Ar.screenY):za=Ia=0,Ar=e),Ia)},movementY:function(e){return"movementY"in e?e.movementY:za}}),Dc=at(Ro),qf=je({},Ro,{dataTransfer:0}),eh=at(qf),th=je({},Tr,{relatedTarget:0}),Ra=at(th),nh=je({},Wn,{animationName:0,elapsedTime:0,pseudoElement:0}),rh=at(nh),oh=je({},Wn,{clipboardData:function(e){return"clipboardData"in e?e.clipboardData:window.clipboardData}}),ih=at(oh),ah=je({},Wn,{data:0}),Oc=at(ah),lh={Esc:"Escape",Spacebar:" ",Left:"ArrowLeft",Up:"ArrowUp",Right:"ArrowRight",Down:"ArrowDown",Del:"Delete",Win:"OS",Menu:"ContextMenu",Apps:"ContextMenu",Scroll:"ScrollLock",MozPrintableKey:"Unidentified"},sh={8:"Backspace",9:"Tab",12:"Clear",13:"Enter",16:"Shift",17:"Control",18:"Alt",19:"Pause",20:"CapsLock",27:"Escape",32:" ",33:"PageUp",34:"PageDown",35:"End",36:"Home",37:"ArrowLeft",38:"ArrowUp",39:"ArrowRight",40:"ArrowDown",45:"Insert",46:"Delete",112:"F1",113:"F2",114:"F3",115:"F4",116:"F5",117:"F6",118:"F7",119:"F8",120:"F9",121:"F10",122:"F11",123:"F12",144:"NumLock",145:"ScrollLock",224:"Meta"},ch={Alt:"altKey",Control:"ctrlKey",Meta:"metaKey",Shift:"shiftKey"};function uh(e){var t=this.nativeEvent;return t.getModifierState?t.getModifierState(e):(e=ch[e])?!!t[e]:!1}function La(){return uh}var ph=je({},Tr,{key:function(e){if(e.key){var t=lh[e.key]||e.key;if(t!=="Unidentified")return t}return e.type==="keypress"?(e=Io(e),e===13?"Enter":String.fromCharCode(e)):e.type==="keydown"||e.type==="keyup"?sh[e.keyCode]||"Unidentified":""},code:0,location:0,ctrlKey:0,shiftKey:0,altKey:0,metaKey:0,repeat:0,locale:0,getModifierState:La,charCode:function(e){return e.type==="keypress"?Io(e):0},keyCode:function(e){return e.type==="keydown"||e.type==="keyup"?e.keyCode:0},which:function(e){return e.type==="keypress"?Io(e):e.type==="keydown"||e.type==="keyup"?e.keyCode:0}}),dh=at(ph),fh=je({},Ro,{pointerId:0,width:0,height:0,pressure:0,tangentialPressure:0,tiltX:0,tiltY:0,twist:0,pointerType:0,isPrimary:0}),Mc=at(fh),hh=je({},Tr,{touches:0,targetTouches:0,changedTouches:0,altKey:0,metaKey:0,ctrlKey:0,shiftKey:0,getModifierState:La}),mh=at(hh),gh=je({},Wn,{propertyName:0,elapsedTime:0,pseudoElement:0}),xh=at(gh),vh=je({},Ro,{deltaX:function(e){return"deltaX"in e?e.deltaX:"wheelDeltaX"in e?-e.wheelDeltaX:0},deltaY:function(e){return"deltaY"in e?e.deltaY:"wheelDeltaY"in e?-e.wheelDeltaY:"wheelDelta"in e?-e.wheelDelta:0},deltaZ:0,deltaMode:0}),yh=at(vh),bh=[9,13,27,32],Da=Lt&&"CompositionEvent"in window,Pr=null;Lt&&"documentMode"in document&&(Pr=document.documentMode);var wh=Lt&&"TextEvent"in window&&!Pr,Bc=Lt&&(!Da||Pr&&8<Pr&&11>=Pr),$c=" ",Uc=!1;function Hc(e,t){switch(e){case"keyup":return bh.indexOf(t.keyCode)!==-1;case"keydown":return t.keyCode!==229;case"keypress":case"mousedown":case"focusout":return!0;default:return!1}}function Wc(e){return e=e.detail,typeof e=="object"&&"data"in e?e.data:null}var Vn=!1;function kh(e,t){switch(e){case"compositionend":return Wc(t);case"keypress":return t.which!==32?null:(Uc=!0,$c);case"textInput":return e=t.data,e===$c&&Uc?null:e;default:return null}}function Sh(e,t){if(Vn)return e==="compositionend"||!Da&&Hc(e,t)?(e=Rc(),Po=Aa=nn=null,Vn=!1,e):null;switch(e){case"paste":return null;case"keypress":if(!(t.ctrlKey||t.altKey||t.metaKey)||t.ctrlKey&&t.altKey){if(t.char&&1<t.char.length)return t.char;if(t.which)return String.fromCharCode(t.which)}return null;case"compositionend":return Bc&&t.locale!=="ko"?null:t.data;default:return null}}var _h={color:!0,date:!0,datetime:!0,"datetime-local":!0,email:!0,month:!0,number:!0,password:!0,range:!0,search:!0,tel:!0,text:!0,time:!0,url:!0,week:!0};function Vc(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t==="input"?!!_h[e.type]:t==="textarea"}function Gc(e,t,n,r){dc(r),t=Bo(t,"onChange"),0<t.length&&(n=new Pa("onChange","change",null,n,r),e.push({event:n,listeners:t}))}var Ir=null,zr=null;function Ch(e){uu(e,0)}function Lo(e){var t=Xn(e);if(ec(t))return e}function Eh(e,t){if(e==="change")return t}var Zc=!1;if(Lt){var Oa;if(Lt){var Ma="oninput"in document;if(!Ma){var Yc=document.createElement("div");Yc.setAttribute("oninput","return;"),Ma=typeof Yc.oninput=="function"}Oa=Ma}else Oa=!1;Zc=Oa&&(!document.documentMode||9<document.documentMode)}function Qc(){Ir&&(Ir.detachEvent("onpropertychange",Xc),zr=Ir=null)}function Xc(e){if(e.propertyName==="value"&&Lo(zr)){var t=[];Gc(t,zr,e,va(e)),gc(Ch,t)}}function Nh(e,t,n){e==="focusin"?(Qc(),Ir=t,zr=n,Ir.attachEvent("onpropertychange",Xc)):e==="focusout"&&Qc()}function jh(e){if(e==="selectionchange"||e==="keyup"||e==="keydown")return Lo(zr)}function Fh(e,t){if(e==="click")return Lo(t)}function Th(e,t){if(e==="input"||e==="change")return Lo(t)}function Ah(e,t){return e===t&&(e!==0||1/e===1/t)||e!==e&&t!==t}var wt=typeof Object.is=="function"?Object.is:Ah;function Rr(e,t){if(wt(e,t))return!0;if(typeof e!="object"||e===null||typeof t!="object"||t===null)return!1;var n=Object.keys(e),r=Object.keys(t);if(n.length!==r.length)return!1;for(r=0;r<n.length;r++){var o=n[r];if(!Xi.call(t,o)||!wt(e[o],t[o]))return!1}return!0}function Kc(e){for(;e&&e.firstChild;)e=e.firstChild;return e}function Jc(e,t){var n=Kc(e);e=0;for(var r;n;){if(n.nodeType===3){if(r=e+n.textContent.length,e<=t&&r>=t)return{node:n,offset:t-e};e=r}e:{for(;n;){if(n.nextSibling){n=n.nextSibling;break e}n=n.parentNode}n=void 0}n=Kc(n)}}function qc(e,t){return e&&t?e===t?!0:e&&e.nodeType===3?!1:t&&t.nodeType===3?qc(e,t.parentNode):"contains"in e?e.contains(t):e.compareDocumentPosition?!!(e.compareDocumentPosition(t)&16):!1:!1}function eu(){for(var e=window,t=yo();t instanceof e.HTMLIFrameElement;){try{var n=typeof t.contentWindow.location.href=="string"}catch{n=!1}if(n)e=t.contentWindow;else break;t=yo(e.document)}return t}function Ba(e){var t=e&&e.nodeName&&e.nodeName.toLowerCase();return t&&(t==="input"&&(e.type==="text"||e.type==="search"||e.type==="tel"||e.type==="url"||e.type==="password")||t==="textarea"||e.contentEditable==="true")}function Ph(e){var t=eu(),n=e.focusedElem,r=e.selectionRange;if(t!==n&&n&&n.ownerDocument&&qc(n.ownerDocument.documentElement,n)){if(r!==null&&Ba(n)){if(t=r.start,e=r.end,e===void 0&&(e=t),"selectionStart"in n)n.selectionStart=t,n.selectionEnd=Math.min(e,n.value.length);else if(e=(t=n.ownerDocument||document)&&t.defaultView||window,e.getSelection){e=e.getSelection();var o=n.textContent.length,i=Math.min(r.start,o);r=r.end===void 0?i:Math.min(r.end,o),!e.extend&&i>r&&(o=r,r=i,i=o),o=Jc(n,i);var a=Jc(n,r);o&&a&&(e.rangeCount!==1||e.anchorNode!==o.node||e.anchorOffset!==o.offset||e.focusNode!==a.node||e.focusOffset!==a.offset)&&(t=t.createRange(),t.setStart(o.node,o.offset),e.removeAllRanges(),i>r?(e.addRange(t),e.extend(a.node,a.offset)):(t.setEnd(a.node,a.offset),e.addRange(t)))}}for(t=[],e=n;e=e.parentNode;)e.nodeType===1&&t.push({element:e,left:e.scrollLeft,top:e.scrollTop});for(typeof n.focus=="function"&&n.focus(),n=0;n<t.length;n++)e=t[n],e.element.scrollLeft=e.left,e.element.scrollTop=e.top}}var Ih=Lt&&"documentMode"in document&&11>=document.documentMode,Gn=null,$a=null,Lr=null,Ua=!1;function tu(e,t,n){var r=n.window===n?n.document:n.nodeType===9?n:n.ownerDocument;Ua||Gn==null||Gn!==yo(r)||(r=Gn,"selectionStart"in r&&Ba(r)?r={start:r.selectionStart,end:r.selectionEnd}:(r=(r.ownerDocument&&r.ownerDocument.defaultView||window).getSelection(),r={anchorNode:r.anchorNode,anchorOffset:r.anchorOffset,focusNode:r.focusNode,focusOffset:r.focusOffset}),Lr&&Rr(Lr,r)||(Lr=r,r=Bo($a,"onSelect"),0<r.length&&(t=new Pa("onSelect","select",null,t,n),e.push({event:t,listeners:r}),t.target=Gn)))}function Do(e,t){var n={};return n[e.toLowerCase()]=t.toLowerCase(),n["Webkit"+e]="webkit"+t,n["Moz"+e]="moz"+t,n}var Zn={animationend:Do("Animation","AnimationEnd"),animationiteration:Do("Animation","AnimationIteration"),animationstart:Do("Animation","AnimationStart"),transitionend:Do("Transition","TransitionEnd")},Ha={},nu={};Lt&&(nu=document.createElement("div").style,"AnimationEvent"in window||(delete Zn.animationend.animation,delete Zn.animationiteration.animation,delete Zn.animationstart.animation),"TransitionEvent"in window||delete Zn.transitionend.transition);function Oo(e){if(Ha[e])return Ha[e];if(!Zn[e])return e;var t=Zn[e],n;for(n in t)if(t.hasOwnProperty(n)&&n in nu)return Ha[e]=t[n];return e}var ru=Oo("animationend"),ou=Oo("animationiteration"),iu=Oo("animationstart"),au=Oo("transitionend"),lu=new Map,su="abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");function rn(e,t){lu.set(e,t),wn(t,[e])}for(var Wa=0;Wa<su.length;Wa++){var Va=su[Wa],zh=Va.toLowerCase(),Rh=Va[0].toUpperCase()+Va.slice(1);rn(zh,"on"+Rh)}rn(ru,"onAnimationEnd"),rn(ou,"onAnimationIteration"),rn(iu,"onAnimationStart"),rn("dblclick","onDoubleClick"),rn("focusin","onFocus"),rn("focusout","onBlur"),rn(au,"onTransitionEnd"),Dn("onMouseEnter",["mouseout","mouseover"]),Dn("onMouseLeave",["mouseout","mouseover"]),Dn("onPointerEnter",["pointerout","pointerover"]),Dn("onPointerLeave",["pointerout","pointerover"]),wn("onChange","change click focusin focusout input keydown keyup selectionchange".split(" ")),wn("onSelect","focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" ")),wn("onBeforeInput",["compositionend","keypress","textInput","paste"]),wn("onCompositionEnd","compositionend focusout keydown keypress keyup mousedown".split(" ")),wn("onCompositionStart","compositionstart focusout keydown keypress keyup mousedown".split(" ")),wn("onCompositionUpdate","compositionupdate focusout keydown keypress keyup mousedown".split(" "));var Dr="abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),Lh=new Set("cancel close invalid load scroll toggle".split(" ").concat(Dr));function cu(e,t,n){var r=e.type||"unknown-event";e.currentTarget=n,zf(r,t,void 0,e),e.currentTarget=null}function uu(e,t){t=(t&4)!==0;for(var n=0;n<e.length;n++){var r=e[n],o=r.event;r=r.listeners;e:{var i=void 0;if(t)for(var a=r.length-1;0<=a;a--){var l=r[a],s=l.instance,u=l.currentTarget;if(l=l.listener,s!==i&&o.isPropagationStopped())break e;cu(o,l,u),i=s}else for(a=0;a<r.length;a++){if(l=r[a],s=l.instance,u=l.currentTarget,l=l.listener,s!==i&&o.isPropagationStopped())break e;cu(o,l,u),i=s}}}if(ko)throw e=ka,ko=!1,ka=null,e}function Ce(e,t){var n=t[qa];n===void 0&&(n=t[qa]=new Set);var r=e+"__bubble";n.has(r)||(pu(t,e,2,!1),n.add(r))}function Ga(e,t,n){var r=0;t&&(r|=4),pu(n,e,r,t)}var Mo="_reactListening"+Math.random().toString(36).slice(2);function Or(e){if(!e[Mo]){e[Mo]=!0,Gs.forEach(function(n){n!=="selectionchange"&&(Lh.has(n)||Ga(n,!1,e),Ga(n,!0,e))});var t=e.nodeType===9?e:e.ownerDocument;t===null||t[Mo]||(t[Mo]=!0,Ga("selectionchange",!1,t))}}function pu(e,t,n,r){switch(zc(t)){case 1:var o=Xf;break;case 4:o=Kf;break;default:o=Fa}n=o.bind(null,t,n,e),o=void 0,!wa||t!=="touchstart"&&t!=="touchmove"&&t!=="wheel"||(o=!0),r?o!==void 0?e.addEventListener(t,n,{capture:!0,passive:o}):e.addEventListener(t,n,!0):o!==void 0?e.addEventListener(t,n,{passive:o}):e.addEventListener(t,n,!1)}function Za(e,t,n,r,o){var i=r;if(!(t&1)&&!(t&2)&&r!==null)e:for(;;){if(r===null)return;var a=r.tag;if(a===3||a===4){var l=r.stateNode.containerInfo;if(l===o||l.nodeType===8&&l.parentNode===o)break;if(a===4)for(a=r.return;a!==null;){var s=a.tag;if((s===3||s===4)&&(s=a.stateNode.containerInfo,s===o||s.nodeType===8&&s.parentNode===o))return;a=a.return}for(;l!==null;){if(a=Sn(l),a===null)return;if(s=a.tag,s===5||s===6){r=i=a;continue e}l=l.parentNode}}r=r.return}gc(function(){var u=i,y=va(n),x=[];e:{var w=lu.get(e);if(w!==void 0){var h=Pa,b=e;switch(e){case"keypress":if(Io(n)===0)break e;case"keydown":case"keyup":h=dh;break;case"focusin":b="focus",h=Ra;break;case"focusout":b="blur",h=Ra;break;case"beforeblur":case"afterblur":h=Ra;break;case"click":if(n.button===2)break e;case"auxclick":case"dblclick":case"mousedown":case"mousemove":case"mouseup":case"mouseout":case"mouseover":case"contextmenu":h=Dc;break;case"drag":case"dragend":case"dragenter":case"dragexit":case"dragleave":case"dragover":case"dragstart":case"drop":h=eh;break;case"touchcancel":case"touchend":case"touchmove":case"touchstart":h=mh;break;case ru:case ou:case iu:h=rh;break;case au:h=xh;break;case"scroll":h=Jf;break;case"wheel":h=yh;break;case"copy":case"cut":case"paste":h=ih;break;case"gotpointercapture":case"lostpointercapture":case"pointercancel":case"pointerdown":case"pointermove":case"pointerout":case"pointerover":case"pointerup":h=Mc}var f=(t&4)!==0,v=!f&&e==="scroll",p=f?w!==null?w+"Capture":null:w;f=[];for(var d=u,g;d!==null;){g=d;var S=g.stateNode;if(g.tag===5&&S!==null&&(g=S,p!==null&&(S=br(d,p),S!=null&&f.push(Mr(d,S,g)))),v)break;d=d.return}0<f.length&&(w=new h(w,b,null,n,y),x.push({event:w,listeners:f}))}}if(!(t&7)){e:{if(w=e==="mouseover"||e==="pointerover",h=e==="mouseout"||e==="pointerout",w&&n!==xa&&(b=n.relatedTarget||n.fromElement)&&(Sn(b)||b[Ot]))break e;if((h||w)&&(w=y.window===y?y:(w=y.ownerDocument)?w.defaultView||w.parentWindow:window,h?(b=n.relatedTarget||n.toElement,h=u,b=b?Sn(b):null,b!==null&&(v=kn(b),b!==v||b.tag!==5&&b.tag!==6)&&(b=null)):(h=null,b=u),h!==b)){if(f=Dc,S="onMouseLeave",p="onMouseEnter",d="mouse",(e==="pointerout"||e==="pointerover")&&(f=Mc,S="onPointerLeave",p="onPointerEnter",d="pointer"),v=h==null?w:Xn(h),g=b==null?w:Xn(b),w=new f(S,d+"leave",h,n,y),w.target=v,w.relatedTarget=g,S=null,Sn(y)===u&&(f=new f(p,d+"enter",b,n,y),f.target=g,f.relatedTarget=v,S=f),v=S,h&&b)t:{for(f=h,p=b,d=0,g=f;g;g=Yn(g))d++;for(g=0,S=p;S;S=Yn(S))g++;for(;0<d-g;)f=Yn(f),d--;for(;0<g-d;)p=Yn(p),g--;for(;d--;){if(f===p||p!==null&&f===p.alternate)break t;f=Yn(f),p=Yn(p)}f=null}else f=null;h!==null&&du(x,w,h,f,!1),b!==null&&v!==null&&du(x,v,b,f,!0)}}e:{if(w=u?Xn(u):window,h=w.nodeName&&w.nodeName.toLowerCase(),h==="select"||h==="input"&&w.type==="file")var C=Eh;else if(Vc(w))if(Zc)C=Th;else{C=jh;var A=Nh}else(h=w.nodeName)&&h.toLowerCase()==="input"&&(w.type==="checkbox"||w.type==="radio")&&(C=Fh);if(C&&(C=C(e,u))){Gc(x,C,n,y);break e}A&&A(e,w,u),e==="focusout"&&(A=w._wrapperState)&&A.controlled&&w.type==="number"&&da(w,"number",w.value)}switch(A=u?Xn(u):window,e){case"focusin":(Vc(A)||A.contentEditable==="true")&&(Gn=A,$a=u,Lr=null);break;case"focusout":Lr=$a=Gn=null;break;case"mousedown":Ua=!0;break;case"contextmenu":case"mouseup":case"dragend":Ua=!1,tu(x,n,y);break;case"selectionchange":if(Ih)break;case"keydown":case"keyup":tu(x,n,y)}var T;if(Da)e:{switch(e){case"compositionstart":var R="onCompositionStart";break e;case"compositionend":R="onCompositionEnd";break e;case"compositionupdate":R="onCompositionUpdate";break e}R=void 0}else Vn?Hc(e,n)&&(R="onCompositionEnd"):e==="keydown"&&n.keyCode===229&&(R="onCompositionStart");R&&(Bc&&n.locale!=="ko"&&(Vn||R!=="onCompositionStart"?R==="onCompositionEnd"&&Vn&&(T=Rc()):(nn=y,Aa="value"in nn?nn.value:nn.textContent,Vn=!0)),A=Bo(u,R),0<A.length&&(R=new Oc(R,e,null,n,y),x.push({event:R,listeners:A}),T?R.data=T:(T=Wc(n),T!==null&&(R.data=T)))),(T=wh?kh(e,n):Sh(e,n))&&(u=Bo(u,"onBeforeInput"),0<u.length&&(y=new Oc("onBeforeInput","beforeinput",null,n,y),x.push({event:y,listeners:u}),y.data=T))}uu(x,t)})}function Mr(e,t,n){return{instance:e,listener:t,currentTarget:n}}function Bo(e,t){for(var n=t+"Capture",r=[];e!==null;){var o=e,i=o.stateNode;o.tag===5&&i!==null&&(o=i,i=br(e,n),i!=null&&r.unshift(Mr(e,i,o)),i=br(e,t),i!=null&&r.push(Mr(e,i,o))),e=e.return}return r}function Yn(e){if(e===null)return null;do e=e.return;while(e&&e.tag!==5);return e||null}function du(e,t,n,r,o){for(var i=t._reactName,a=[];n!==null&&n!==r;){var l=n,s=l.alternate,u=l.stateNode;if(s!==null&&s===r)break;l.tag===5&&u!==null&&(l=u,o?(s=br(n,i),s!=null&&a.unshift(Mr(n,s,l))):o||(s=br(n,i),s!=null&&a.push(Mr(n,s,l)))),n=n.return}a.length!==0&&e.push({event:t,listeners:a})}var Dh=/\r\n?/g,Oh=/\u0000|\uFFFD/g;function fu(e){return(typeof e=="string"?e:""+e).replace(Dh,`
`).replace(Oh,"")}function $o(e,t,n){if(t=fu(t),fu(e)!==t&&n)throw Error(K(425))}function Uo(){}var Ya=null,Qa=null;function Xa(e,t){return e==="textarea"||e==="noscript"||typeof t.children=="string"||typeof t.children=="number"||typeof t.dangerouslySetInnerHTML=="object"&&t.dangerouslySetInnerHTML!==null&&t.dangerouslySetInnerHTML.__html!=null}var Ka=typeof setTimeout=="function"?setTimeout:void 0,Mh=typeof clearTimeout=="function"?clearTimeout:void 0,hu=typeof Promise=="function"?Promise:void 0,Bh=typeof queueMicrotask=="function"?queueMicrotask:typeof hu<"u"?function(e){return hu.resolve(null).then(e).catch($h)}:Ka;function $h(e){setTimeout(function(){throw e})}function Ja(e,t){var n=t,r=0;do{var o=n.nextSibling;if(e.removeChild(n),o&&o.nodeType===8)if(n=o.data,n==="/$"){if(r===0){e.removeChild(o),Fr(t);return}r--}else n!=="$"&&n!=="$?"&&n!=="$!"||r++;n=o}while(n);Fr(t)}function on(e){for(;e!=null;e=e.nextSibling){var t=e.nodeType;if(t===1||t===3)break;if(t===8){if(t=e.data,t==="$"||t==="$!"||t==="$?")break;if(t==="/$")return null}}return e}function mu(e){e=e.previousSibling;for(var t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="$"||n==="$!"||n==="$?"){if(t===0)return e;t--}else n==="/$"&&t++}e=e.previousSibling}return null}var Qn=Math.random().toString(36).slice(2),Ft="__reactFiber$"+Qn,Br="__reactProps$"+Qn,Ot="__reactContainer$"+Qn,qa="__reactEvents$"+Qn,Uh="__reactListeners$"+Qn,Hh="__reactHandles$"+Qn;function Sn(e){var t=e[Ft];if(t)return t;for(var n=e.parentNode;n;){if(t=n[Ot]||n[Ft]){if(n=t.alternate,t.child!==null||n!==null&&n.child!==null)for(e=mu(e);e!==null;){if(n=e[Ft])return n;e=mu(e)}return t}e=n,n=e.parentNode}return null}function $r(e){return e=e[Ft]||e[Ot],!e||e.tag!==5&&e.tag!==6&&e.tag!==13&&e.tag!==3?null:e}function Xn(e){if(e.tag===5||e.tag===6)return e.stateNode;throw Error(K(33))}function Ho(e){return e[Br]||null}var el=[],Kn=-1;function an(e){return{current:e}}function Ee(e){0>Kn||(e.current=el[Kn],el[Kn]=null,Kn--)}function Se(e,t){Kn++,el[Kn]=e.current,e.current=t}var ln={},We=an(ln),Je=an(!1),_n=ln;function Jn(e,t){var n=e.type.contextTypes;if(!n)return ln;var r=e.stateNode;if(r&&r.__reactInternalMemoizedUnmaskedChildContext===t)return r.__reactInternalMemoizedMaskedChildContext;var o={},i;for(i in n)o[i]=t[i];return r&&(e=e.stateNode,e.__reactInternalMemoizedUnmaskedChildContext=t,e.__reactInternalMemoizedMaskedChildContext=o),o}function qe(e){return e=e.childContextTypes,e!=null}function Wo(){Ee(Je),Ee(We)}function gu(e,t,n){if(We.current!==ln)throw Error(K(168));Se(We,t),Se(Je,n)}function xu(e,t,n){var r=e.stateNode;if(t=t.childContextTypes,typeof r.getChildContext!="function")return n;r=r.getChildContext();for(var o in r)if(!(o in t))throw Error(K(108,Nf(e)||"Unknown",o));return je({},n,r)}function Vo(e){return e=(e=e.stateNode)&&e.__reactInternalMemoizedMergedChildContext||ln,_n=We.current,Se(We,e),Se(Je,Je.current),!0}function vu(e,t,n){var r=e.stateNode;if(!r)throw Error(K(169));n?(e=xu(e,t,_n),r.__reactInternalMemoizedMergedChildContext=e,Ee(Je),Ee(We),Se(We,e)):Ee(Je),Se(Je,n)}var Mt=null,Go=!1,tl=!1;function yu(e){Mt===null?Mt=[e]:Mt.push(e)}function Wh(e){Go=!0,yu(e)}function sn(){if(!tl&&Mt!==null){tl=!0;var e=0,t=we;try{var n=Mt;for(we=1;e<n.length;e++){var r=n[e];do r=r(!0);while(r!==null)}Mt=null,Go=!1}catch(o){throw Mt!==null&&(Mt=Mt.slice(e+1)),wc(Sa,sn),o}finally{we=t,tl=!1}}return null}var qn=[],er=0,Zo=null,Yo=0,pt=[],dt=0,Cn=null,Bt=1,$t="";function En(e,t){qn[er++]=Yo,qn[er++]=Zo,Zo=e,Yo=t}function bu(e,t,n){pt[dt++]=Bt,pt[dt++]=$t,pt[dt++]=Cn,Cn=e;var r=Bt;e=$t;var o=32-bt(r)-1;r&=~(1<<o),n+=1;var i=32-bt(t)+o;if(30<i){var a=o-o%5;i=(r&(1<<a)-1).toString(32),r>>=a,o-=a,Bt=1<<32-bt(t)+o|n<<o|r,$t=i+e}else Bt=1<<i|n<<o|r,$t=e}function nl(e){e.return!==null&&(En(e,1),bu(e,1,0))}function rl(e){for(;e===Zo;)Zo=qn[--er],qn[er]=null,Yo=qn[--er],qn[er]=null;for(;e===Cn;)Cn=pt[--dt],pt[dt]=null,$t=pt[--dt],pt[dt]=null,Bt=pt[--dt],pt[dt]=null}var lt=null,st=null,Ne=!1,kt=null;function wu(e,t){var n=gt(5,null,null,0);n.elementType="DELETED",n.stateNode=t,n.return=e,t=e.deletions,t===null?(e.deletions=[n],e.flags|=16):t.push(n)}function ku(e,t){switch(e.tag){case 5:var n=e.type;return t=t.nodeType!==1||n.toLowerCase()!==t.nodeName.toLowerCase()?null:t,t!==null?(e.stateNode=t,lt=e,st=on(t.firstChild),!0):!1;case 6:return t=e.pendingProps===""||t.nodeType!==3?null:t,t!==null?(e.stateNode=t,lt=e,st=null,!0):!1;case 13:return t=t.nodeType!==8?null:t,t!==null?(n=Cn!==null?{id:Bt,overflow:$t}:null,e.memoizedState={dehydrated:t,treeContext:n,retryLane:1073741824},n=gt(18,null,null,0),n.stateNode=t,n.return=e,e.child=n,lt=e,st=null,!0):!1;default:return!1}}function ol(e){return(e.mode&1)!==0&&(e.flags&128)===0}function il(e){if(Ne){var t=st;if(t){var n=t;if(!ku(e,t)){if(ol(e))throw Error(K(418));t=on(n.nextSibling);var r=lt;t&&ku(e,t)?wu(r,n):(e.flags=e.flags&-4097|2,Ne=!1,lt=e)}}else{if(ol(e))throw Error(K(418));e.flags=e.flags&-4097|2,Ne=!1,lt=e}}}function Su(e){for(e=e.return;e!==null&&e.tag!==5&&e.tag!==3&&e.tag!==13;)e=e.return;lt=e}function Qo(e){if(e!==lt)return!1;if(!Ne)return Su(e),Ne=!0,!1;var t;if((t=e.tag!==3)&&!(t=e.tag!==5)&&(t=e.type,t=t!=="head"&&t!=="body"&&!Xa(e.type,e.memoizedProps)),t&&(t=st)){if(ol(e))throw _u(),Error(K(418));for(;t;)wu(e,t),t=on(t.nextSibling)}if(Su(e),e.tag===13){if(e=e.memoizedState,e=e!==null?e.dehydrated:null,!e)throw Error(K(317));e:{for(e=e.nextSibling,t=0;e;){if(e.nodeType===8){var n=e.data;if(n==="/$"){if(t===0){st=on(e.nextSibling);break e}t--}else n!=="$"&&n!=="$!"&&n!=="$?"||t++}e=e.nextSibling}st=null}}else st=lt?on(e.stateNode.nextSibling):null;return!0}function _u(){for(var e=st;e;)e=on(e.nextSibling)}function tr(){st=lt=null,Ne=!1}function al(e){kt===null?kt=[e]:kt.push(e)}var Vh=Dt.ReactCurrentBatchConfig;function Ur(e,t,n){if(e=n.ref,e!==null&&typeof e!="function"&&typeof e!="object"){if(n._owner){if(n=n._owner,n){if(n.tag!==1)throw Error(K(309));var r=n.stateNode}if(!r)throw Error(K(147,e));var o=r,i=""+e;return t!==null&&t.ref!==null&&typeof t.ref=="function"&&t.ref._stringRef===i?t.ref:(t=function(a){var l=o.refs;a===null?delete l[i]:l[i]=a},t._stringRef=i,t)}if(typeof e!="string")throw Error(K(284));if(!n._owner)throw Error(K(290,e))}return e}function Xo(e,t){throw e=Object.prototype.toString.call(t),Error(K(31,e==="[object Object]"?"object with keys {"+Object.keys(t).join(", ")+"}":e))}function Cu(e){var t=e._init;return t(e._payload)}function Eu(e){function t(p,d){if(e){var g=p.deletions;g===null?(p.deletions=[d],p.flags|=16):g.push(d)}}function n(p,d){if(!e)return null;for(;d!==null;)t(p,d),d=d.sibling;return null}function r(p,d){for(p=new Map;d!==null;)d.key!==null?p.set(d.key,d):p.set(d.index,d),d=d.sibling;return p}function o(p,d){return p=gn(p,d),p.index=0,p.sibling=null,p}function i(p,d,g){return p.index=g,e?(g=p.alternate,g!==null?(g=g.index,g<d?(p.flags|=2,d):g):(p.flags|=2,d)):(p.flags|=1048576,d)}function a(p){return e&&p.alternate===null&&(p.flags|=2),p}function l(p,d,g,S){return d===null||d.tag!==6?(d=Kl(g,p.mode,S),d.return=p,d):(d=o(d,g),d.return=p,d)}function s(p,d,g,S){var C=g.type;return C===Mn?y(p,d,g.props.children,S,g.key):d!==null&&(d.elementType===C||typeof C=="object"&&C!==null&&C.$$typeof===Xt&&Cu(C)===d.type)?(S=o(d,g.props),S.ref=Ur(p,d,g),S.return=p,S):(S=bi(g.type,g.key,g.props,null,p.mode,S),S.ref=Ur(p,d,g),S.return=p,S)}function u(p,d,g,S){return d===null||d.tag!==4||d.stateNode.containerInfo!==g.containerInfo||d.stateNode.implementation!==g.implementation?(d=Jl(g,p.mode,S),d.return=p,d):(d=o(d,g.children||[]),d.return=p,d)}function y(p,d,g,S,C){return d===null||d.tag!==7?(d=zn(g,p.mode,S,C),d.return=p,d):(d=o(d,g),d.return=p,d)}function x(p,d,g){if(typeof d=="string"&&d!==""||typeof d=="number")return d=Kl(""+d,p.mode,g),d.return=p,d;if(typeof d=="object"&&d!==null){switch(d.$$typeof){case xo:return g=bi(d.type,d.key,d.props,null,p.mode,g),g.ref=Ur(p,null,d),g.return=p,g;case On:return d=Jl(d,p.mode,g),d.return=p,d;case Xt:var S=d._init;return x(p,S(d._payload),g)}if(xr(d)||mr(d))return d=zn(d,p.mode,g,null),d.return=p,d;Xo(p,d)}return null}function w(p,d,g,S){var C=d!==null?d.key:null;if(typeof g=="string"&&g!==""||typeof g=="number")return C!==null?null:l(p,d,""+g,S);if(typeof g=="object"&&g!==null){switch(g.$$typeof){case xo:return g.key===C?s(p,d,g,S):null;case On:return g.key===C?u(p,d,g,S):null;case Xt:return C=g._init,w(p,d,C(g._payload),S)}if(xr(g)||mr(g))return C!==null?null:y(p,d,g,S,null);Xo(p,g)}return null}function h(p,d,g,S,C){if(typeof S=="string"&&S!==""||typeof S=="number")return p=p.get(g)||null,l(d,p,""+S,C);if(typeof S=="object"&&S!==null){switch(S.$$typeof){case xo:return p=p.get(S.key===null?g:S.key)||null,s(d,p,S,C);case On:return p=p.get(S.key===null?g:S.key)||null,u(d,p,S,C);case Xt:var A=S._init;return h(p,d,g,A(S._payload),C)}if(xr(S)||mr(S))return p=p.get(g)||null,y(d,p,S,C,null);Xo(d,S)}return null}function b(p,d,g,S){for(var C=null,A=null,T=d,R=d=0,L=null;T!==null&&R<g.length;R++){T.index>R?(L=T,T=null):L=T.sibling;var M=w(p,T,g[R],S);if(M===null){T===null&&(T=L);break}e&&T&&M.alternate===null&&t(p,T),d=i(M,d,R),A===null?C=M:A.sibling=M,A=M,T=L}if(R===g.length)return n(p,T),Ne&&En(p,R),C;if(T===null){for(;R<g.length;R++)T=x(p,g[R],S),T!==null&&(d=i(T,d,R),A===null?C=T:A.sibling=T,A=T);return Ne&&En(p,R),C}for(T=r(p,T);R<g.length;R++)L=h(T,p,R,g[R],S),L!==null&&(e&&L.alternate!==null&&T.delete(L.key===null?R:L.key),d=i(L,d,R),A===null?C=L:A.sibling=L,A=L);return e&&T.forEach(function(ie){return t(p,ie)}),Ne&&En(p,R),C}function f(p,d,g,S){var C=mr(g);if(typeof C!="function")throw Error(K(150));if(g=C.call(g),g==null)throw Error(K(151));for(var A=C=null,T=d,R=d=0,L=null,M=g.next();T!==null&&!M.done;R++,M=g.next()){T.index>R?(L=T,T=null):L=T.sibling;var ie=w(p,T,M.value,S);if(ie===null){T===null&&(T=L);break}e&&T&&ie.alternate===null&&t(p,T),d=i(ie,d,R),A===null?C=ie:A.sibling=ie,A=ie,T=L}if(M.done)return n(p,T),Ne&&En(p,R),C;if(T===null){for(;!M.done;R++,M=g.next())M=x(p,M.value,S),M!==null&&(d=i(M,d,R),A===null?C=M:A.sibling=M,A=M);return Ne&&En(p,R),C}for(T=r(p,T);!M.done;R++,M=g.next())M=h(T,p,R,M.value,S),M!==null&&(e&&M.alternate!==null&&T.delete(M.key===null?R:M.key),d=i(M,d,R),A===null?C=M:A.sibling=M,A=M);return e&&T.forEach(function(F){return t(p,F)}),Ne&&En(p,R),C}function v(p,d,g,S){if(typeof g=="object"&&g!==null&&g.type===Mn&&g.key===null&&(g=g.props.children),typeof g=="object"&&g!==null){switch(g.$$typeof){case xo:e:{for(var C=g.key,A=d;A!==null;){if(A.key===C){if(C=g.type,C===Mn){if(A.tag===7){n(p,A.sibling),d=o(A,g.props.children),d.return=p,p=d;break e}}else if(A.elementType===C||typeof C=="object"&&C!==null&&C.$$typeof===Xt&&Cu(C)===A.type){n(p,A.sibling),d=o(A,g.props),d.ref=Ur(p,A,g),d.return=p,p=d;break e}n(p,A);break}else t(p,A);A=A.sibling}g.type===Mn?(d=zn(g.props.children,p.mode,S,g.key),d.return=p,p=d):(S=bi(g.type,g.key,g.props,null,p.mode,S),S.ref=Ur(p,d,g),S.return=p,p=S)}return a(p);case On:e:{for(A=g.key;d!==null;){if(d.key===A)if(d.tag===4&&d.stateNode.containerInfo===g.containerInfo&&d.stateNode.implementation===g.implementation){n(p,d.sibling),d=o(d,g.children||[]),d.return=p,p=d;break e}else{n(p,d);break}else t(p,d);d=d.sibling}d=Jl(g,p.mode,S),d.return=p,p=d}return a(p);case Xt:return A=g._init,v(p,d,A(g._payload),S)}if(xr(g))return b(p,d,g,S);if(mr(g))return f(p,d,g,S);Xo(p,g)}return typeof g=="string"&&g!==""||typeof g=="number"?(g=""+g,d!==null&&d.tag===6?(n(p,d.sibling),d=o(d,g),d.return=p,p=d):(n(p,d),d=Kl(g,p.mode,S),d.return=p,p=d),a(p)):n(p,d)}return v}var nr=Eu(!0),Nu=Eu(!1),Ko=an(null),Jo=null,rr=null,ll=null;function sl(){ll=rr=Jo=null}function cl(e){var t=Ko.current;Ee(Ko),e._currentValue=t}function ul(e,t,n){for(;e!==null;){var r=e.alternate;if((e.childLanes&t)!==t?(e.childLanes|=t,r!==null&&(r.childLanes|=t)):r!==null&&(r.childLanes&t)!==t&&(r.childLanes|=t),e===n)break;e=e.return}}function or(e,t){Jo=e,ll=rr=null,e=e.dependencies,e!==null&&e.firstContext!==null&&(e.lanes&t&&(et=!0),e.firstContext=null)}function ft(e){var t=e._currentValue;if(ll!==e)if(e={context:e,memoizedValue:t,next:null},rr===null){if(Jo===null)throw Error(K(308));rr=e,Jo.dependencies={lanes:0,firstContext:e}}else rr=rr.next=e;return t}var Nn=null;function pl(e){Nn===null?Nn=[e]:Nn.push(e)}function ju(e,t,n,r){var o=t.interleaved;return o===null?(n.next=n,pl(t)):(n.next=o.next,o.next=n),t.interleaved=n,Ut(e,r)}function Ut(e,t){e.lanes|=t;var n=e.alternate;for(n!==null&&(n.lanes|=t),n=e,e=e.return;e!==null;)e.childLanes|=t,n=e.alternate,n!==null&&(n.childLanes|=t),n=e,e=e.return;return n.tag===3?n.stateNode:null}var cn=!1;function dl(e){e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,interleaved:null,lanes:0},effects:null}}function Fu(e,t){e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,effects:e.effects})}function Ht(e,t){return{eventTime:e,lane:t,tag:0,payload:null,callback:null,next:null}}function un(e,t,n){var r=e.updateQueue;if(r===null)return null;if(r=r.shared,ge&2){var o=r.pending;return o===null?t.next=t:(t.next=o.next,o.next=t),r.pending=t,Ut(e,n)}return o=r.interleaved,o===null?(t.next=t,pl(r)):(t.next=o.next,o.next=t),r.interleaved=t,Ut(e,n)}function qo(e,t,n){if(t=t.updateQueue,t!==null&&(t=t.shared,(n&4194240)!==0)){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,Ea(e,n)}}function Tu(e,t){var n=e.updateQueue,r=e.alternate;if(r!==null&&(r=r.updateQueue,n===r)){var o=null,i=null;if(n=n.firstBaseUpdate,n!==null){do{var a={eventTime:n.eventTime,lane:n.lane,tag:n.tag,payload:n.payload,callback:n.callback,next:null};i===null?o=i=a:i=i.next=a,n=n.next}while(n!==null);i===null?o=i=t:i=i.next=t}else o=i=t;n={baseState:r.baseState,firstBaseUpdate:o,lastBaseUpdate:i,shared:r.shared,effects:r.effects},e.updateQueue=n;return}e=n.lastBaseUpdate,e===null?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t}function ei(e,t,n,r){var o=e.updateQueue;cn=!1;var i=o.firstBaseUpdate,a=o.lastBaseUpdate,l=o.shared.pending;if(l!==null){o.shared.pending=null;var s=l,u=s.next;s.next=null,a===null?i=u:a.next=u,a=s;var y=e.alternate;y!==null&&(y=y.updateQueue,l=y.lastBaseUpdate,l!==a&&(l===null?y.firstBaseUpdate=u:l.next=u,y.lastBaseUpdate=s))}if(i!==null){var x=o.baseState;a=0,y=u=s=null,l=i;do{var w=l.lane,h=l.eventTime;if((r&w)===w){y!==null&&(y=y.next={eventTime:h,lane:0,tag:l.tag,payload:l.payload,callback:l.callback,next:null});e:{var b=e,f=l;switch(w=t,h=n,f.tag){case 1:if(b=f.payload,typeof b=="function"){x=b.call(h,x,w);break e}x=b;break e;case 3:b.flags=b.flags&-65537|128;case 0:if(b=f.payload,w=typeof b=="function"?b.call(h,x,w):b,w==null)break e;x=je({},x,w);break e;case 2:cn=!0}}l.callback!==null&&l.lane!==0&&(e.flags|=64,w=o.effects,w===null?o.effects=[l]:w.push(l))}else h={eventTime:h,lane:w,tag:l.tag,payload:l.payload,callback:l.callback,next:null},y===null?(u=y=h,s=x):y=y.next=h,a|=w;if(l=l.next,l===null){if(l=o.shared.pending,l===null)break;w=l,l=w.next,w.next=null,o.lastBaseUpdate=w,o.shared.pending=null}}while(!0);if(y===null&&(s=x),o.baseState=s,o.firstBaseUpdate=u,o.lastBaseUpdate=y,t=o.shared.interleaved,t!==null){o=t;do a|=o.lane,o=o.next;while(o!==t)}else i===null&&(o.shared.lanes=0);Tn|=a,e.lanes=a,e.memoizedState=x}}function Au(e,t,n){if(e=t.effects,t.effects=null,e!==null)for(t=0;t<e.length;t++){var r=e[t],o=r.callback;if(o!==null){if(r.callback=null,r=n,typeof o!="function")throw Error(K(191,o));o.call(r)}}}var Hr={},Tt=an(Hr),Wr=an(Hr),Vr=an(Hr);function jn(e){if(e===Hr)throw Error(K(174));return e}function fl(e,t){switch(Se(Vr,t),Se(Wr,e),Se(Tt,Hr),e=t.nodeType,e){case 9:case 11:t=(t=t.documentElement)?t.namespaceURI:ha(null,"");break;default:e=e===8?t.parentNode:t,t=e.namespaceURI||null,e=e.tagName,t=ha(t,e)}Ee(Tt),Se(Tt,t)}function ir(){Ee(Tt),Ee(Wr),Ee(Vr)}function Pu(e){jn(Vr.current);var t=jn(Tt.current),n=ha(t,e.type);t!==n&&(Se(Wr,e),Se(Tt,n))}function hl(e){Wr.current===e&&(Ee(Tt),Ee(Wr))}var Fe=an(0);function ti(e){for(var t=e;t!==null;){if(t.tag===13){var n=t.memoizedState;if(n!==null&&(n=n.dehydrated,n===null||n.data==="$?"||n.data==="$!"))return t}else if(t.tag===19&&t.memoizedProps.revealOrder!==void 0){if(t.flags&128)return t}else if(t.child!==null){t.child.return=t,t=t.child;continue}if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return null;t=t.return}t.sibling.return=t.return,t=t.sibling}return null}var ml=[];function gl(){for(var e=0;e<ml.length;e++)ml[e]._workInProgressVersionPrimary=null;ml.length=0}var ni=Dt.ReactCurrentDispatcher,xl=Dt.ReactCurrentBatchConfig,Fn=0,Te=null,Re=null,De=null,ri=!1,Gr=!1,Zr=0,Gh=0;function Ve(){throw Error(K(321))}function vl(e,t){if(t===null)return!1;for(var n=0;n<t.length&&n<e.length;n++)if(!wt(e[n],t[n]))return!1;return!0}function yl(e,t,n,r,o,i){if(Fn=i,Te=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,ni.current=e===null||e.memoizedState===null?Xh:Kh,e=n(r,o),Gr){i=0;do{if(Gr=!1,Zr=0,25<=i)throw Error(K(301));i+=1,De=Re=null,t.updateQueue=null,ni.current=Jh,e=n(r,o)}while(Gr)}if(ni.current=ai,t=Re!==null&&Re.next!==null,Fn=0,De=Re=Te=null,ri=!1,t)throw Error(K(300));return e}function bl(){var e=Zr!==0;return Zr=0,e}function At(){var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};return De===null?Te.memoizedState=De=e:De=De.next=e,De}function ht(){if(Re===null){var e=Te.alternate;e=e!==null?e.memoizedState:null}else e=Re.next;var t=De===null?Te.memoizedState:De.next;if(t!==null)De=t,Re=e;else{if(e===null)throw Error(K(310));Re=e,e={memoizedState:Re.memoizedState,baseState:Re.baseState,baseQueue:Re.baseQueue,queue:Re.queue,next:null},De===null?Te.memoizedState=De=e:De=De.next=e}return De}function Yr(e,t){return typeof t=="function"?t(e):t}function wl(e){var t=ht(),n=t.queue;if(n===null)throw Error(K(311));n.lastRenderedReducer=e;var r=Re,o=r.baseQueue,i=n.pending;if(i!==null){if(o!==null){var a=o.next;o.next=i.next,i.next=a}r.baseQueue=o=i,n.pending=null}if(o!==null){i=o.next,r=r.baseState;var l=a=null,s=null,u=i;do{var y=u.lane;if((Fn&y)===y)s!==null&&(s=s.next={lane:0,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null}),r=u.hasEagerState?u.eagerState:e(r,u.action);else{var x={lane:y,action:u.action,hasEagerState:u.hasEagerState,eagerState:u.eagerState,next:null};s===null?(l=s=x,a=r):s=s.next=x,Te.lanes|=y,Tn|=y}u=u.next}while(u!==null&&u!==i);s===null?a=r:s.next=l,wt(r,t.memoizedState)||(et=!0),t.memoizedState=r,t.baseState=a,t.baseQueue=s,n.lastRenderedState=r}if(e=n.interleaved,e!==null){o=e;do i=o.lane,Te.lanes|=i,Tn|=i,o=o.next;while(o!==e)}else o===null&&(n.lanes=0);return[t.memoizedState,n.dispatch]}function kl(e){var t=ht(),n=t.queue;if(n===null)throw Error(K(311));n.lastRenderedReducer=e;var r=n.dispatch,o=n.pending,i=t.memoizedState;if(o!==null){n.pending=null;var a=o=o.next;do i=e(i,a.action),a=a.next;while(a!==o);wt(i,t.memoizedState)||(et=!0),t.memoizedState=i,t.baseQueue===null&&(t.baseState=i),n.lastRenderedState=i}return[i,r]}function Iu(){}function zu(e,t){var n=Te,r=ht(),o=t(),i=!wt(r.memoizedState,o);if(i&&(r.memoizedState=o,et=!0),r=r.queue,Sl(Du.bind(null,n,r,e),[e]),r.getSnapshot!==t||i||De!==null&&De.memoizedState.tag&1){if(n.flags|=2048,Qr(9,Lu.bind(null,n,r,o,t),void 0,null),Oe===null)throw Error(K(349));Fn&30||Ru(n,t,o)}return o}function Ru(e,t,n){e.flags|=16384,e={getSnapshot:t,value:n},t=Te.updateQueue,t===null?(t={lastEffect:null,stores:null},Te.updateQueue=t,t.stores=[e]):(n=t.stores,n===null?t.stores=[e]:n.push(e))}function Lu(e,t,n,r){t.value=n,t.getSnapshot=r,Ou(t)&&Mu(e)}function Du(e,t,n){return n(function(){Ou(t)&&Mu(e)})}function Ou(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!wt(e,n)}catch{return!0}}function Mu(e){var t=Ut(e,1);t!==null&&Et(t,e,1,-1)}function Bu(e){var t=At();return typeof e=="function"&&(e=e()),t.memoizedState=t.baseState=e,e={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:Yr,lastRenderedState:e},t.queue=e,e=e.dispatch=Qh.bind(null,Te,e),[t.memoizedState,e]}function Qr(e,t,n,r){return e={tag:e,create:t,destroy:n,deps:r,next:null},t=Te.updateQueue,t===null?(t={lastEffect:null,stores:null},Te.updateQueue=t,t.lastEffect=e.next=e):(n=t.lastEffect,n===null?t.lastEffect=e.next=e:(r=n.next,n.next=e,e.next=r,t.lastEffect=e)),e}function $u(){return ht().memoizedState}function oi(e,t,n,r){var o=At();Te.flags|=e,o.memoizedState=Qr(1|t,n,void 0,r===void 0?null:r)}function ii(e,t,n,r){var o=ht();r=r===void 0?null:r;var i=void 0;if(Re!==null){var a=Re.memoizedState;if(i=a.destroy,r!==null&&vl(r,a.deps)){o.memoizedState=Qr(t,n,i,r);return}}Te.flags|=e,o.memoizedState=Qr(1|t,n,i,r)}function Uu(e,t){return oi(8390656,8,e,t)}function Sl(e,t){return ii(2048,8,e,t)}function Hu(e,t){return ii(4,2,e,t)}function Wu(e,t){return ii(4,4,e,t)}function Vu(e,t){if(typeof t=="function")return e=e(),t(e),function(){t(null)};if(t!=null)return e=e(),t.current=e,function(){t.current=null}}function Gu(e,t,n){return n=n!=null?n.concat([e]):null,ii(4,4,Vu.bind(null,t,e),n)}function _l(){}function Zu(e,t){var n=ht();t=t===void 0?null:t;var r=n.memoizedState;return r!==null&&t!==null&&vl(t,r[1])?r[0]:(n.memoizedState=[e,t],e)}function Yu(e,t){var n=ht();t=t===void 0?null:t;var r=n.memoizedState;return r!==null&&t!==null&&vl(t,r[1])?r[0]:(e=e(),n.memoizedState=[e,t],e)}function Qu(e,t,n){return Fn&21?(wt(n,t)||(n=Cc(),Te.lanes|=n,Tn|=n,e.baseState=!0),t):(e.baseState&&(e.baseState=!1,et=!0),e.memoizedState=n)}function Zh(e,t){var n=we;we=n!==0&&4>n?n:4,e(!0);var r=xl.transition;xl.transition={};try{e(!1),t()}finally{we=n,xl.transition=r}}function Xu(){return ht().memoizedState}function Yh(e,t,n){var r=hn(e);if(n={lane:r,action:n,hasEagerState:!1,eagerState:null,next:null},Ku(e))Ju(t,n);else if(n=ju(e,t,n,r),n!==null){var o=Ke();Et(n,e,r,o),qu(n,t,r)}}function Qh(e,t,n){var r=hn(e),o={lane:r,action:n,hasEagerState:!1,eagerState:null,next:null};if(Ku(e))Ju(t,o);else{var i=e.alternate;if(e.lanes===0&&(i===null||i.lanes===0)&&(i=t.lastRenderedReducer,i!==null))try{var a=t.lastRenderedState,l=i(a,n);if(o.hasEagerState=!0,o.eagerState=l,wt(l,a)){var s=t.interleaved;s===null?(o.next=o,pl(t)):(o.next=s.next,s.next=o),t.interleaved=o;return}}catch{}finally{}n=ju(e,t,o,r),n!==null&&(o=Ke(),Et(n,e,r,o),qu(n,t,r))}}function Ku(e){var t=e.alternate;return e===Te||t!==null&&t===Te}function Ju(e,t){Gr=ri=!0;var n=e.pending;n===null?t.next=t:(t.next=n.next,n.next=t),e.pending=t}function qu(e,t,n){if(n&4194240){var r=t.lanes;r&=e.pendingLanes,n|=r,t.lanes=n,Ea(e,n)}}var ai={readContext:ft,useCallback:Ve,useContext:Ve,useEffect:Ve,useImperativeHandle:Ve,useInsertionEffect:Ve,useLayoutEffect:Ve,useMemo:Ve,useReducer:Ve,useRef:Ve,useState:Ve,useDebugValue:Ve,useDeferredValue:Ve,useTransition:Ve,useMutableSource:Ve,useSyncExternalStore:Ve,useId:Ve,unstable_isNewReconciler:!1},Xh={readContext:ft,useCallback:function(e,t){return At().memoizedState=[e,t===void 0?null:t],e},useContext:ft,useEffect:Uu,useImperativeHandle:function(e,t,n){return n=n!=null?n.concat([e]):null,oi(4194308,4,Vu.bind(null,t,e),n)},useLayoutEffect:function(e,t){return oi(4194308,4,e,t)},useInsertionEffect:function(e,t){return oi(4,2,e,t)},useMemo:function(e,t){var n=At();return t=t===void 0?null:t,e=e(),n.memoizedState=[e,t],e},useReducer:function(e,t,n){var r=At();return t=n!==void 0?n(t):t,r.memoizedState=r.baseState=t,e={pending:null,interleaved:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:t},r.queue=e,e=e.dispatch=Yh.bind(null,Te,e),[r.memoizedState,e]},useRef:function(e){var t=At();return e={current:e},t.memoizedState=e},useState:Bu,useDebugValue:_l,useDeferredValue:function(e){return At().memoizedState=e},useTransition:function(){var e=Bu(!1),t=e[0];return e=Zh.bind(null,e[1]),At().memoizedState=e,[t,e]},useMutableSource:function(){},useSyncExternalStore:function(e,t,n){var r=Te,o=At();if(Ne){if(n===void 0)throw Error(K(407));n=n()}else{if(n=t(),Oe===null)throw Error(K(349));Fn&30||Ru(r,t,n)}o.memoizedState=n;var i={value:n,getSnapshot:t};return o.queue=i,Uu(Du.bind(null,r,i,e),[e]),r.flags|=2048,Qr(9,Lu.bind(null,r,i,n,t),void 0,null),n},useId:function(){var e=At(),t=Oe.identifierPrefix;if(Ne){var n=$t,r=Bt;n=(r&~(1<<32-bt(r)-1)).toString(32)+n,t=":"+t+"R"+n,n=Zr++,0<n&&(t+="H"+n.toString(32)),t+=":"}else n=Gh++,t=":"+t+"r"+n.toString(32)+":";return e.memoizedState=t},unstable_isNewReconciler:!1},Kh={readContext:ft,useCallback:Zu,useContext:ft,useEffect:Sl,useImperativeHandle:Gu,useInsertionEffect:Hu,useLayoutEffect:Wu,useMemo:Yu,useReducer:wl,useRef:$u,useState:function(){return wl(Yr)},useDebugValue:_l,useDeferredValue:function(e){var t=ht();return Qu(t,Re.memoizedState,e)},useTransition:function(){var e=wl(Yr)[0],t=ht().memoizedState;return[e,t]},useMutableSource:Iu,useSyncExternalStore:zu,useId:Xu,unstable_isNewReconciler:!1},Jh={readContext:ft,useCallback:Zu,useContext:ft,useEffect:Sl,useImperativeHandle:Gu,useInsertionEffect:Hu,useLayoutEffect:Wu,useMemo:Yu,useReducer:kl,useRef:$u,useState:function(){return kl(Yr)},useDebugValue:_l,useDeferredValue:function(e){var t=ht();return Re===null?t.memoizedState=e:Qu(t,Re.memoizedState,e)},useTransition:function(){var e=kl(Yr)[0],t=ht().memoizedState;return[e,t]},useMutableSource:Iu,useSyncExternalStore:zu,useId:Xu,unstable_isNewReconciler:!1};function St(e,t){if(e&&e.defaultProps){t=je({},t),e=e.defaultProps;for(var n in e)t[n]===void 0&&(t[n]=e[n]);return t}return t}function Cl(e,t,n,r){t=e.memoizedState,n=n(r,t),n=n==null?t:je({},t,n),e.memoizedState=n,e.lanes===0&&(e.updateQueue.baseState=n)}var li={isMounted:function(e){return(e=e._reactInternals)?kn(e)===e:!1},enqueueSetState:function(e,t,n){e=e._reactInternals;var r=Ke(),o=hn(e),i=Ht(r,o);i.payload=t,n!=null&&(i.callback=n),t=un(e,i,o),t!==null&&(Et(t,e,o,r),qo(t,e,o))},enqueueReplaceState:function(e,t,n){e=e._reactInternals;var r=Ke(),o=hn(e),i=Ht(r,o);i.tag=1,i.payload=t,n!=null&&(i.callback=n),t=un(e,i,o),t!==null&&(Et(t,e,o,r),qo(t,e,o))},enqueueForceUpdate:function(e,t){e=e._reactInternals;var n=Ke(),r=hn(e),o=Ht(n,r);o.tag=2,t!=null&&(o.callback=t),t=un(e,o,r),t!==null&&(Et(t,e,r,n),qo(t,e,r))}};function ep(e,t,n,r,o,i,a){return e=e.stateNode,typeof e.shouldComponentUpdate=="function"?e.shouldComponentUpdate(r,i,a):t.prototype&&t.prototype.isPureReactComponent?!Rr(n,r)||!Rr(o,i):!0}function tp(e,t,n){var r=!1,o=ln,i=t.contextType;return typeof i=="object"&&i!==null?i=ft(i):(o=qe(t)?_n:We.current,r=t.contextTypes,i=(r=r!=null)?Jn(e,o):ln),t=new t(n,i),e.memoizedState=t.state!==null&&t.state!==void 0?t.state:null,t.updater=li,e.stateNode=t,t._reactInternals=e,r&&(e=e.stateNode,e.__reactInternalMemoizedUnmaskedChildContext=o,e.__reactInternalMemoizedMaskedChildContext=i),t}function np(e,t,n,r){e=t.state,typeof t.componentWillReceiveProps=="function"&&t.componentWillReceiveProps(n,r),typeof t.UNSAFE_componentWillReceiveProps=="function"&&t.UNSAFE_componentWillReceiveProps(n,r),t.state!==e&&li.enqueueReplaceState(t,t.state,null)}function El(e,t,n,r){var o=e.stateNode;o.props=n,o.state=e.memoizedState,o.refs={},dl(e);var i=t.contextType;typeof i=="object"&&i!==null?o.context=ft(i):(i=qe(t)?_n:We.current,o.context=Jn(e,i)),o.state=e.memoizedState,i=t.getDerivedStateFromProps,typeof i=="function"&&(Cl(e,t,i,n),o.state=e.memoizedState),typeof t.getDerivedStateFromProps=="function"||typeof o.getSnapshotBeforeUpdate=="function"||typeof o.UNSAFE_componentWillMount!="function"&&typeof o.componentWillMount!="function"||(t=o.state,typeof o.componentWillMount=="function"&&o.componentWillMount(),typeof o.UNSAFE_componentWillMount=="function"&&o.UNSAFE_componentWillMount(),t!==o.state&&li.enqueueReplaceState(o,o.state,null),ei(e,n,o,r),o.state=e.memoizedState),typeof o.componentDidMount=="function"&&(e.flags|=4194308)}function ar(e,t){try{var n="",r=t;do n+=Ef(r),r=r.return;while(r);var o=n}catch(i){o=`
Error generating stack: `+i.message+`
`+i.stack}return{value:e,source:t,stack:o,digest:null}}function Nl(e,t,n){return{value:e,source:null,stack:n??null,digest:t??null}}function jl(e,t){try{console.error(t.value)}catch(n){setTimeout(function(){throw n})}}var qh=typeof WeakMap=="function"?WeakMap:Map;function rp(e,t,n){n=Ht(-1,n),n.tag=3,n.payload={element:null};var r=t.value;return n.callback=function(){hi||(hi=!0,Hl=r),jl(e,t)},n}function op(e,t,n){n=Ht(-1,n),n.tag=3;var r=e.type.getDerivedStateFromError;if(typeof r=="function"){var o=t.value;n.payload=function(){return r(o)},n.callback=function(){jl(e,t)}}var i=e.stateNode;return i!==null&&typeof i.componentDidCatch=="function"&&(n.callback=function(){jl(e,t),typeof r!="function"&&(dn===null?dn=new Set([this]):dn.add(this));var a=t.stack;this.componentDidCatch(t.value,{componentStack:a!==null?a:""})}),n}function ip(e,t,n){var r=e.pingCache;if(r===null){r=e.pingCache=new qh;var o=new Set;r.set(t,o)}else o=r.get(t),o===void 0&&(o=new Set,r.set(t,o));o.has(n)||(o.add(n),e=fm.bind(null,e,t,n),t.then(e,e))}function ap(e){do{var t;if((t=e.tag===13)&&(t=e.memoizedState,t=t!==null?t.dehydrated!==null:!0),t)return e;e=e.return}while(e!==null);return null}function lp(e,t,n,r,o){return e.mode&1?(e.flags|=65536,e.lanes=o,e):(e===t?e.flags|=65536:(e.flags|=128,n.flags|=131072,n.flags&=-52805,n.tag===1&&(n.alternate===null?n.tag=17:(t=Ht(-1,1),t.tag=2,un(n,t,1))),n.lanes|=1),e)}var em=Dt.ReactCurrentOwner,et=!1;function Xe(e,t,n,r){t.child=e===null?Nu(t,null,n,r):nr(t,e.child,n,r)}function sp(e,t,n,r,o){n=n.render;var i=t.ref;return or(t,o),r=yl(e,t,n,r,i,o),n=bl(),e!==null&&!et?(t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~o,Wt(e,t,o)):(Ne&&n&&nl(t),t.flags|=1,Xe(e,t,r,o),t.child)}function cp(e,t,n,r,o){if(e===null){var i=n.type;return typeof i=="function"&&!Xl(i)&&i.defaultProps===void 0&&n.compare===null&&n.defaultProps===void 0?(t.tag=15,t.type=i,up(e,t,i,r,o)):(e=bi(n.type,null,r,t,t.mode,o),e.ref=t.ref,e.return=t,t.child=e)}if(i=e.child,!(e.lanes&o)){var a=i.memoizedProps;if(n=n.compare,n=n!==null?n:Rr,n(a,r)&&e.ref===t.ref)return Wt(e,t,o)}return t.flags|=1,e=gn(i,r),e.ref=t.ref,e.return=t,t.child=e}function up(e,t,n,r,o){if(e!==null){var i=e.memoizedProps;if(Rr(i,r)&&e.ref===t.ref)if(et=!1,t.pendingProps=r=i,(e.lanes&o)!==0)e.flags&131072&&(et=!0);else return t.lanes=e.lanes,Wt(e,t,o)}return Fl(e,t,n,r,o)}function pp(e,t,n){var r=t.pendingProps,o=r.children,i=e!==null?e.memoizedState:null;if(r.mode==="hidden")if(!(t.mode&1))t.memoizedState={baseLanes:0,cachePool:null,transitions:null},Se(sr,ct),ct|=n;else{if(!(n&1073741824))return e=i!==null?i.baseLanes|n:n,t.lanes=t.childLanes=1073741824,t.memoizedState={baseLanes:e,cachePool:null,transitions:null},t.updateQueue=null,Se(sr,ct),ct|=e,null;t.memoizedState={baseLanes:0,cachePool:null,transitions:null},r=i!==null?i.baseLanes:n,Se(sr,ct),ct|=r}else i!==null?(r=i.baseLanes|n,t.memoizedState=null):r=n,Se(sr,ct),ct|=r;return Xe(e,t,o,n),t.child}function dp(e,t){var n=t.ref;(e===null&&n!==null||e!==null&&e.ref!==n)&&(t.flags|=512,t.flags|=2097152)}function Fl(e,t,n,r,o){var i=qe(n)?_n:We.current;return i=Jn(t,i),or(t,o),n=yl(e,t,n,r,i,o),r=bl(),e!==null&&!et?(t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~o,Wt(e,t,o)):(Ne&&r&&nl(t),t.flags|=1,Xe(e,t,n,o),t.child)}function fp(e,t,n,r,o){if(qe(n)){var i=!0;Vo(t)}else i=!1;if(or(t,o),t.stateNode===null)ci(e,t),tp(t,n,r),El(t,n,r,o),r=!0;else if(e===null){var a=t.stateNode,l=t.memoizedProps;a.props=l;var s=a.context,u=n.contextType;typeof u=="object"&&u!==null?u=ft(u):(u=qe(n)?_n:We.current,u=Jn(t,u));var y=n.getDerivedStateFromProps,x=typeof y=="function"||typeof a.getSnapshotBeforeUpdate=="function";x||typeof a.UNSAFE_componentWillReceiveProps!="function"&&typeof a.componentWillReceiveProps!="function"||(l!==r||s!==u)&&np(t,a,r,u),cn=!1;var w=t.memoizedState;a.state=w,ei(t,r,a,o),s=t.memoizedState,l!==r||w!==s||Je.current||cn?(typeof y=="function"&&(Cl(t,n,y,r),s=t.memoizedState),(l=cn||ep(t,n,l,r,w,s,u))?(x||typeof a.UNSAFE_componentWillMount!="function"&&typeof a.componentWillMount!="function"||(typeof a.componentWillMount=="function"&&a.componentWillMount(),typeof a.UNSAFE_componentWillMount=="function"&&a.UNSAFE_componentWillMount()),typeof a.componentDidMount=="function"&&(t.flags|=4194308)):(typeof a.componentDidMount=="function"&&(t.flags|=4194308),t.memoizedProps=r,t.memoizedState=s),a.props=r,a.state=s,a.context=u,r=l):(typeof a.componentDidMount=="function"&&(t.flags|=4194308),r=!1)}else{a=t.stateNode,Fu(e,t),l=t.memoizedProps,u=t.type===t.elementType?l:St(t.type,l),a.props=u,x=t.pendingProps,w=a.context,s=n.contextType,typeof s=="object"&&s!==null?s=ft(s):(s=qe(n)?_n:We.current,s=Jn(t,s));var h=n.getDerivedStateFromProps;(y=typeof h=="function"||typeof a.getSnapshotBeforeUpdate=="function")||typeof a.UNSAFE_componentWillReceiveProps!="function"&&typeof a.componentWillReceiveProps!="function"||(l!==x||w!==s)&&np(t,a,r,s),cn=!1,w=t.memoizedState,a.state=w,ei(t,r,a,o);var b=t.memoizedState;l!==x||w!==b||Je.current||cn?(typeof h=="function"&&(Cl(t,n,h,r),b=t.memoizedState),(u=cn||ep(t,n,u,r,w,b,s)||!1)?(y||typeof a.UNSAFE_componentWillUpdate!="function"&&typeof a.componentWillUpdate!="function"||(typeof a.componentWillUpdate=="function"&&a.componentWillUpdate(r,b,s),typeof a.UNSAFE_componentWillUpdate=="function"&&a.UNSAFE_componentWillUpdate(r,b,s)),typeof a.componentDidUpdate=="function"&&(t.flags|=4),typeof a.getSnapshotBeforeUpdate=="function"&&(t.flags|=1024)):(typeof a.componentDidUpdate!="function"||l===e.memoizedProps&&w===e.memoizedState||(t.flags|=4),typeof a.getSnapshotBeforeUpdate!="function"||l===e.memoizedProps&&w===e.memoizedState||(t.flags|=1024),t.memoizedProps=r,t.memoizedState=b),a.props=r,a.state=b,a.context=s,r=u):(typeof a.componentDidUpdate!="function"||l===e.memoizedProps&&w===e.memoizedState||(t.flags|=4),typeof a.getSnapshotBeforeUpdate!="function"||l===e.memoizedProps&&w===e.memoizedState||(t.flags|=1024),r=!1)}return Tl(e,t,n,r,i,o)}function Tl(e,t,n,r,o,i){dp(e,t);var a=(t.flags&128)!==0;if(!r&&!a)return o&&vu(t,n,!1),Wt(e,t,i);r=t.stateNode,em.current=t;var l=a&&typeof n.getDerivedStateFromError!="function"?null:r.render();return t.flags|=1,e!==null&&a?(t.child=nr(t,e.child,null,i),t.child=nr(t,null,l,i)):Xe(e,t,l,i),t.memoizedState=r.state,o&&vu(t,n,!0),t.child}function hp(e){var t=e.stateNode;t.pendingContext?gu(e,t.pendingContext,t.pendingContext!==t.context):t.context&&gu(e,t.context,!1),fl(e,t.containerInfo)}function mp(e,t,n,r,o){return tr(),al(o),t.flags|=256,Xe(e,t,n,r),t.child}var Al={dehydrated:null,treeContext:null,retryLane:0};function Pl(e){return{baseLanes:e,cachePool:null,transitions:null}}function gp(e,t,n){var r=t.pendingProps,o=Fe.current,i=!1,a=(t.flags&128)!==0,l;if((l=a)||(l=e!==null&&e.memoizedState===null?!1:(o&2)!==0),l?(i=!0,t.flags&=-129):(e===null||e.memoizedState!==null)&&(o|=1),Se(Fe,o&1),e===null)return il(t),e=t.memoizedState,e!==null&&(e=e.dehydrated,e!==null)?(t.mode&1?e.data==="$!"?t.lanes=8:t.lanes=1073741824:t.lanes=1,null):(a=r.children,e=r.fallback,i?(r=t.mode,i=t.child,a={mode:"hidden",children:a},!(r&1)&&i!==null?(i.childLanes=0,i.pendingProps=a):i=wi(a,r,0,null),e=zn(e,r,n,null),i.return=t,e.return=t,i.sibling=e,t.child=i,t.child.memoizedState=Pl(n),t.memoizedState=Al,e):Il(t,a));if(o=e.memoizedState,o!==null&&(l=o.dehydrated,l!==null))return tm(e,t,a,r,l,o,n);if(i){i=r.fallback,a=t.mode,o=e.child,l=o.sibling;var s={mode:"hidden",children:r.children};return!(a&1)&&t.child!==o?(r=t.child,r.childLanes=0,r.pendingProps=s,t.deletions=null):(r=gn(o,s),r.subtreeFlags=o.subtreeFlags&14680064),l!==null?i=gn(l,i):(i=zn(i,a,n,null),i.flags|=2),i.return=t,r.return=t,r.sibling=i,t.child=r,r=i,i=t.child,a=e.child.memoizedState,a=a===null?Pl(n):{baseLanes:a.baseLanes|n,cachePool:null,transitions:a.transitions},i.memoizedState=a,i.childLanes=e.childLanes&~n,t.memoizedState=Al,r}return i=e.child,e=i.sibling,r=gn(i,{mode:"visible",children:r.children}),!(t.mode&1)&&(r.lanes=n),r.return=t,r.sibling=null,e!==null&&(n=t.deletions,n===null?(t.deletions=[e],t.flags|=16):n.push(e)),t.child=r,t.memoizedState=null,r}function Il(e,t){return t=wi({mode:"visible",children:t},e.mode,0,null),t.return=e,e.child=t}function si(e,t,n,r){return r!==null&&al(r),nr(t,e.child,null,n),e=Il(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e}function tm(e,t,n,r,o,i,a){if(n)return t.flags&256?(t.flags&=-257,r=Nl(Error(K(422))),si(e,t,a,r)):t.memoizedState!==null?(t.child=e.child,t.flags|=128,null):(i=r.fallback,o=t.mode,r=wi({mode:"visible",children:r.children},o,0,null),i=zn(i,o,a,null),i.flags|=2,r.return=t,i.return=t,r.sibling=i,t.child=r,t.mode&1&&nr(t,e.child,null,a),t.child.memoizedState=Pl(a),t.memoizedState=Al,i);if(!(t.mode&1))return si(e,t,a,null);if(o.data==="$!"){if(r=o.nextSibling&&o.nextSibling.dataset,r)var l=r.dgst;return r=l,i=Error(K(419)),r=Nl(i,r,void 0),si(e,t,a,r)}if(l=(a&e.childLanes)!==0,et||l){if(r=Oe,r!==null){switch(a&-a){case 4:o=2;break;case 16:o=8;break;case 64:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 16777216:case 33554432:case 67108864:o=32;break;case 536870912:o=268435456;break;default:o=0}o=o&(r.suspendedLanes|a)?0:o,o!==0&&o!==i.retryLane&&(i.retryLane=o,Ut(e,o),Et(r,e,o,-1))}return Ql(),r=Nl(Error(K(421))),si(e,t,a,r)}return o.data==="$?"?(t.flags|=128,t.child=e.child,t=hm.bind(null,e),o._reactRetry=t,null):(e=i.treeContext,st=on(o.nextSibling),lt=t,Ne=!0,kt=null,e!==null&&(pt[dt++]=Bt,pt[dt++]=$t,pt[dt++]=Cn,Bt=e.id,$t=e.overflow,Cn=t),t=Il(t,r.children),t.flags|=4096,t)}function xp(e,t,n){e.lanes|=t;var r=e.alternate;r!==null&&(r.lanes|=t),ul(e.return,t,n)}function zl(e,t,n,r,o){var i=e.memoizedState;i===null?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:r,tail:n,tailMode:o}:(i.isBackwards=t,i.rendering=null,i.renderingStartTime=0,i.last=r,i.tail=n,i.tailMode=o)}function vp(e,t,n){var r=t.pendingProps,o=r.revealOrder,i=r.tail;if(Xe(e,t,r.children,n),r=Fe.current,r&2)r=r&1|2,t.flags|=128;else{if(e!==null&&e.flags&128)e:for(e=t.child;e!==null;){if(e.tag===13)e.memoizedState!==null&&xp(e,n,t);else if(e.tag===19)xp(e,n,t);else if(e.child!==null){e.child.return=e,e=e.child;continue}if(e===t)break e;for(;e.sibling===null;){if(e.return===null||e.return===t)break e;e=e.return}e.sibling.return=e.return,e=e.sibling}r&=1}if(Se(Fe,r),!(t.mode&1))t.memoizedState=null;else switch(o){case"forwards":for(n=t.child,o=null;n!==null;)e=n.alternate,e!==null&&ti(e)===null&&(o=n),n=n.sibling;n=o,n===null?(o=t.child,t.child=null):(o=n.sibling,n.sibling=null),zl(t,!1,o,n,i);break;case"backwards":for(n=null,o=t.child,t.child=null;o!==null;){if(e=o.alternate,e!==null&&ti(e)===null){t.child=o;break}e=o.sibling,o.sibling=n,n=o,o=e}zl(t,!0,n,null,i);break;case"together":zl(t,!1,null,null,void 0);break;default:t.memoizedState=null}return t.child}function ci(e,t){!(t.mode&1)&&e!==null&&(e.alternate=null,t.alternate=null,t.flags|=2)}function Wt(e,t,n){if(e!==null&&(t.dependencies=e.dependencies),Tn|=t.lanes,!(n&t.childLanes))return null;if(e!==null&&t.child!==e.child)throw Error(K(153));if(t.child!==null){for(e=t.child,n=gn(e,e.pendingProps),t.child=n,n.return=t;e.sibling!==null;)e=e.sibling,n=n.sibling=gn(e,e.pendingProps),n.return=t;n.sibling=null}return t.child}function nm(e,t,n){switch(t.tag){case 3:hp(t),tr();break;case 5:Pu(t);break;case 1:qe(t.type)&&Vo(t);break;case 4:fl(t,t.stateNode.containerInfo);break;case 10:var r=t.type._context,o=t.memoizedProps.value;Se(Ko,r._currentValue),r._currentValue=o;break;case 13:if(r=t.memoizedState,r!==null)return r.dehydrated!==null?(Se(Fe,Fe.current&1),t.flags|=128,null):n&t.child.childLanes?gp(e,t,n):(Se(Fe,Fe.current&1),e=Wt(e,t,n),e!==null?e.sibling:null);Se(Fe,Fe.current&1);break;case 19:if(r=(n&t.childLanes)!==0,e.flags&128){if(r)return vp(e,t,n);t.flags|=128}if(o=t.memoizedState,o!==null&&(o.rendering=null,o.tail=null,o.lastEffect=null),Se(Fe,Fe.current),r)break;return null;case 22:case 23:return t.lanes=0,pp(e,t,n)}return Wt(e,t,n)}var yp,Rl,bp,wp;yp=function(e,t){for(var n=t.child;n!==null;){if(n.tag===5||n.tag===6)e.appendChild(n.stateNode);else if(n.tag!==4&&n.child!==null){n.child.return=n,n=n.child;continue}if(n===t)break;for(;n.sibling===null;){if(n.return===null||n.return===t)return;n=n.return}n.sibling.return=n.return,n=n.sibling}},Rl=function(){},bp=function(e,t,n,r){var o=e.memoizedProps;if(o!==r){e=t.stateNode,jn(Tt.current);var i=null;switch(n){case"input":o=ua(e,o),r=ua(e,r),i=[];break;case"select":o=je({},o,{value:void 0}),r=je({},r,{value:void 0}),i=[];break;case"textarea":o=fa(e,o),r=fa(e,r),i=[];break;default:typeof o.onClick!="function"&&typeof r.onClick=="function"&&(e.onclick=Uo)}ma(n,r);var a;n=null;for(u in o)if(!r.hasOwnProperty(u)&&o.hasOwnProperty(u)&&o[u]!=null)if(u==="style"){var l=o[u];for(a in l)l.hasOwnProperty(a)&&(n||(n={}),n[a]="")}else u!=="dangerouslySetInnerHTML"&&u!=="children"&&u!=="suppressContentEditableWarning"&&u!=="suppressHydrationWarning"&&u!=="autoFocus"&&(hr.hasOwnProperty(u)?i||(i=[]):(i=i||[]).push(u,null));for(u in r){var s=r[u];if(l=o?.[u],r.hasOwnProperty(u)&&s!==l&&(s!=null||l!=null))if(u==="style")if(l){for(a in l)!l.hasOwnProperty(a)||s&&s.hasOwnProperty(a)||(n||(n={}),n[a]="");for(a in s)s.hasOwnProperty(a)&&l[a]!==s[a]&&(n||(n={}),n[a]=s[a])}else n||(i||(i=[]),i.push(u,n)),n=s;else u==="dangerouslySetInnerHTML"?(s=s?s.__html:void 0,l=l?l.__html:void 0,s!=null&&l!==s&&(i=i||[]).push(u,s)):u==="children"?typeof s!="string"&&typeof s!="number"||(i=i||[]).push(u,""+s):u!=="suppressContentEditableWarning"&&u!=="suppressHydrationWarning"&&(hr.hasOwnProperty(u)?(s!=null&&u==="onScroll"&&Ce("scroll",e),i||l===s||(i=[])):(i=i||[]).push(u,s))}n&&(i=i||[]).push("style",n);var u=i;(t.updateQueue=u)&&(t.flags|=4)}},wp=function(e,t,n,r){n!==r&&(t.flags|=4)};function Xr(e,t){if(!Ne)switch(e.tailMode){case"hidden":t=e.tail;for(var n=null;t!==null;)t.alternate!==null&&(n=t),t=t.sibling;n===null?e.tail=null:n.sibling=null;break;case"collapsed":n=e.tail;for(var r=null;n!==null;)n.alternate!==null&&(r=n),n=n.sibling;r===null?t||e.tail===null?e.tail=null:e.tail.sibling=null:r.sibling=null}}function Ge(e){var t=e.alternate!==null&&e.alternate.child===e.child,n=0,r=0;if(t)for(var o=e.child;o!==null;)n|=o.lanes|o.childLanes,r|=o.subtreeFlags&14680064,r|=o.flags&14680064,o.return=e,o=o.sibling;else for(o=e.child;o!==null;)n|=o.lanes|o.childLanes,r|=o.subtreeFlags,r|=o.flags,o.return=e,o=o.sibling;return e.subtreeFlags|=r,e.childLanes=n,t}function rm(e,t,n){var r=t.pendingProps;switch(rl(t),t.tag){case 2:case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:return Ge(t),null;case 1:return qe(t.type)&&Wo(),Ge(t),null;case 3:return r=t.stateNode,ir(),Ee(Je),Ee(We),gl(),r.pendingContext&&(r.context=r.pendingContext,r.pendingContext=null),(e===null||e.child===null)&&(Qo(t)?t.flags|=4:e===null||e.memoizedState.isDehydrated&&!(t.flags&256)||(t.flags|=1024,kt!==null&&(Gl(kt),kt=null))),Rl(e,t),Ge(t),null;case 5:hl(t);var o=jn(Vr.current);if(n=t.type,e!==null&&t.stateNode!=null)bp(e,t,n,r,o),e.ref!==t.ref&&(t.flags|=512,t.flags|=2097152);else{if(!r){if(t.stateNode===null)throw Error(K(166));return Ge(t),null}if(e=jn(Tt.current),Qo(t)){r=t.stateNode,n=t.type;var i=t.memoizedProps;switch(r[Ft]=t,r[Br]=i,e=(t.mode&1)!==0,n){case"dialog":Ce("cancel",r),Ce("close",r);break;case"iframe":case"object":case"embed":Ce("load",r);break;case"video":case"audio":for(o=0;o<Dr.length;o++)Ce(Dr[o],r);break;case"source":Ce("error",r);break;case"img":case"image":case"link":Ce("error",r),Ce("load",r);break;case"details":Ce("toggle",r);break;case"input":tc(r,i),Ce("invalid",r);break;case"select":r._wrapperState={wasMultiple:!!i.multiple},Ce("invalid",r);break;case"textarea":oc(r,i),Ce("invalid",r)}ma(n,i),o=null;for(var a in i)if(i.hasOwnProperty(a)){var l=i[a];a==="children"?typeof l=="string"?r.textContent!==l&&(i.suppressHydrationWarning!==!0&&$o(r.textContent,l,e),o=["children",l]):typeof l=="number"&&r.textContent!==""+l&&(i.suppressHydrationWarning!==!0&&$o(r.textContent,l,e),o=["children",""+l]):hr.hasOwnProperty(a)&&l!=null&&a==="onScroll"&&Ce("scroll",r)}switch(n){case"input":vo(r),rc(r,i,!0);break;case"textarea":vo(r),ac(r);break;case"select":case"option":break;default:typeof i.onClick=="function"&&(r.onclick=Uo)}r=o,t.updateQueue=r,r!==null&&(t.flags|=4)}else{a=o.nodeType===9?o:o.ownerDocument,e==="http://www.w3.org/1999/xhtml"&&(e=lc(n)),e==="http://www.w3.org/1999/xhtml"?n==="script"?(e=a.createElement("div"),e.innerHTML="<script><\/script>",e=e.removeChild(e.firstChild)):typeof r.is=="string"?e=a.createElement(n,{is:r.is}):(e=a.createElement(n),n==="select"&&(a=e,r.multiple?a.multiple=!0:r.size&&(a.size=r.size))):e=a.createElementNS(e,n),e[Ft]=t,e[Br]=r,yp(e,t,!1,!1),t.stateNode=e;e:{switch(a=ga(n,r),n){case"dialog":Ce("cancel",e),Ce("close",e),o=r;break;case"iframe":case"object":case"embed":Ce("load",e),o=r;break;case"video":case"audio":for(o=0;o<Dr.length;o++)Ce(Dr[o],e);o=r;break;case"source":Ce("error",e),o=r;break;case"img":case"image":case"link":Ce("error",e),Ce("load",e),o=r;break;case"details":Ce("toggle",e),o=r;break;case"input":tc(e,r),o=ua(e,r),Ce("invalid",e);break;case"option":o=r;break;case"select":e._wrapperState={wasMultiple:!!r.multiple},o=je({},r,{value:void 0}),Ce("invalid",e);break;case"textarea":oc(e,r),o=fa(e,r),Ce("invalid",e);break;default:o=r}ma(n,o),l=o;for(i in l)if(l.hasOwnProperty(i)){var s=l[i];i==="style"?uc(e,s):i==="dangerouslySetInnerHTML"?(s=s?s.__html:void 0,s!=null&&sc(e,s)):i==="children"?typeof s=="string"?(n!=="textarea"||s!=="")&&vr(e,s):typeof s=="number"&&vr(e,""+s):i!=="suppressContentEditableWarning"&&i!=="suppressHydrationWarning"&&i!=="autoFocus"&&(hr.hasOwnProperty(i)?s!=null&&i==="onScroll"&&Ce("scroll",e):s!=null&&qi(e,i,s,a))}switch(n){case"input":vo(e),rc(e,r,!1);break;case"textarea":vo(e),ac(e);break;case"option":r.value!=null&&e.setAttribute("value",""+Kt(r.value));break;case"select":e.multiple=!!r.multiple,i=r.value,i!=null?Bn(e,!!r.multiple,i,!1):r.defaultValue!=null&&Bn(e,!!r.multiple,r.defaultValue,!0);break;default:typeof o.onClick=="function"&&(e.onclick=Uo)}switch(n){case"button":case"input":case"select":case"textarea":r=!!r.autoFocus;break e;case"img":r=!0;break e;default:r=!1}}r&&(t.flags|=4)}t.ref!==null&&(t.flags|=512,t.flags|=2097152)}return Ge(t),null;case 6:if(e&&t.stateNode!=null)wp(e,t,e.memoizedProps,r);else{if(typeof r!="string"&&t.stateNode===null)throw Error(K(166));if(n=jn(Vr.current),jn(Tt.current),Qo(t)){if(r=t.stateNode,n=t.memoizedProps,r[Ft]=t,(i=r.nodeValue!==n)&&(e=lt,e!==null))switch(e.tag){case 3:$o(r.nodeValue,n,(e.mode&1)!==0);break;case 5:e.memoizedProps.suppressHydrationWarning!==!0&&$o(r.nodeValue,n,(e.mode&1)!==0)}i&&(t.flags|=4)}else r=(n.nodeType===9?n:n.ownerDocument).createTextNode(r),r[Ft]=t,t.stateNode=r}return Ge(t),null;case 13:if(Ee(Fe),r=t.memoizedState,e===null||e.memoizedState!==null&&e.memoizedState.dehydrated!==null){if(Ne&&st!==null&&t.mode&1&&!(t.flags&128))_u(),tr(),t.flags|=98560,i=!1;else if(i=Qo(t),r!==null&&r.dehydrated!==null){if(e===null){if(!i)throw Error(K(318));if(i=t.memoizedState,i=i!==null?i.dehydrated:null,!i)throw Error(K(317));i[Ft]=t}else tr(),!(t.flags&128)&&(t.memoizedState=null),t.flags|=4;Ge(t),i=!1}else kt!==null&&(Gl(kt),kt=null),i=!0;if(!i)return t.flags&65536?t:null}return t.flags&128?(t.lanes=n,t):(r=r!==null,r!==(e!==null&&e.memoizedState!==null)&&r&&(t.child.flags|=8192,t.mode&1&&(e===null||Fe.current&1?Le===0&&(Le=3):Ql())),t.updateQueue!==null&&(t.flags|=4),Ge(t),null);case 4:return ir(),Rl(e,t),e===null&&Or(t.stateNode.containerInfo),Ge(t),null;case 10:return cl(t.type._context),Ge(t),null;case 17:return qe(t.type)&&Wo(),Ge(t),null;case 19:if(Ee(Fe),i=t.memoizedState,i===null)return Ge(t),null;if(r=(t.flags&128)!==0,a=i.rendering,a===null)if(r)Xr(i,!1);else{if(Le!==0||e!==null&&e.flags&128)for(e=t.child;e!==null;){if(a=ti(e),a!==null){for(t.flags|=128,Xr(i,!1),r=a.updateQueue,r!==null&&(t.updateQueue=r,t.flags|=4),t.subtreeFlags=0,r=n,n=t.child;n!==null;)i=n,e=r,i.flags&=14680066,a=i.alternate,a===null?(i.childLanes=0,i.lanes=e,i.child=null,i.subtreeFlags=0,i.memoizedProps=null,i.memoizedState=null,i.updateQueue=null,i.dependencies=null,i.stateNode=null):(i.childLanes=a.childLanes,i.lanes=a.lanes,i.child=a.child,i.subtreeFlags=0,i.deletions=null,i.memoizedProps=a.memoizedProps,i.memoizedState=a.memoizedState,i.updateQueue=a.updateQueue,i.type=a.type,e=a.dependencies,i.dependencies=e===null?null:{lanes:e.lanes,firstContext:e.firstContext}),n=n.sibling;return Se(Fe,Fe.current&1|2),t.child}e=e.sibling}i.tail!==null&&Pe()>cr&&(t.flags|=128,r=!0,Xr(i,!1),t.lanes=4194304)}else{if(!r)if(e=ti(a),e!==null){if(t.flags|=128,r=!0,n=e.updateQueue,n!==null&&(t.updateQueue=n,t.flags|=4),Xr(i,!0),i.tail===null&&i.tailMode==="hidden"&&!a.alternate&&!Ne)return Ge(t),null}else 2*Pe()-i.renderingStartTime>cr&&n!==1073741824&&(t.flags|=128,r=!0,Xr(i,!1),t.lanes=4194304);i.isBackwards?(a.sibling=t.child,t.child=a):(n=i.last,n!==null?n.sibling=a:t.child=a,i.last=a)}return i.tail!==null?(t=i.tail,i.rendering=t,i.tail=t.sibling,i.renderingStartTime=Pe(),t.sibling=null,n=Fe.current,Se(Fe,r?n&1|2:n&1),t):(Ge(t),null);case 22:case 23:return Yl(),r=t.memoizedState!==null,e!==null&&e.memoizedState!==null!==r&&(t.flags|=8192),r&&t.mode&1?ct&1073741824&&(Ge(t),t.subtreeFlags&6&&(t.flags|=8192)):Ge(t),null;case 24:return null;case 25:return null}throw Error(K(156,t.tag))}function om(e,t){switch(rl(t),t.tag){case 1:return qe(t.type)&&Wo(),e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 3:return ir(),Ee(Je),Ee(We),gl(),e=t.flags,e&65536&&!(e&128)?(t.flags=e&-65537|128,t):null;case 5:return hl(t),null;case 13:if(Ee(Fe),e=t.memoizedState,e!==null&&e.dehydrated!==null){if(t.alternate===null)throw Error(K(340));tr()}return e=t.flags,e&65536?(t.flags=e&-65537|128,t):null;case 19:return Ee(Fe),null;case 4:return ir(),null;case 10:return cl(t.type._context),null;case 22:case 23:return Yl(),null;case 24:return null;default:return null}}var ui=!1,Ze=!1,im=typeof WeakSet=="function"?WeakSet:Set,ae=null;function lr(e,t){var n=e.ref;if(n!==null)if(typeof n=="function")try{n(null)}catch(r){Ae(e,t,r)}else n.current=null}function Ll(e,t,n){try{n()}catch(r){Ae(e,t,r)}}var kp=!1;function am(e,t){if(Ya=To,e=eu(),Ba(e)){if("selectionStart"in e)var n={start:e.selectionStart,end:e.selectionEnd};else e:{n=(n=e.ownerDocument)&&n.defaultView||window;var r=n.getSelection&&n.getSelection();if(r&&r.rangeCount!==0){n=r.anchorNode;var o=r.anchorOffset,i=r.focusNode;r=r.focusOffset;try{n.nodeType,i.nodeType}catch{n=null;break e}var a=0,l=-1,s=-1,u=0,y=0,x=e,w=null;t:for(;;){for(var h;x!==n||o!==0&&x.nodeType!==3||(l=a+o),x!==i||r!==0&&x.nodeType!==3||(s=a+r),x.nodeType===3&&(a+=x.nodeValue.length),(h=x.firstChild)!==null;)w=x,x=h;for(;;){if(x===e)break t;if(w===n&&++u===o&&(l=a),w===i&&++y===r&&(s=a),(h=x.nextSibling)!==null)break;x=w,w=x.parentNode}x=h}n=l===-1||s===-1?null:{start:l,end:s}}else n=null}n=n||{start:0,end:0}}else n=null;for(Qa={focusedElem:e,selectionRange:n},To=!1,ae=t;ae!==null;)if(t=ae,e=t.child,(t.subtreeFlags&1028)!==0&&e!==null)e.return=t,ae=e;else for(;ae!==null;){t=ae;try{var b=t.alternate;if(t.flags&1024)switch(t.tag){case 0:case 11:case 15:break;case 1:if(b!==null){var f=b.memoizedProps,v=b.memoizedState,p=t.stateNode,d=p.getSnapshotBeforeUpdate(t.elementType===t.type?f:St(t.type,f),v);p.__reactInternalSnapshotBeforeUpdate=d}break;case 3:var g=t.stateNode.containerInfo;g.nodeType===1?g.textContent="":g.nodeType===9&&g.documentElement&&g.removeChild(g.documentElement);break;case 5:case 6:case 4:case 17:break;default:throw Error(K(163))}}catch(S){Ae(t,t.return,S)}if(e=t.sibling,e!==null){e.return=t.return,ae=e;break}ae=t.return}return b=kp,kp=!1,b}function Kr(e,t,n){var r=t.updateQueue;if(r=r!==null?r.lastEffect:null,r!==null){var o=r=r.next;do{if((o.tag&e)===e){var i=o.destroy;o.destroy=void 0,i!==void 0&&Ll(t,n,i)}o=o.next}while(o!==r)}}function pi(e,t){if(t=t.updateQueue,t=t!==null?t.lastEffect:null,t!==null){var n=t=t.next;do{if((n.tag&e)===e){var r=n.create;n.destroy=r()}n=n.next}while(n!==t)}}function Dl(e){var t=e.ref;if(t!==null){var n=e.stateNode;switch(e.tag){case 5:e=n;break;default:e=n}typeof t=="function"?t(e):t.current=e}}function Sp(e){var t=e.alternate;t!==null&&(e.alternate=null,Sp(t)),e.child=null,e.deletions=null,e.sibling=null,e.tag===5&&(t=e.stateNode,t!==null&&(delete t[Ft],delete t[Br],delete t[qa],delete t[Uh],delete t[Hh])),e.stateNode=null,e.return=null,e.dependencies=null,e.memoizedProps=null,e.memoizedState=null,e.pendingProps=null,e.stateNode=null,e.updateQueue=null}function _p(e){return e.tag===5||e.tag===3||e.tag===4}function Cp(e){e:for(;;){for(;e.sibling===null;){if(e.return===null||_p(e.return))return null;e=e.return}for(e.sibling.return=e.return,e=e.sibling;e.tag!==5&&e.tag!==6&&e.tag!==18;){if(e.flags&2||e.child===null||e.tag===4)continue e;e.child.return=e,e=e.child}if(!(e.flags&2))return e.stateNode}}function Ol(e,t,n){var r=e.tag;if(r===5||r===6)e=e.stateNode,t?n.nodeType===8?n.parentNode.insertBefore(e,t):n.insertBefore(e,t):(n.nodeType===8?(t=n.parentNode,t.insertBefore(e,n)):(t=n,t.appendChild(e)),n=n._reactRootContainer,n!=null||t.onclick!==null||(t.onclick=Uo));else if(r!==4&&(e=e.child,e!==null))for(Ol(e,t,n),e=e.sibling;e!==null;)Ol(e,t,n),e=e.sibling}function Ml(e,t,n){var r=e.tag;if(r===5||r===6)e=e.stateNode,t?n.insertBefore(e,t):n.appendChild(e);else if(r!==4&&(e=e.child,e!==null))for(Ml(e,t,n),e=e.sibling;e!==null;)Ml(e,t,n),e=e.sibling}var $e=null,_t=!1;function pn(e,t,n){for(n=n.child;n!==null;)Ep(e,t,n),n=n.sibling}function Ep(e,t,n){if(jt&&typeof jt.onCommitFiberUnmount=="function")try{jt.onCommitFiberUnmount(_o,n)}catch{}switch(n.tag){case 5:Ze||lr(n,t);case 6:var r=$e,o=_t;$e=null,pn(e,t,n),$e=r,_t=o,$e!==null&&(_t?(e=$e,n=n.stateNode,e.nodeType===8?e.parentNode.removeChild(n):e.removeChild(n)):$e.removeChild(n.stateNode));break;case 18:$e!==null&&(_t?(e=$e,n=n.stateNode,e.nodeType===8?Ja(e.parentNode,n):e.nodeType===1&&Ja(e,n),Fr(e)):Ja($e,n.stateNode));break;case 4:r=$e,o=_t,$e=n.stateNode.containerInfo,_t=!0,pn(e,t,n),$e=r,_t=o;break;case 0:case 11:case 14:case 15:if(!Ze&&(r=n.updateQueue,r!==null&&(r=r.lastEffect,r!==null))){o=r=r.next;do{var i=o,a=i.destroy;i=i.tag,a!==void 0&&(i&2||i&4)&&Ll(n,t,a),o=o.next}while(o!==r)}pn(e,t,n);break;case 1:if(!Ze&&(lr(n,t),r=n.stateNode,typeof r.componentWillUnmount=="function"))try{r.props=n.memoizedProps,r.state=n.memoizedState,r.componentWillUnmount()}catch(l){Ae(n,t,l)}pn(e,t,n);break;case 21:pn(e,t,n);break;case 22:n.mode&1?(Ze=(r=Ze)||n.memoizedState!==null,pn(e,t,n),Ze=r):pn(e,t,n);break;default:pn(e,t,n)}}function Np(e){var t=e.updateQueue;if(t!==null){e.updateQueue=null;var n=e.stateNode;n===null&&(n=e.stateNode=new im),t.forEach(function(r){var o=mm.bind(null,e,r);n.has(r)||(n.add(r),r.then(o,o))})}}function Ct(e,t){var n=t.deletions;if(n!==null)for(var r=0;r<n.length;r++){var o=n[r];try{var i=e,a=t,l=a;e:for(;l!==null;){switch(l.tag){case 5:$e=l.stateNode,_t=!1;break e;case 3:$e=l.stateNode.containerInfo,_t=!0;break e;case 4:$e=l.stateNode.containerInfo,_t=!0;break e}l=l.return}if($e===null)throw Error(K(160));Ep(i,a,o),$e=null,_t=!1;var s=o.alternate;s!==null&&(s.return=null),o.return=null}catch(u){Ae(o,t,u)}}if(t.subtreeFlags&12854)for(t=t.child;t!==null;)jp(t,e),t=t.sibling}function jp(e,t){var n=e.alternate,r=e.flags;switch(e.tag){case 0:case 11:case 14:case 15:if(Ct(t,e),Pt(e),r&4){try{Kr(3,e,e.return),pi(3,e)}catch(f){Ae(e,e.return,f)}try{Kr(5,e,e.return)}catch(f){Ae(e,e.return,f)}}break;case 1:Ct(t,e),Pt(e),r&512&&n!==null&&lr(n,n.return);break;case 5:if(Ct(t,e),Pt(e),r&512&&n!==null&&lr(n,n.return),e.flags&32){var o=e.stateNode;try{vr(o,"")}catch(f){Ae(e,e.return,f)}}if(r&4&&(o=e.stateNode,o!=null)){var i=e.memoizedProps,a=n!==null?n.memoizedProps:i,l=e.type,s=e.updateQueue;if(e.updateQueue=null,s!==null)try{l==="input"&&i.type==="radio"&&i.name!=null&&nc(o,i),ga(l,a);var u=ga(l,i);for(a=0;a<s.length;a+=2){var y=s[a],x=s[a+1];y==="style"?uc(o,x):y==="dangerouslySetInnerHTML"?sc(o,x):y==="children"?vr(o,x):qi(o,y,x,u)}switch(l){case"input":pa(o,i);break;case"textarea":ic(o,i);break;case"select":var w=o._wrapperState.wasMultiple;o._wrapperState.wasMultiple=!!i.multiple;var h=i.value;h!=null?Bn(o,!!i.multiple,h,!1):w!==!!i.multiple&&(i.defaultValue!=null?Bn(o,!!i.multiple,i.defaultValue,!0):Bn(o,!!i.multiple,i.multiple?[]:"",!1))}o[Br]=i}catch(f){Ae(e,e.return,f)}}break;case 6:if(Ct(t,e),Pt(e),r&4){if(e.stateNode===null)throw Error(K(162));o=e.stateNode,i=e.memoizedProps;try{o.nodeValue=i}catch(f){Ae(e,e.return,f)}}break;case 3:if(Ct(t,e),Pt(e),r&4&&n!==null&&n.memoizedState.isDehydrated)try{Fr(t.containerInfo)}catch(f){Ae(e,e.return,f)}break;case 4:Ct(t,e),Pt(e);break;case 13:Ct(t,e),Pt(e),o=e.child,o.flags&8192&&(i=o.memoizedState!==null,o.stateNode.isHidden=i,!i||o.alternate!==null&&o.alternate.memoizedState!==null||(Ul=Pe())),r&4&&Np(e);break;case 22:if(y=n!==null&&n.memoizedState!==null,e.mode&1?(Ze=(u=Ze)||y,Ct(t,e),Ze=u):Ct(t,e),Pt(e),r&8192){if(u=e.memoizedState!==null,(e.stateNode.isHidden=u)&&!y&&e.mode&1)for(ae=e,y=e.child;y!==null;){for(x=ae=y;ae!==null;){switch(w=ae,h=w.child,w.tag){case 0:case 11:case 14:case 15:Kr(4,w,w.return);break;case 1:lr(w,w.return);var b=w.stateNode;if(typeof b.componentWillUnmount=="function"){r=w,n=w.return;try{t=r,b.props=t.memoizedProps,b.state=t.memoizedState,b.componentWillUnmount()}catch(f){Ae(r,n,f)}}break;case 5:lr(w,w.return);break;case 22:if(w.memoizedState!==null){Ap(x);continue}}h!==null?(h.return=w,ae=h):Ap(x)}y=y.sibling}e:for(y=null,x=e;;){if(x.tag===5){if(y===null){y=x;try{o=x.stateNode,u?(i=o.style,typeof i.setProperty=="function"?i.setProperty("display","none","important"):i.display="none"):(l=x.stateNode,s=x.memoizedProps.style,a=s!=null&&s.hasOwnProperty("display")?s.display:null,l.style.display=cc("display",a))}catch(f){Ae(e,e.return,f)}}}else if(x.tag===6){if(y===null)try{x.stateNode.nodeValue=u?"":x.memoizedProps}catch(f){Ae(e,e.return,f)}}else if((x.tag!==22&&x.tag!==23||x.memoizedState===null||x===e)&&x.child!==null){x.child.return=x,x=x.child;continue}if(x===e)break e;for(;x.sibling===null;){if(x.return===null||x.return===e)break e;y===x&&(y=null),x=x.return}y===x&&(y=null),x.sibling.return=x.return,x=x.sibling}}break;case 19:Ct(t,e),Pt(e),r&4&&Np(e);break;case 21:break;default:Ct(t,e),Pt(e)}}function Pt(e){var t=e.flags;if(t&2){try{e:{for(var n=e.return;n!==null;){if(_p(n)){var r=n;break e}n=n.return}throw Error(K(160))}switch(r.tag){case 5:var o=r.stateNode;r.flags&32&&(vr(o,""),r.flags&=-33);var i=Cp(e);Ml(e,i,o);break;case 3:case 4:var a=r.stateNode.containerInfo,l=Cp(e);Ol(e,l,a);break;default:throw Error(K(161))}}catch(s){Ae(e,e.return,s)}e.flags&=-3}t&4096&&(e.flags&=-4097)}function lm(e,t,n){ae=e,Fp(e)}function Fp(e,t,n){for(var r=(e.mode&1)!==0;ae!==null;){var o=ae,i=o.child;if(o.tag===22&&r){var a=o.memoizedState!==null||ui;if(!a){var l=o.alternate,s=l!==null&&l.memoizedState!==null||Ze;l=ui;var u=Ze;if(ui=a,(Ze=s)&&!u)for(ae=o;ae!==null;)a=ae,s=a.child,a.tag===22&&a.memoizedState!==null?Pp(o):s!==null?(s.return=a,ae=s):Pp(o);for(;i!==null;)ae=i,Fp(i),i=i.sibling;ae=o,ui=l,Ze=u}Tp(e)}else o.subtreeFlags&8772&&i!==null?(i.return=o,ae=i):Tp(e)}}function Tp(e){for(;ae!==null;){var t=ae;if(t.flags&8772){var n=t.alternate;try{if(t.flags&8772)switch(t.tag){case 0:case 11:case 15:Ze||pi(5,t);break;case 1:var r=t.stateNode;if(t.flags&4&&!Ze)if(n===null)r.componentDidMount();else{var o=t.elementType===t.type?n.memoizedProps:St(t.type,n.memoizedProps);r.componentDidUpdate(o,n.memoizedState,r.__reactInternalSnapshotBeforeUpdate)}var i=t.updateQueue;i!==null&&Au(t,i,r);break;case 3:var a=t.updateQueue;if(a!==null){if(n=null,t.child!==null)switch(t.child.tag){case 5:n=t.child.stateNode;break;case 1:n=t.child.stateNode}Au(t,a,n)}break;case 5:var l=t.stateNode;if(n===null&&t.flags&4){n=l;var s=t.memoizedProps;switch(t.type){case"button":case"input":case"select":case"textarea":s.autoFocus&&n.focus();break;case"img":s.src&&(n.src=s.src)}}break;case 6:break;case 4:break;case 12:break;case 13:if(t.memoizedState===null){var u=t.alternate;if(u!==null){var y=u.memoizedState;if(y!==null){var x=y.dehydrated;x!==null&&Fr(x)}}}break;case 19:case 17:case 21:case 22:case 23:case 25:break;default:throw Error(K(163))}Ze||t.flags&512&&Dl(t)}catch(w){Ae(t,t.return,w)}}if(t===e){ae=null;break}if(n=t.sibling,n!==null){n.return=t.return,ae=n;break}ae=t.return}}function Ap(e){for(;ae!==null;){var t=ae;if(t===e){ae=null;break}var n=t.sibling;if(n!==null){n.return=t.return,ae=n;break}ae=t.return}}function Pp(e){for(;ae!==null;){var t=ae;try{switch(t.tag){case 0:case 11:case 15:var n=t.return;try{pi(4,t)}catch(s){Ae(t,n,s)}break;case 1:var r=t.stateNode;if(typeof r.componentDidMount=="function"){var o=t.return;try{r.componentDidMount()}catch(s){Ae(t,o,s)}}var i=t.return;try{Dl(t)}catch(s){Ae(t,i,s)}break;case 5:var a=t.return;try{Dl(t)}catch(s){Ae(t,a,s)}}}catch(s){Ae(t,t.return,s)}if(t===e){ae=null;break}var l=t.sibling;if(l!==null){l.return=t.return,ae=l;break}ae=t.return}}var sm=Math.ceil,di=Dt.ReactCurrentDispatcher,Bl=Dt.ReactCurrentOwner,mt=Dt.ReactCurrentBatchConfig,ge=0,Oe=null,ze=null,Ue=0,ct=0,sr=an(0),Le=0,Jr=null,Tn=0,fi=0,$l=0,qr=null,tt=null,Ul=0,cr=1/0,Vt=null,hi=!1,Hl=null,dn=null,mi=!1,fn=null,gi=0,eo=0,Wl=null,xi=-1,vi=0;function Ke(){return ge&6?Pe():xi!==-1?xi:xi=Pe()}function hn(e){return e.mode&1?ge&2&&Ue!==0?Ue&-Ue:Vh.transition!==null?(vi===0&&(vi=Cc()),vi):(e=we,e!==0||(e=window.event,e=e===void 0?16:zc(e.type)),e):1}function Et(e,t,n,r){if(50<eo)throw eo=0,Wl=null,Error(K(185));_r(e,n,r),(!(ge&2)||e!==Oe)&&(e===Oe&&(!(ge&2)&&(fi|=n),Le===4&&mn(e,Ue)),nt(e,r),n===1&&ge===0&&!(t.mode&1)&&(cr=Pe()+500,Go&&sn()))}function nt(e,t){var n=e.callbackNode;Vf(e,t);var r=No(e,e===Oe?Ue:0);if(r===0)n!==null&&kc(n),e.callbackNode=null,e.callbackPriority=0;else if(t=r&-r,e.callbackPriority!==t){if(n!=null&&kc(n),t===1)e.tag===0?Wh(zp.bind(null,e)):yu(zp.bind(null,e)),Bh(function(){!(ge&6)&&sn()}),n=null;else{switch(Ec(r)){case 1:n=Sa;break;case 4:n=Sc;break;case 16:n=So;break;case 536870912:n=_c;break;default:n=So}n=Up(n,Ip.bind(null,e))}e.callbackPriority=t,e.callbackNode=n}}function Ip(e,t){if(xi=-1,vi=0,ge&6)throw Error(K(327));var n=e.callbackNode;if(ur()&&e.callbackNode!==n)return null;var r=No(e,e===Oe?Ue:0);if(r===0)return null;if(r&30||r&e.expiredLanes||t)t=yi(e,r);else{t=r;var o=ge;ge|=2;var i=Lp();(Oe!==e||Ue!==t)&&(Vt=null,cr=Pe()+500,Pn(e,t));do try{pm();break}catch(l){Rp(e,l)}while(!0);sl(),di.current=i,ge=o,ze!==null?t=0:(Oe=null,Ue=0,t=Le)}if(t!==0){if(t===2&&(o=_a(e),o!==0&&(r=o,t=Vl(e,o))),t===1)throw n=Jr,Pn(e,0),mn(e,r),nt(e,Pe()),n;if(t===6)mn(e,r);else{if(o=e.current.alternate,!(r&30)&&!cm(o)&&(t=yi(e,r),t===2&&(i=_a(e),i!==0&&(r=i,t=Vl(e,i))),t===1))throw n=Jr,Pn(e,0),mn(e,r),nt(e,Pe()),n;switch(e.finishedWork=o,e.finishedLanes=r,t){case 0:case 1:throw Error(K(345));case 2:In(e,tt,Vt);break;case 3:if(mn(e,r),(r&130023424)===r&&(t=Ul+500-Pe(),10<t)){if(No(e,0)!==0)break;if(o=e.suspendedLanes,(o&r)!==r){Ke(),e.pingedLanes|=e.suspendedLanes&o;break}e.timeoutHandle=Ka(In.bind(null,e,tt,Vt),t);break}In(e,tt,Vt);break;case 4:if(mn(e,r),(r&4194240)===r)break;for(t=e.eventTimes,o=-1;0<r;){var a=31-bt(r);i=1<<a,a=t[a],a>o&&(o=a),r&=~i}if(r=o,r=Pe()-r,r=(120>r?120:480>r?480:1080>r?1080:1920>r?1920:3e3>r?3e3:4320>r?4320:1960*sm(r/1960))-r,10<r){e.timeoutHandle=Ka(In.bind(null,e,tt,Vt),r);break}In(e,tt,Vt);break;case 5:In(e,tt,Vt);break;default:throw Error(K(329))}}}return nt(e,Pe()),e.callbackNode===n?Ip.bind(null,e):null}function Vl(e,t){var n=qr;return e.current.memoizedState.isDehydrated&&(Pn(e,t).flags|=256),e=yi(e,t),e!==2&&(t=tt,tt=n,t!==null&&Gl(t)),e}function Gl(e){tt===null?tt=e:tt.push.apply(tt,e)}function cm(e){for(var t=e;;){if(t.flags&16384){var n=t.updateQueue;if(n!==null&&(n=n.stores,n!==null))for(var r=0;r<n.length;r++){var o=n[r],i=o.getSnapshot;o=o.value;try{if(!wt(i(),o))return!1}catch{return!1}}}if(n=t.child,t.subtreeFlags&16384&&n!==null)n.return=t,t=n;else{if(t===e)break;for(;t.sibling===null;){if(t.return===null||t.return===e)return!0;t=t.return}t.sibling.return=t.return,t=t.sibling}}return!0}function mn(e,t){for(t&=~$l,t&=~fi,e.suspendedLanes|=t,e.pingedLanes&=~t,e=e.expirationTimes;0<t;){var n=31-bt(t),r=1<<n;e[n]=-1,t&=~r}}function zp(e){if(ge&6)throw Error(K(327));ur();var t=No(e,0);if(!(t&1))return nt(e,Pe()),null;var n=yi(e,t);if(e.tag!==0&&n===2){var r=_a(e);r!==0&&(t=r,n=Vl(e,r))}if(n===1)throw n=Jr,Pn(e,0),mn(e,t),nt(e,Pe()),n;if(n===6)throw Error(K(345));return e.finishedWork=e.current.alternate,e.finishedLanes=t,In(e,tt,Vt),nt(e,Pe()),null}function Zl(e,t){var n=ge;ge|=1;try{return e(t)}finally{ge=n,ge===0&&(cr=Pe()+500,Go&&sn())}}function An(e){fn!==null&&fn.tag===0&&!(ge&6)&&ur();var t=ge;ge|=1;var n=mt.transition,r=we;try{if(mt.transition=null,we=1,e)return e()}finally{we=r,mt.transition=n,ge=t,!(ge&6)&&sn()}}function Yl(){ct=sr.current,Ee(sr)}function Pn(e,t){e.finishedWork=null,e.finishedLanes=0;var n=e.timeoutHandle;if(n!==-1&&(e.timeoutHandle=-1,Mh(n)),ze!==null)for(n=ze.return;n!==null;){var r=n;switch(rl(r),r.tag){case 1:r=r.type.childContextTypes,r!=null&&Wo();break;case 3:ir(),Ee(Je),Ee(We),gl();break;case 5:hl(r);break;case 4:ir();break;case 13:Ee(Fe);break;case 19:Ee(Fe);break;case 10:cl(r.type._context);break;case 22:case 23:Yl()}n=n.return}if(Oe=e,ze=e=gn(e.current,null),Ue=ct=t,Le=0,Jr=null,$l=fi=Tn=0,tt=qr=null,Nn!==null){for(t=0;t<Nn.length;t++)if(n=Nn[t],r=n.interleaved,r!==null){n.interleaved=null;var o=r.next,i=n.pending;if(i!==null){var a=i.next;i.next=o,r.next=a}n.pending=r}Nn=null}return e}function Rp(e,t){do{var n=ze;try{if(sl(),ni.current=ai,ri){for(var r=Te.memoizedState;r!==null;){var o=r.queue;o!==null&&(o.pending=null),r=r.next}ri=!1}if(Fn=0,De=Re=Te=null,Gr=!1,Zr=0,Bl.current=null,n===null||n.return===null){Le=1,Jr=t,ze=null;break}e:{var i=e,a=n.return,l=n,s=t;if(t=Ue,l.flags|=32768,s!==null&&typeof s=="object"&&typeof s.then=="function"){var u=s,y=l,x=y.tag;if(!(y.mode&1)&&(x===0||x===11||x===15)){var w=y.alternate;w?(y.updateQueue=w.updateQueue,y.memoizedState=w.memoizedState,y.lanes=w.lanes):(y.updateQueue=null,y.memoizedState=null)}var h=ap(a);if(h!==null){h.flags&=-257,lp(h,a,l,i,t),h.mode&1&&ip(i,u,t),t=h,s=u;var b=t.updateQueue;if(b===null){var f=new Set;f.add(s),t.updateQueue=f}else b.add(s);break e}else{if(!(t&1)){ip(i,u,t),Ql();break e}s=Error(K(426))}}else if(Ne&&l.mode&1){var v=ap(a);if(v!==null){!(v.flags&65536)&&(v.flags|=256),lp(v,a,l,i,t),al(ar(s,l));break e}}i=s=ar(s,l),Le!==4&&(Le=2),qr===null?qr=[i]:qr.push(i),i=a;do{switch(i.tag){case 3:i.flags|=65536,t&=-t,i.lanes|=t;var p=rp(i,s,t);Tu(i,p);break e;case 1:l=s;var d=i.type,g=i.stateNode;if(!(i.flags&128)&&(typeof d.getDerivedStateFromError=="function"||g!==null&&typeof g.componentDidCatch=="function"&&(dn===null||!dn.has(g)))){i.flags|=65536,t&=-t,i.lanes|=t;var S=op(i,l,t);Tu(i,S);break e}}i=i.return}while(i!==null)}Op(n)}catch(C){t=C,ze===n&&n!==null&&(ze=n=n.return);continue}break}while(!0)}function Lp(){var e=di.current;return di.current=ai,e===null?ai:e}function Ql(){(Le===0||Le===3||Le===2)&&(Le=4),Oe===null||!(Tn&268435455)&&!(fi&268435455)||mn(Oe,Ue)}function yi(e,t){var n=ge;ge|=2;var r=Lp();(Oe!==e||Ue!==t)&&(Vt=null,Pn(e,t));do try{um();break}catch(o){Rp(e,o)}while(!0);if(sl(),ge=n,di.current=r,ze!==null)throw Error(K(261));return Oe=null,Ue=0,Le}function um(){for(;ze!==null;)Dp(ze)}function pm(){for(;ze!==null&&!Lf();)Dp(ze)}function Dp(e){var t=$p(e.alternate,e,ct);e.memoizedProps=e.pendingProps,t===null?Op(e):ze=t,Bl.current=null}function Op(e){var t=e;do{var n=t.alternate;if(e=t.return,t.flags&32768){if(n=om(n,t),n!==null){n.flags&=32767,ze=n;return}if(e!==null)e.flags|=32768,e.subtreeFlags=0,e.deletions=null;else{Le=6,ze=null;return}}else if(n=rm(n,t,ct),n!==null){ze=n;return}if(t=t.sibling,t!==null){ze=t;return}ze=t=e}while(t!==null);Le===0&&(Le=5)}function In(e,t,n){var r=we,o=mt.transition;try{mt.transition=null,we=1,dm(e,t,n,r)}finally{mt.transition=o,we=r}return null}function dm(e,t,n,r){do ur();while(fn!==null);if(ge&6)throw Error(K(327));n=e.finishedWork;var o=e.finishedLanes;if(n===null)return null;if(e.finishedWork=null,e.finishedLanes=0,n===e.current)throw Error(K(177));e.callbackNode=null,e.callbackPriority=0;var i=n.lanes|n.childLanes;if(Gf(e,i),e===Oe&&(ze=Oe=null,Ue=0),!(n.subtreeFlags&2064)&&!(n.flags&2064)||mi||(mi=!0,Up(So,function(){return ur(),null})),i=(n.flags&15990)!==0,n.subtreeFlags&15990||i){i=mt.transition,mt.transition=null;var a=we;we=1;var l=ge;ge|=4,Bl.current=null,am(e,n),jp(n,e),Ph(Qa),To=!!Ya,Qa=Ya=null,e.current=n,lm(n),Df(),ge=l,we=a,mt.transition=i}else e.current=n;if(mi&&(mi=!1,fn=e,gi=o),i=e.pendingLanes,i===0&&(dn=null),Bf(n.stateNode),nt(e,Pe()),t!==null)for(r=e.onRecoverableError,n=0;n<t.length;n++)o=t[n],r(o.value,{componentStack:o.stack,digest:o.digest});if(hi)throw hi=!1,e=Hl,Hl=null,e;return gi&1&&e.tag!==0&&ur(),i=e.pendingLanes,i&1?e===Wl?eo++:(eo=0,Wl=e):eo=0,sn(),null}function ur(){if(fn!==null){var e=Ec(gi),t=mt.transition,n=we;try{if(mt.transition=null,we=16>e?16:e,fn===null)var r=!1;else{if(e=fn,fn=null,gi=0,ge&6)throw Error(K(331));var o=ge;for(ge|=4,ae=e.current;ae!==null;){var i=ae,a=i.child;if(ae.flags&16){var l=i.deletions;if(l!==null){for(var s=0;s<l.length;s++){var u=l[s];for(ae=u;ae!==null;){var y=ae;switch(y.tag){case 0:case 11:case 15:Kr(8,y,i)}var x=y.child;if(x!==null)x.return=y,ae=x;else for(;ae!==null;){y=ae;var w=y.sibling,h=y.return;if(Sp(y),y===u){ae=null;break}if(w!==null){w.return=h,ae=w;break}ae=h}}}var b=i.alternate;if(b!==null){var f=b.child;if(f!==null){b.child=null;do{var v=f.sibling;f.sibling=null,f=v}while(f!==null)}}ae=i}}if(i.subtreeFlags&2064&&a!==null)a.return=i,ae=a;else e:for(;ae!==null;){if(i=ae,i.flags&2048)switch(i.tag){case 0:case 11:case 15:Kr(9,i,i.return)}var p=i.sibling;if(p!==null){p.return=i.return,ae=p;break e}ae=i.return}}var d=e.current;for(ae=d;ae!==null;){a=ae;var g=a.child;if(a.subtreeFlags&2064&&g!==null)g.return=a,ae=g;else e:for(a=d;ae!==null;){if(l=ae,l.flags&2048)try{switch(l.tag){case 0:case 11:case 15:pi(9,l)}}catch(C){Ae(l,l.return,C)}if(l===a){ae=null;break e}var S=l.sibling;if(S!==null){S.return=l.return,ae=S;break e}ae=l.return}}if(ge=o,sn(),jt&&typeof jt.onPostCommitFiberRoot=="function")try{jt.onPostCommitFiberRoot(_o,e)}catch{}r=!0}return r}finally{we=n,mt.transition=t}}return!1}function Mp(e,t,n){t=ar(n,t),t=rp(e,t,1),e=un(e,t,1),t=Ke(),e!==null&&(_r(e,1,t),nt(e,t))}function Ae(e,t,n){if(e.tag===3)Mp(e,e,n);else for(;t!==null;){if(t.tag===3){Mp(t,e,n);break}else if(t.tag===1){var r=t.stateNode;if(typeof t.type.getDerivedStateFromError=="function"||typeof r.componentDidCatch=="function"&&(dn===null||!dn.has(r))){e=ar(n,e),e=op(t,e,1),t=un(t,e,1),e=Ke(),t!==null&&(_r(t,1,e),nt(t,e));break}}t=t.return}}function fm(e,t,n){var r=e.pingCache;r!==null&&r.delete(t),t=Ke(),e.pingedLanes|=e.suspendedLanes&n,Oe===e&&(Ue&n)===n&&(Le===4||Le===3&&(Ue&130023424)===Ue&&500>Pe()-Ul?Pn(e,0):$l|=n),nt(e,t)}function Bp(e,t){t===0&&(e.mode&1?(t=Eo,Eo<<=1,!(Eo&130023424)&&(Eo=4194304)):t=1);var n=Ke();e=Ut(e,t),e!==null&&(_r(e,t,n),nt(e,n))}function hm(e){var t=e.memoizedState,n=0;t!==null&&(n=t.retryLane),Bp(e,n)}function mm(e,t){var n=0;switch(e.tag){case 13:var r=e.stateNode,o=e.memoizedState;o!==null&&(n=o.retryLane);break;case 19:r=e.stateNode;break;default:throw Error(K(314))}r!==null&&r.delete(t),Bp(e,n)}var $p;$p=function(e,t,n){if(e!==null)if(e.memoizedProps!==t.pendingProps||Je.current)et=!0;else{if(!(e.lanes&n)&&!(t.flags&128))return et=!1,nm(e,t,n);et=!!(e.flags&131072)}else et=!1,Ne&&t.flags&1048576&&bu(t,Yo,t.index);switch(t.lanes=0,t.tag){case 2:var r=t.type;ci(e,t),e=t.pendingProps;var o=Jn(t,We.current);or(t,n),o=yl(null,t,r,e,o,n);var i=bl();return t.flags|=1,typeof o=="object"&&o!==null&&typeof o.render=="function"&&o.$$typeof===void 0?(t.tag=1,t.memoizedState=null,t.updateQueue=null,qe(r)?(i=!0,Vo(t)):i=!1,t.memoizedState=o.state!==null&&o.state!==void 0?o.state:null,dl(t),o.updater=li,t.stateNode=o,o._reactInternals=t,El(t,r,e,n),t=Tl(null,t,r,!0,i,n)):(t.tag=0,Ne&&i&&nl(t),Xe(null,t,o,n),t=t.child),t;case 16:r=t.elementType;e:{switch(ci(e,t),e=t.pendingProps,o=r._init,r=o(r._payload),t.type=r,o=t.tag=xm(r),e=St(r,e),o){case 0:t=Fl(null,t,r,e,n);break e;case 1:t=fp(null,t,r,e,n);break e;case 11:t=sp(null,t,r,e,n);break e;case 14:t=cp(null,t,r,St(r.type,e),n);break e}throw Error(K(306,r,""))}return t;case 0:return r=t.type,o=t.pendingProps,o=t.elementType===r?o:St(r,o),Fl(e,t,r,o,n);case 1:return r=t.type,o=t.pendingProps,o=t.elementType===r?o:St(r,o),fp(e,t,r,o,n);case 3:e:{if(hp(t),e===null)throw Error(K(387));r=t.pendingProps,i=t.memoizedState,o=i.element,Fu(e,t),ei(t,r,null,n);var a=t.memoizedState;if(r=a.element,i.isDehydrated)if(i={element:r,isDehydrated:!1,cache:a.cache,pendingSuspenseBoundaries:a.pendingSuspenseBoundaries,transitions:a.transitions},t.updateQueue.baseState=i,t.memoizedState=i,t.flags&256){o=ar(Error(K(423)),t),t=mp(e,t,r,n,o);break e}else if(r!==o){o=ar(Error(K(424)),t),t=mp(e,t,r,n,o);break e}else for(st=on(t.stateNode.containerInfo.firstChild),lt=t,Ne=!0,kt=null,n=Nu(t,null,r,n),t.child=n;n;)n.flags=n.flags&-3|4096,n=n.sibling;else{if(tr(),r===o){t=Wt(e,t,n);break e}Xe(e,t,r,n)}t=t.child}return t;case 5:return Pu(t),e===null&&il(t),r=t.type,o=t.pendingProps,i=e!==null?e.memoizedProps:null,a=o.children,Xa(r,o)?a=null:i!==null&&Xa(r,i)&&(t.flags|=32),dp(e,t),Xe(e,t,a,n),t.child;case 6:return e===null&&il(t),null;case 13:return gp(e,t,n);case 4:return fl(t,t.stateNode.containerInfo),r=t.pendingProps,e===null?t.child=nr(t,null,r,n):Xe(e,t,r,n),t.child;case 11:return r=t.type,o=t.pendingProps,o=t.elementType===r?o:St(r,o),sp(e,t,r,o,n);case 7:return Xe(e,t,t.pendingProps,n),t.child;case 8:return Xe(e,t,t.pendingProps.children,n),t.child;case 12:return Xe(e,t,t.pendingProps.children,n),t.child;case 10:e:{if(r=t.type._context,o=t.pendingProps,i=t.memoizedProps,a=o.value,Se(Ko,r._currentValue),r._currentValue=a,i!==null)if(wt(i.value,a)){if(i.children===o.children&&!Je.current){t=Wt(e,t,n);break e}}else for(i=t.child,i!==null&&(i.return=t);i!==null;){var l=i.dependencies;if(l!==null){a=i.child;for(var s=l.firstContext;s!==null;){if(s.context===r){if(i.tag===1){s=Ht(-1,n&-n),s.tag=2;var u=i.updateQueue;if(u!==null){u=u.shared;var y=u.pending;y===null?s.next=s:(s.next=y.next,y.next=s),u.pending=s}}i.lanes|=n,s=i.alternate,s!==null&&(s.lanes|=n),ul(i.return,n,t),l.lanes|=n;break}s=s.next}}else if(i.tag===10)a=i.type===t.type?null:i.child;else if(i.tag===18){if(a=i.return,a===null)throw Error(K(341));a.lanes|=n,l=a.alternate,l!==null&&(l.lanes|=n),ul(a,n,t),a=i.sibling}else a=i.child;if(a!==null)a.return=i;else for(a=i;a!==null;){if(a===t){a=null;break}if(i=a.sibling,i!==null){i.return=a.return,a=i;break}a=a.return}i=a}Xe(e,t,o.children,n),t=t.child}return t;case 9:return o=t.type,r=t.pendingProps.children,or(t,n),o=ft(o),r=r(o),t.flags|=1,Xe(e,t,r,n),t.child;case 14:return r=t.type,o=St(r,t.pendingProps),o=St(r.type,o),cp(e,t,r,o,n);case 15:return up(e,t,t.type,t.pendingProps,n);case 17:return r=t.type,o=t.pendingProps,o=t.elementType===r?o:St(r,o),ci(e,t),t.tag=1,qe(r)?(e=!0,Vo(t)):e=!1,or(t,n),tp(t,r,o),El(t,r,o,n),Tl(null,t,r,!0,e,n);case 19:return vp(e,t,n);case 22:return pp(e,t,n)}throw Error(K(156,t.tag))};function Up(e,t){return wc(e,t)}function gm(e,t,n,r){this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=r,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null}function gt(e,t,n,r){return new gm(e,t,n,r)}function Xl(e){return e=e.prototype,!(!e||!e.isReactComponent)}function xm(e){if(typeof e=="function")return Xl(e)?1:0;if(e!=null){if(e=e.$$typeof,e===na)return 11;if(e===ia)return 14}return 2}function gn(e,t){var n=e.alternate;return n===null?(n=gt(e.tag,t,e.key,e.mode),n.elementType=e.elementType,n.type=e.type,n.stateNode=e.stateNode,n.alternate=e,e.alternate=n):(n.pendingProps=t,n.type=e.type,n.flags=0,n.subtreeFlags=0,n.deletions=null),n.flags=e.flags&14680064,n.childLanes=e.childLanes,n.lanes=e.lanes,n.child=e.child,n.memoizedProps=e.memoizedProps,n.memoizedState=e.memoizedState,n.updateQueue=e.updateQueue,t=e.dependencies,n.dependencies=t===null?null:{lanes:t.lanes,firstContext:t.firstContext},n.sibling=e.sibling,n.index=e.index,n.ref=e.ref,n}function bi(e,t,n,r,o,i){var a=2;if(r=e,typeof e=="function")Xl(e)&&(a=1);else if(typeof e=="string")a=5;else e:switch(e){case Mn:return zn(n.children,o,i,t);case ea:a=8,o|=8;break;case ta:return e=gt(12,n,t,o|2),e.elementType=ta,e.lanes=i,e;case ra:return e=gt(13,n,t,o),e.elementType=ra,e.lanes=i,e;case oa:return e=gt(19,n,t,o),e.elementType=oa,e.lanes=i,e;case Ks:return wi(n,o,i,t);default:if(typeof e=="object"&&e!==null)switch(e.$$typeof){case Qs:a=10;break e;case Xs:a=9;break e;case na:a=11;break e;case ia:a=14;break e;case Xt:a=16,r=null;break e}throw Error(K(130,e==null?e:typeof e,""))}return t=gt(a,n,t,o),t.elementType=e,t.type=r,t.lanes=i,t}function zn(e,t,n,r){return e=gt(7,e,r,t),e.lanes=n,e}function wi(e,t,n,r){return e=gt(22,e,r,t),e.elementType=Ks,e.lanes=n,e.stateNode={isHidden:!1},e}function Kl(e,t,n){return e=gt(6,e,null,t),e.lanes=n,e}function Jl(e,t,n){return t=gt(4,e.children!==null?e.children:[],e.key,t),t.lanes=n,t.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},t}function vm(e,t,n,r,o){this.tag=t,this.containerInfo=e,this.finishedWork=this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=-1,this.callbackNode=this.pendingContext=this.context=null,this.callbackPriority=0,this.eventTimes=Ca(0),this.expirationTimes=Ca(-1),this.entangledLanes=this.finishedLanes=this.mutableReadLanes=this.expiredLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=Ca(0),this.identifierPrefix=r,this.onRecoverableError=o,this.mutableSourceEagerHydrationData=null}function ql(e,t,n,r,o,i,a,l,s){return e=new vm(e,t,n,l,s),t===1?(t=1,i===!0&&(t|=8)):t=0,i=gt(3,null,null,t),e.current=i,i.stateNode=e,i.memoizedState={element:r,isDehydrated:n,cache:null,transitions:null,pendingSuspenseBoundaries:null},dl(i),e}function ym(e,t,n){var r=3<arguments.length&&arguments[3]!==void 0?arguments[3]:null;return{$$typeof:On,key:r==null?null:""+r,children:e,containerInfo:t,implementation:n}}function Hp(e){if(!e)return ln;e=e._reactInternals;e:{if(kn(e)!==e||e.tag!==1)throw Error(K(170));var t=e;do{switch(t.tag){case 3:t=t.stateNode.context;break e;case 1:if(qe(t.type)){t=t.stateNode.__reactInternalMemoizedMergedChildContext;break e}}t=t.return}while(t!==null);throw Error(K(171))}if(e.tag===1){var n=e.type;if(qe(n))return xu(e,n,t)}return t}function Wp(e,t,n,r,o,i,a,l,s){return e=ql(n,r,!0,e,o,i,a,l,s),e.context=Hp(null),n=e.current,r=Ke(),o=hn(n),i=Ht(r,o),i.callback=t??null,un(n,i,o),e.current.lanes=o,_r(e,o,r),nt(e,r),e}function ki(e,t,n,r){var o=t.current,i=Ke(),a=hn(o);return n=Hp(n),t.context===null?t.context=n:t.pendingContext=n,t=Ht(i,a),t.payload={element:e},r=r===void 0?null:r,r!==null&&(t.callback=r),e=un(o,t,a),e!==null&&(Et(e,o,a,i),qo(e,o,a)),a}function Si(e){if(e=e.current,!e.child)return null;switch(e.child.tag){case 5:return e.child.stateNode;default:return e.child.stateNode}}function Vp(e,t){if(e=e.memoizedState,e!==null&&e.dehydrated!==null){var n=e.retryLane;e.retryLane=n!==0&&n<t?n:t}}function es(e,t){Vp(e,t),(e=e.alternate)&&Vp(e,t)}function bm(){return null}var Gp=typeof reportError=="function"?reportError:function(e){console.error(e)};function ts(e){this._internalRoot=e}_i.prototype.render=ts.prototype.render=function(e){var t=this._internalRoot;if(t===null)throw Error(K(409));ki(e,t,null,null)},_i.prototype.unmount=ts.prototype.unmount=function(){var e=this._internalRoot;if(e!==null){this._internalRoot=null;var t=e.containerInfo;An(function(){ki(null,e,null,null)}),t[Ot]=null}};function _i(e){this._internalRoot=e}_i.prototype.unstable_scheduleHydration=function(e){if(e){var t=Fc();e={blockedOn:null,target:e,priority:t};for(var n=0;n<tn.length&&t!==0&&t<tn[n].priority;n++);tn.splice(n,0,e),n===0&&Pc(e)}};function ns(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11)}function Ci(e){return!(!e||e.nodeType!==1&&e.nodeType!==9&&e.nodeType!==11&&(e.nodeType!==8||e.nodeValue!==" react-mount-point-unstable "))}function Zp(){}function wm(e,t,n,r,o){if(o){if(typeof r=="function"){var i=r;r=function(){var u=Si(a);i.call(u)}}var a=Wp(t,r,e,0,null,!1,!1,"",Zp);return e._reactRootContainer=a,e[Ot]=a.current,Or(e.nodeType===8?e.parentNode:e),An(),a}for(;o=e.lastChild;)e.removeChild(o);if(typeof r=="function"){var l=r;r=function(){var u=Si(s);l.call(u)}}var s=ql(e,0,!1,null,null,!1,!1,"",Zp);return e._reactRootContainer=s,e[Ot]=s.current,Or(e.nodeType===8?e.parentNode:e),An(function(){ki(t,s,n,r)}),s}function Ei(e,t,n,r,o){var i=n._reactRootContainer;if(i){var a=i;if(typeof o=="function"){var l=o;o=function(){var s=Si(a);l.call(s)}}ki(t,a,e,o)}else a=wm(n,t,e,o,r);return Si(a)}Nc=function(e){switch(e.tag){case 3:var t=e.stateNode;if(t.current.memoizedState.isDehydrated){var n=Sr(t.pendingLanes);n!==0&&(Ea(t,n|1),nt(t,Pe()),!(ge&6)&&(cr=Pe()+500,sn()))}break;case 13:An(function(){var r=Ut(e,1);if(r!==null){var o=Ke();Et(r,e,1,o)}}),es(e,1)}},Na=function(e){if(e.tag===13){var t=Ut(e,134217728);if(t!==null){var n=Ke();Et(t,e,134217728,n)}es(e,134217728)}},jc=function(e){if(e.tag===13){var t=hn(e),n=Ut(e,t);if(n!==null){var r=Ke();Et(n,e,t,r)}es(e,t)}},Fc=function(){return we},Tc=function(e,t){var n=we;try{return we=e,t()}finally{we=n}},ya=function(e,t,n){switch(t){case"input":if(pa(e,n),t=n.name,n.type==="radio"&&t!=null){for(n=e;n.parentNode;)n=n.parentNode;for(n=n.querySelectorAll("input[name="+JSON.stringify(""+t)+'][type="radio"]'),t=0;t<n.length;t++){var r=n[t];if(r!==e&&r.form===e.form){var o=Ho(r);if(!o)throw Error(K(90));ec(r),pa(r,o)}}}break;case"textarea":ic(e,n);break;case"select":t=n.value,t!=null&&Bn(e,!!n.multiple,t,!1)}},hc=Zl,mc=An;var km={usingClientEntryPoint:!1,Events:[$r,Xn,Ho,dc,fc,Zl]},to={findFiberByHostInstance:Sn,bundleType:0,version:"18.3.1",rendererPackageName:"react-dom"},Sm={bundleType:to.bundleType,version:to.version,rendererPackageName:to.rendererPackageName,rendererConfig:to.rendererConfig,overrideHookState:null,overrideHookStateDeletePath:null,overrideHookStateRenamePath:null,overrideProps:null,overridePropsDeletePath:null,overridePropsRenamePath:null,setErrorHandler:null,setSuspenseHandler:null,scheduleUpdate:null,currentDispatcherRef:Dt.ReactCurrentDispatcher,findHostInstanceByFiber:function(e){return e=yc(e),e===null?null:e.stateNode},findFiberByHostInstance:to.findFiberByHostInstance||bm,findHostInstancesForRefresh:null,scheduleRefresh:null,scheduleRoot:null,setRefreshHandler:null,getCurrentFiber:null,reconcilerVersion:"18.3.1-next-f1338f8080-20240426"};if(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__<"u"){var Ni=__REACT_DEVTOOLS_GLOBAL_HOOK__;if(!Ni.isDisabled&&Ni.supportsFiber)try{_o=Ni.inject(Sm),jt=Ni}catch{}}ot.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED=km,ot.createPortal=function(e,t){var n=2<arguments.length&&arguments[2]!==void 0?arguments[2]:null;if(!ns(t))throw Error(K(200));return ym(e,t,null,n)},ot.createRoot=function(e,t){if(!ns(e))throw Error(K(299));var n=!1,r="",o=Gp;return t!=null&&(t.unstable_strictMode===!0&&(n=!0),t.identifierPrefix!==void 0&&(r=t.identifierPrefix),t.onRecoverableError!==void 0&&(o=t.onRecoverableError)),t=ql(e,1,!1,null,null,n,!1,r,o),e[Ot]=t.current,Or(e.nodeType===8?e.parentNode:e),new ts(t)},ot.findDOMNode=function(e){if(e==null)return null;if(e.nodeType===1)return e;var t=e._reactInternals;if(t===void 0)throw typeof e.render=="function"?Error(K(188)):(e=Object.keys(e).join(","),Error(K(268,e)));return e=yc(t),e=e===null?null:e.stateNode,e},ot.flushSync=function(e){return An(e)},ot.hydrate=function(e,t,n){if(!Ci(t))throw Error(K(200));return Ei(null,e,t,!0,n)},ot.hydrateRoot=function(e,t,n){if(!ns(e))throw Error(K(405));var r=n!=null&&n.hydratedSources||null,o=!1,i="",a=Gp;if(n!=null&&(n.unstable_strictMode===!0&&(o=!0),n.identifierPrefix!==void 0&&(i=n.identifierPrefix),n.onRecoverableError!==void 0&&(a=n.onRecoverableError)),t=Wp(t,null,e,1,n??null,o,!1,i,a),e[Ot]=t.current,Or(e),r)for(e=0;e<r.length;e++)n=r[e],o=n._getVersion,o=o(n._source),t.mutableSourceEagerHydrationData==null?t.mutableSourceEagerHydrationData=[n,o]:t.mutableSourceEagerHydrationData.push(n,o);return new _i(t)},ot.render=function(e,t,n){if(!Ci(t))throw Error(K(200));return Ei(null,e,t,!1,n)},ot.unmountComponentAtNode=function(e){if(!Ci(e))throw Error(K(40));return e._reactRootContainer?(An(function(){Ei(null,null,e,!1,function(){e._reactRootContainer=null,e[Ot]=null})}),!0):!1},ot.unstable_batchedUpdates=Zl,ot.unstable_renderSubtreeIntoContainer=function(e,t,n,r){if(!Ci(n))throw Error(K(200));if(e==null||e._reactInternals===void 0)throw Error(K(38));return Ei(e,t,n,!1,r)},ot.version="18.3.1-next-f1338f8080-20240426";function Yp(){if(!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u"||typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE!="function"))try{__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(Yp)}catch(e){console.error(e)}}Yp(),Hs.exports=ot;var _m=Hs.exports,Qp,Xp=_m;Qp=Xp.createRoot,Xp.hydrateRoot;const N={appName:"Inspect Page",btnFullPage:"Export Full Page",btnPick:"Pick Element",btnCancel:"Cancel",btnCancelPicker:"Cancel picker",btnRetry:"Retry",btnCopyDetails:"Copy details",btnResetSettings:"Reset to defaults",btnOpenPanel:"Open panel on page",btnMinimize:"Minimize",btnClose:"Close",btnPopOut:"Open in new window",lblResizePanel:"Resize panel",btnThemeLight:"Switch to light theme",btnThemeDark:"Switch to dark theme",tabExport:"Export",tabPick:"Pick",tabInspect:"Inspect",inspectModeTitle:"Inspect Mode",inspectModePlaceholder:"Overview, Typography, Colors, Contrast and Inspector arrive in upcoming phases.",inspectOverviewTitle:"Overview",inspectLoading:"Collecting page snapshot…",inspectError:"Could not collect this page",inspectRetry:"Retry",inspectOpenDocs:"Open docs",inspectTypographyTitle:"Typography",inspectTypoHeadings:"Headings",inspectTypoBody:"Body",inspectTypoWeights:"{n} weights",inspectTypoStyles:"{n} text styles",inspectTypoShowAll:"Show all",inspectTypoNone:"No fonts detected on this page.",inspectTypoModalTitle:"All fonts",inspectClose:"Close",inspectColorsTitle:"Colors {n}",inspectColorsExportAll:"Export All",inspectColorsPalette:"Palette",inspectColorsCategories:"Categories",inspectColorsNone:"No colors detected on this page.",inspectColorLocate:"Locate",inspectColorCopy:"Copy",inspectColorCopied:"Copied",inspectColorLocateCount:"{n} match for {value}",inspectColorLocateCountPlural:"{n} matches for {value}",inspectColorLocateNone:"No matches for {value}",inspectColorLocateError:"Couldn't locate {value}",inspectColorCatBackground:"Background colors",inspectColorCatText:"Text colors",inspectColorCatBorder:"Border colors",inspectColorCatFill:"Fill colors",inspectColorCatStroke:"Stroke colors",inspectColorCatGradient:"Gradients",inspectColorCatShadow:"Shadow colors",inspectColorCatOther:"Other",inspectContrastTitle:"Contrast Scanner",inspectContrastShowAll:"Show all",inspectContrastFailing:"Failing",inspectContrastPassing:"Passing",inspectContrastNone:"No text-on-background pairs detected.",inspectContrastInstances:"{n} instances",inspectContrastShowDetails:"Show details",inspectContrastHideDetails:"Hide details",inspectContrastText:"Text",inspectContrastBackground:"Background",inspectContrastNormal:"Normal",inspectContrastLarge:"Large",inspectContrastBack:"Back",inspectCssTitle:"CSS Information",inspectCssRules:"CSS rules",inspectCssSize:"Inlined CSS",inspectCssExternalSheets:"External stylesheets",inspectCssInlineTags:"<style> tags",inspectCssUnreachable:"Unreachable sheets",inspectCssUnreachableHint:"Cross-origin stylesheets without CORS — counts only.",inspectCssNone:"No CSS detected on this page.",inspectInspectorTitle:"Element Inspector",inspectInspectorEmpty:"No elements available to inspect.",inspectInspectorHint:"Showing the largest visible elements first. Click any row to view its computed styles.",inspectInspectorRect:"{w} × {h}",inspectInspectorShowMore:"Show more",inspectInspectorShowLess:"Show less",inspectInspectorCopySelector:"Copy selector",inspectInspectorCopied:"Copied",inspectInspectorAnchor:"Set as anchor",inspectInspectorAnchored:"Anchor",inspectInspectorClearAnchor:"Clear anchor",inspectInspectorAnchorBanner:"Anchor: {selector}",inspectInspectorDistTitle:"Distance to anchor",inspectInspectorDistLeft:"left",inspectInspectorDistRight:"right",inspectInspectorDistTop:"top",inspectInspectorDistBottom:"bottom",inspectInspectorDistHGap:"horizontal gap",inspectInspectorDistVGap:"vertical gap",inspectInspectorDistOverlap:"overlapping",inspectInspectorDistSelf:"Anchor selected.",inspectInspectorShowCode:"Show code",inspectShowCodeTitle:"Show code",inspectShowCodeTabHtml:"HTML",inspectShowCodeTabCss:"CSS",inspectShowCodeCopy:"Copy",inspectShowCodeCopied:"Copied",inspectShowCodeNote:"Synthesized from the captured snapshot — class names and computed styles only. For full markup use Pick Element export.",inspectDetailTitle:"Color details",inspectDetailHex:"Hex",inspectDetailRgb:"RGB",inspectDetailHsl:"HSL",inspectDetailAlpha:"Alpha",inspectDetailCategory:"Category",inspectDetailInstances:"Instances",inspectDetailCopyHex:"Copy hex",inspectDetailCopyRgb:"Copy rgb()",inspectDetailCopyHsl:"Copy hsl()",inspectDetailCopied:"Copied",inspectExportReport:"Export report",inspectExportJson:"JSON",inspectExportMarkdown:"Markdown",inspectExportColorsCsv:"Colors (CSV)",inspectExportFontsCsv:"Fonts (CSV)",inspectFooterLabel:"Inspect Page v{version}",statusIdle:"Idle",statusCollecting:"Collecting page assets…",statusCapturing:"Capturing screenshot {done}/{total}",statusStitching:"Stitching image…",statusBundling:"Building ZIP…",statusDownloading:"Downloading…",statusPicker:"Picker active. Click (or right-click) an element. Esc to cancel.",statusSelecting:"Building element export…",statusSuccess:"Saved {filename}",statusError:"Error: {message} ({code})",settingsHeader:"Settings",lblImageFormat:"Image format",lblJpegQuality:"JPEG quality",lblRedact:"Redact <input type=password> values",lblComputed:"Include computed styles",lblMatched:"Include matched rules",lblNameFull:"Filename — full page",lblNameElem:"Filename — element",notAvailable:"Not available on browser pages.",telemetryHeader:"Captured in this export",telemetryShadowRoots:"shadow roots",telemetryFonts:"fonts",telemetryIframesSame:"same-origin iframes",telemetryIframesCross:"cross-origin iframes (skipped)",telemetryStylesheets:"stylesheets",telemetryFrames:"screenshot tiles",telemetryElementOuterHtml:"outerHTML",telemetryElementMatchedRules:"matched CSS rules",telemetryElementComputedDiff:"computed-style diffs",telemetryElementScreenshots:"screenshots (context + isolated)",telemetryElementIsolatedSkipped:"isolated skipped",debugHeader:"Picked element",debugSelector:"Selector",debugTabHtml:"HTML",debugTabCss:"CSS",debugTabJs:"JS",debugCopy:"Copy",debugFormatLabel:"Format",debugFormatRaw:"Raw",debugFormatMd:"Markdown",debugDownloadCurrent:"Download current",debugDownloadAll:"Download all (zip)",debugClear:"Clear",debugJsEmpty:"Element-scoped JS is not extracted. Showing computed-style diff (JSON).",fullPageActionsHeader:"Re-download captured files",fullPageDownloadHtml:"HTML",fullPageDownloadCss:"CSS",fullPageDownloadJs:"JS",fullPageDownloadScreenshot:"Screenshot",fullPageDownloadAllZip:"Download all (zip)",exportModesHeader:"Export for AI",exportModeMd:"MD",exportModeMdFiles:"MD + files",exportModeZip:"ZIP",exportModeShare:"Share Links",exportModeShareDisabledTip:"Sign in to Inspect Page in Settings → Smart Share",onboardingTitle:"Smart Share",onboardingBody:"Sign in to your WordPress account to create shareable links that expire in 24 hours.",onboardingDismiss:"Got it",onboardingSignIn:"Sign in",shareSettingsHeader:"Smart Share",shareHelp:"Sign in once with the Inspect Page account — no passwords or tokens are saved on your device.",shareNotConfiguredMsg:"Smart Share is being set up. This export mode will be available shortly.",shareSignInBtn:"Sign in",shareSignOutBtn:"Sign out",shareCheckBtn:"I'm signed in — refresh",shareSignedInAsPrefix:"Signed in as",shareSignedOutMsg:"Not signed in to this site.",shareBadUrlMsg:"Enter a valid http(s) site URL (e.g. https://example.com).",shareLoginOpenedMsg:'A WordPress login tab was opened. Sign in there, then come back and click "refresh".',shareUploading:"Uploading to WordPress…",shareCopied:"4 URLs + AI prompt copied to clipboard",shareExpiresInPrefix:"Expires in",shareDialogHeader:"Share links created",shareDialogIntro:"These 4 URLs are publicly fetchable for 24 hours. Anyone with a link can read the file.",shareLblHtml:"HTML",shareLblCss:"CSS",shareLblJs:"JS",shareLblImage:"Image",shareCopyOne:"Copy",shareCopyAll:"Copy AI prompt + 4 URLs",shareCopyAllDone:"Copied!",shareCopyOneDone:"Copied",shareRevokeBtn:"Revoke now",shareRevokedMsg:"Revoked. The links no longer work.",shareRevokingMsg:"Revoking…",shareCloseBtn:"Close",shareExpiredMsg:"Expired",shareQuotaPrefix:"Free shares used:",shareQuotaUnlimited:"Pro plan — unlimited shares",shareUpgradeHint:"Upgrade to Pro for unlimited shares",shareUpgradeBtn:"Upgrade to Pro",shareManageSubscriptionBtn:"Manage subscription",billingPlanLabel:"Plan",billingPlanFree:"Free",billingPlanPro:"Pro",billingSubscriptionLabel:"Subscription",billingPriceTagline:"$5 / month — unlimited Smart Shares",billingUpgradeAlwaysHint:"Tip: Pro removes the 5-share lifetime cap.",shareQuotaFreeReachedMsg:"Free quota reached. Upgrade to Inspect Page Pro to keep sharing.",billingFeatureUnlimited:"Unlimited Smart Shares (no 5-share cap)",billingFeaturePriority:"Priority share-link delivery",billingFeatureVisitors:"Recent visitors drawer in WP admin",billingFeatureSupport:"Email support from the maintainer",billingProToast:"You're Pro 🎉 — unlimited Smart Shares unlocked.",workspaceLabel:"Workspace",workspaceRoleOwner:"Owner",workspaceRoleAdmin:"Admin",workspaceRoleMember:"Member",workspaceLicenseFree:"Free",workspaceLicenseActive:"Pro",workspaceLicensePastDue:"Past due",workspaceLicenseCanceled:"Canceled",workspaceLoadingMsg:"Loading workspaces…",workspaceNoneMsg:"No workspace selected.",workspaceRecentLabel:"Showing recent shares for",workspacePickerOpen:"Switch workspace",workspacePickerTitle:"Choose workspace",workspacePickerCurrent:"Current",workspacePickerManage:"Manage in WordPress",workspacePickerClose:"Close"},Cm=`I'm sharing a UI component with you. Please read all four files first, then apply the change I describe at the end.

HTML:    {{HTML_REF}}
CSS:     {{CSS_REF}}
JS:      {{JS_REF}}
Image:   {{IMAGE_REF}}

Instructions:
1. Fetch and read the HTML to understand the current markup and structure.
2. Fetch and read the CSS to understand the current styling, tokens, and breakpoints.
3. Fetch and read the JS to understand any current behavior.
4. Open the image to see how the component currently renders.
5. Then make the change requested below — modify HTML/CSS/JS only. Do not break the existing structure, semantics, or responsiveness unless I ask for it. You may add animations, restyle, or adjust layout.

My request:
<write your change request here>
`;function Kp(e){return Cm.replace("{{HTML_REF}}",e.htmlRef).replace("{{CSS_REF}}",e.cssRef).replace("{{JS_REF}}",e.jsRef).replace("{{IMAGE_REF}}",e.imageRef)}function xt(e,t){return e.replace(/\{(\w+)\}/g,(n,r)=>{const o=t[r];return o==null?`{${r}}`:String(o)})}function no(e){if(!Number.isFinite(e)||e<=0)return"0 B";const t=["B","KB","MB","GB"];let n=0,r=e;for(;r>=1024&&n<t.length-1;)r/=1024,n+=1;return`${r<10&&n>0?r.toFixed(1):Math.round(r)} ${t[n]}`}function Em(e){const t=[];if(typeof e.shadowRootsExpanded=="number"&&e.shadowRootsExpanded>0&&t.push([N.telemetryShadowRoots,String(e.shadowRootsExpanded)]),typeof e.fontsInlined=="number"&&e.fontsInlined>0){const r=typeof e.fontsBytesInlined=="number"?` (${no(e.fontsBytesInlined)})`:"";t.push([N.telemetryFonts,`${e.fontsInlined}${r}`])}typeof e.iframesSameOrigin=="number"&&e.iframesSameOrigin>0&&t.push([N.telemetryIframesSame,String(e.iframesSameOrigin)]),typeof e.iframesCrossOrigin=="number"&&e.iframesCrossOrigin>0&&t.push([N.telemetryIframesCross,String(e.iframesCrossOrigin)]);const n=e.linkedStylesheets+e.inlineStyles;if(n>0&&t.push([N.telemetryStylesheets,String(n)]),e.captureFrames>0&&t.push([N.telemetryFrames,String(e.captureFrames)]),typeof e.elementOuterHtmlBytes=="number"&&e.elementOuterHtmlBytes>0&&t.push([N.telemetryElementOuterHtml,no(e.elementOuterHtmlBytes)]),typeof e.elementMatchedRules=="number"&&e.elementMatchedRules>0&&t.push([N.telemetryElementMatchedRules,String(e.elementMatchedRules)]),typeof e.elementComputedDiffEntries=="number"&&e.elementComputedDiffEntries>0&&t.push([N.telemetryElementComputedDiff,String(e.elementComputedDiffEntries)]),typeof e.elementContextPngBytes=="number"&&e.elementContextPngBytes>0){const r=e.elementIsolatedSkipped===!0?N.telemetryElementIsolatedSkipped:typeof e.elementIsolatedPngBytes=="number"&&e.elementIsolatedPngBytes>0?no(e.elementIsolatedPngBytes):null,o=r?`${no(e.elementContextPngBytes)} + ${r}`:no(e.elementContextPngBytes);t.push([N.telemetryElementScreenshots,o])}return t}function ji(e){throw new Error('Could not dynamically require "'+e+'". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.')}var Jp={exports:{}};/*!

  JSZip v3.10.1 - A JavaScript class for generating and reading zip files
  <http://stuartk.com/jszip>

  (c) 2009-2016 Stuart Knightley <stuart [at] stuartk.com>
  Dual licenced under the MIT license or GPLv3. See https://raw.github.com/Stuk/jszip/main/LICENSE.markdown.

  JSZip uses the library pako released under the MIT license :
  https://github.com/nodeca/pako/blob/main/LICENSE
  */(function(e,t){(function(n){e.exports=n()})(function(){return function n(r,o,i){function a(u,y){if(!o[u]){if(!r[u]){var x=typeof ji=="function"&&ji;if(!y&&x)return x(u,!0);if(l)return l(u,!0);var w=new Error("Cannot find module '"+u+"'");throw w.code="MODULE_NOT_FOUND",w}var h=o[u]={exports:{}};r[u][0].call(h.exports,function(b){var f=r[u][1][b];return a(f||b)},h,h.exports,n,r,o,i)}return o[u].exports}for(var l=typeof ji=="function"&&ji,s=0;s<i.length;s++)a(i[s]);return a}({1:[function(n,r,o){var i=n("./utils"),a=n("./support"),l="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";o.encode=function(s){for(var u,y,x,w,h,b,f,v=[],p=0,d=s.length,g=d,S=i.getTypeOf(s)!=="string";p<s.length;)g=d-p,x=S?(u=s[p++],y=p<d?s[p++]:0,p<d?s[p++]:0):(u=s.charCodeAt(p++),y=p<d?s.charCodeAt(p++):0,p<d?s.charCodeAt(p++):0),w=u>>2,h=(3&u)<<4|y>>4,b=1<g?(15&y)<<2|x>>6:64,f=2<g?63&x:64,v.push(l.charAt(w)+l.charAt(h)+l.charAt(b)+l.charAt(f));return v.join("")},o.decode=function(s){var u,y,x,w,h,b,f=0,v=0,p="data:";if(s.substr(0,p.length)===p)throw new Error("Invalid base64 input, it looks like a data url.");var d,g=3*(s=s.replace(/[^A-Za-z0-9+/=]/g,"")).length/4;if(s.charAt(s.length-1)===l.charAt(64)&&g--,s.charAt(s.length-2)===l.charAt(64)&&g--,g%1!=0)throw new Error("Invalid base64 input, bad content length.");for(d=a.uint8array?new Uint8Array(0|g):new Array(0|g);f<s.length;)u=l.indexOf(s.charAt(f++))<<2|(w=l.indexOf(s.charAt(f++)))>>4,y=(15&w)<<4|(h=l.indexOf(s.charAt(f++)))>>2,x=(3&h)<<6|(b=l.indexOf(s.charAt(f++))),d[v++]=u,h!==64&&(d[v++]=y),b!==64&&(d[v++]=x);return d}},{"./support":30,"./utils":32}],2:[function(n,r,o){var i=n("./external"),a=n("./stream/DataWorker"),l=n("./stream/Crc32Probe"),s=n("./stream/DataLengthProbe");function u(y,x,w,h,b){this.compressedSize=y,this.uncompressedSize=x,this.crc32=w,this.compression=h,this.compressedContent=b}u.prototype={getContentWorker:function(){var y=new a(i.Promise.resolve(this.compressedContent)).pipe(this.compression.uncompressWorker()).pipe(new s("data_length")),x=this;return y.on("end",function(){if(this.streamInfo.data_length!==x.uncompressedSize)throw new Error("Bug : uncompressed data size mismatch")}),y},getCompressedWorker:function(){return new a(i.Promise.resolve(this.compressedContent)).withStreamInfo("compressedSize",this.compressedSize).withStreamInfo("uncompressedSize",this.uncompressedSize).withStreamInfo("crc32",this.crc32).withStreamInfo("compression",this.compression)}},u.createWorkerFrom=function(y,x,w){return y.pipe(new l).pipe(new s("uncompressedSize")).pipe(x.compressWorker(w)).pipe(new s("compressedSize")).withStreamInfo("compression",x)},r.exports=u},{"./external":6,"./stream/Crc32Probe":25,"./stream/DataLengthProbe":26,"./stream/DataWorker":27}],3:[function(n,r,o){var i=n("./stream/GenericWorker");o.STORE={magic:"\0\0",compressWorker:function(){return new i("STORE compression")},uncompressWorker:function(){return new i("STORE decompression")}},o.DEFLATE=n("./flate")},{"./flate":7,"./stream/GenericWorker":28}],4:[function(n,r,o){var i=n("./utils"),a=function(){for(var l,s=[],u=0;u<256;u++){l=u;for(var y=0;y<8;y++)l=1&l?3988292384^l>>>1:l>>>1;s[u]=l}return s}();r.exports=function(l,s){return l!==void 0&&l.length?i.getTypeOf(l)!=="string"?function(u,y,x,w){var h=a,b=w+x;u^=-1;for(var f=w;f<b;f++)u=u>>>8^h[255&(u^y[f])];return-1^u}(0|s,l,l.length,0):function(u,y,x,w){var h=a,b=w+x;u^=-1;for(var f=w;f<b;f++)u=u>>>8^h[255&(u^y.charCodeAt(f))];return-1^u}(0|s,l,l.length,0):0}},{"./utils":32}],5:[function(n,r,o){o.base64=!1,o.binary=!1,o.dir=!1,o.createFolders=!0,o.date=null,o.compression=null,o.compressionOptions=null,o.comment=null,o.unixPermissions=null,o.dosPermissions=null},{}],6:[function(n,r,o){var i=null;i=typeof Promise<"u"?Promise:n("lie"),r.exports={Promise:i}},{lie:37}],7:[function(n,r,o){var i=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Uint32Array<"u",a=n("pako"),l=n("./utils"),s=n("./stream/GenericWorker"),u=i?"uint8array":"array";function y(x,w){s.call(this,"FlateWorker/"+x),this._pako=null,this._pakoAction=x,this._pakoOptions=w,this.meta={}}o.magic="\b\0",l.inherits(y,s),y.prototype.processChunk=function(x){this.meta=x.meta,this._pako===null&&this._createPako(),this._pako.push(l.transformTo(u,x.data),!1)},y.prototype.flush=function(){s.prototype.flush.call(this),this._pako===null&&this._createPako(),this._pako.push([],!0)},y.prototype.cleanUp=function(){s.prototype.cleanUp.call(this),this._pako=null},y.prototype._createPako=function(){this._pako=new a[this._pakoAction]({raw:!0,level:this._pakoOptions.level||-1});var x=this;this._pako.onData=function(w){x.push({data:w,meta:x.meta})}},o.compressWorker=function(x){return new y("Deflate",x)},o.uncompressWorker=function(){return new y("Inflate",{})}},{"./stream/GenericWorker":28,"./utils":32,pako:38}],8:[function(n,r,o){function i(h,b){var f,v="";for(f=0;f<b;f++)v+=String.fromCharCode(255&h),h>>>=8;return v}function a(h,b,f,v,p,d){var g,S,C=h.file,A=h.compression,T=d!==u.utf8encode,R=l.transformTo("string",d(C.name)),L=l.transformTo("string",u.utf8encode(C.name)),M=C.comment,ie=l.transformTo("string",d(M)),F=l.transformTo("string",u.utf8encode(M)),B=L.length!==C.name.length,k=F.length!==M.length,H="",ce="",Q="",Z=C.dir,$=C.date,O={crc32:0,compressedSize:0,uncompressedSize:0};b&&!f||(O.crc32=h.crc32,O.compressedSize=h.compressedSize,O.uncompressedSize=h.uncompressedSize);var P=0;b&&(P|=8),T||!B&&!k||(P|=2048);var I=0,re=0;Z&&(I|=16),p==="UNIX"?(re=798,I|=function(J,fe){var ee=J;return J||(ee=fe?16893:33204),(65535&ee)<<16}(C.unixPermissions,Z)):(re=20,I|=function(J){return 63&(J||0)}(C.dosPermissions)),g=$.getUTCHours(),g<<=6,g|=$.getUTCMinutes(),g<<=5,g|=$.getUTCSeconds()/2,S=$.getUTCFullYear()-1980,S<<=4,S|=$.getUTCMonth()+1,S<<=5,S|=$.getUTCDate(),B&&(ce=i(1,1)+i(y(R),4)+L,H+="up"+i(ce.length,2)+ce),k&&(Q=i(1,1)+i(y(ie),4)+F,H+="uc"+i(Q.length,2)+Q);var te="";return te+=`
\0`,te+=i(P,2),te+=A.magic,te+=i(g,2),te+=i(S,2),te+=i(O.crc32,4),te+=i(O.compressedSize,4),te+=i(O.uncompressedSize,4),te+=i(R.length,2),te+=i(H.length,2),{fileRecord:x.LOCAL_FILE_HEADER+te+R+H,dirRecord:x.CENTRAL_FILE_HEADER+i(re,2)+te+i(ie.length,2)+"\0\0\0\0"+i(I,4)+i(v,4)+R+H+ie}}var l=n("../utils"),s=n("../stream/GenericWorker"),u=n("../utf8"),y=n("../crc32"),x=n("../signature");function w(h,b,f,v){s.call(this,"ZipFileWorker"),this.bytesWritten=0,this.zipComment=b,this.zipPlatform=f,this.encodeFileName=v,this.streamFiles=h,this.accumulate=!1,this.contentBuffer=[],this.dirRecords=[],this.currentSourceOffset=0,this.entriesCount=0,this.currentFile=null,this._sources=[]}l.inherits(w,s),w.prototype.push=function(h){var b=h.meta.percent||0,f=this.entriesCount,v=this._sources.length;this.accumulate?this.contentBuffer.push(h):(this.bytesWritten+=h.data.length,s.prototype.push.call(this,{data:h.data,meta:{currentFile:this.currentFile,percent:f?(b+100*(f-v-1))/f:100}}))},w.prototype.openedSource=function(h){this.currentSourceOffset=this.bytesWritten,this.currentFile=h.file.name;var b=this.streamFiles&&!h.file.dir;if(b){var f=a(h,b,!1,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);this.push({data:f.fileRecord,meta:{percent:0}})}else this.accumulate=!0},w.prototype.closedSource=function(h){this.accumulate=!1;var b=this.streamFiles&&!h.file.dir,f=a(h,b,!0,this.currentSourceOffset,this.zipPlatform,this.encodeFileName);if(this.dirRecords.push(f.dirRecord),b)this.push({data:function(v){return x.DATA_DESCRIPTOR+i(v.crc32,4)+i(v.compressedSize,4)+i(v.uncompressedSize,4)}(h),meta:{percent:100}});else for(this.push({data:f.fileRecord,meta:{percent:0}});this.contentBuffer.length;)this.push(this.contentBuffer.shift());this.currentFile=null},w.prototype.flush=function(){for(var h=this.bytesWritten,b=0;b<this.dirRecords.length;b++)this.push({data:this.dirRecords[b],meta:{percent:100}});var f=this.bytesWritten-h,v=function(p,d,g,S,C){var A=l.transformTo("string",C(S));return x.CENTRAL_DIRECTORY_END+"\0\0\0\0"+i(p,2)+i(p,2)+i(d,4)+i(g,4)+i(A.length,2)+A}(this.dirRecords.length,f,h,this.zipComment,this.encodeFileName);this.push({data:v,meta:{percent:100}})},w.prototype.prepareNextSource=function(){this.previous=this._sources.shift(),this.openedSource(this.previous.streamInfo),this.isPaused?this.previous.pause():this.previous.resume()},w.prototype.registerPrevious=function(h){this._sources.push(h);var b=this;return h.on("data",function(f){b.processChunk(f)}),h.on("end",function(){b.closedSource(b.previous.streamInfo),b._sources.length?b.prepareNextSource():b.end()}),h.on("error",function(f){b.error(f)}),this},w.prototype.resume=function(){return!!s.prototype.resume.call(this)&&(!this.previous&&this._sources.length?(this.prepareNextSource(),!0):this.previous||this._sources.length||this.generatedError?void 0:(this.end(),!0))},w.prototype.error=function(h){var b=this._sources;if(!s.prototype.error.call(this,h))return!1;for(var f=0;f<b.length;f++)try{b[f].error(h)}catch{}return!0},w.prototype.lock=function(){s.prototype.lock.call(this);for(var h=this._sources,b=0;b<h.length;b++)h[b].lock()},r.exports=w},{"../crc32":4,"../signature":23,"../stream/GenericWorker":28,"../utf8":31,"../utils":32}],9:[function(n,r,o){var i=n("../compressions"),a=n("./ZipFileWorker");o.generateWorker=function(l,s,u){var y=new a(s.streamFiles,u,s.platform,s.encodeFileName),x=0;try{l.forEach(function(w,h){x++;var b=function(d,g){var S=d||g,C=i[S];if(!C)throw new Error(S+" is not a valid compression method !");return C}(h.options.compression,s.compression),f=h.options.compressionOptions||s.compressionOptions||{},v=h.dir,p=h.date;h._compressWorker(b,f).withStreamInfo("file",{name:w,dir:v,date:p,comment:h.comment||"",unixPermissions:h.unixPermissions,dosPermissions:h.dosPermissions}).pipe(y)}),y.entriesCount=x}catch(w){y.error(w)}return y}},{"../compressions":3,"./ZipFileWorker":8}],10:[function(n,r,o){function i(){if(!(this instanceof i))return new i;if(arguments.length)throw new Error("The constructor with parameters has been removed in JSZip 3.0, please check the upgrade guide.");this.files=Object.create(null),this.comment=null,this.root="",this.clone=function(){var a=new i;for(var l in this)typeof this[l]!="function"&&(a[l]=this[l]);return a}}(i.prototype=n("./object")).loadAsync=n("./load"),i.support=n("./support"),i.defaults=n("./defaults"),i.version="3.10.1",i.loadAsync=function(a,l){return new i().loadAsync(a,l)},i.external=n("./external"),r.exports=i},{"./defaults":5,"./external":6,"./load":11,"./object":15,"./support":30}],11:[function(n,r,o){var i=n("./utils"),a=n("./external"),l=n("./utf8"),s=n("./zipEntries"),u=n("./stream/Crc32Probe"),y=n("./nodejsUtils");function x(w){return new a.Promise(function(h,b){var f=w.decompressed.getContentWorker().pipe(new u);f.on("error",function(v){b(v)}).on("end",function(){f.streamInfo.crc32!==w.decompressed.crc32?b(new Error("Corrupted zip : CRC32 mismatch")):h()}).resume()})}r.exports=function(w,h){var b=this;return h=i.extend(h||{},{base64:!1,checkCRC32:!1,optimizedBinaryString:!1,createFolders:!1,decodeFileName:l.utf8decode}),y.isNode&&y.isStream(w)?a.Promise.reject(new Error("JSZip can't accept a stream when loading a zip file.")):i.prepareContent("the loaded zip file",w,!0,h.optimizedBinaryString,h.base64).then(function(f){var v=new s(h);return v.load(f),v}).then(function(f){var v=[a.Promise.resolve(f)],p=f.files;if(h.checkCRC32)for(var d=0;d<p.length;d++)v.push(x(p[d]));return a.Promise.all(v)}).then(function(f){for(var v=f.shift(),p=v.files,d=0;d<p.length;d++){var g=p[d],S=g.fileNameStr,C=i.resolve(g.fileNameStr);b.file(C,g.decompressed,{binary:!0,optimizedBinaryString:!0,date:g.date,dir:g.dir,comment:g.fileCommentStr.length?g.fileCommentStr:null,unixPermissions:g.unixPermissions,dosPermissions:g.dosPermissions,createFolders:h.createFolders}),g.dir||(b.file(C).unsafeOriginalName=S)}return v.zipComment.length&&(b.comment=v.zipComment),b})}},{"./external":6,"./nodejsUtils":14,"./stream/Crc32Probe":25,"./utf8":31,"./utils":32,"./zipEntries":33}],12:[function(n,r,o){var i=n("../utils"),a=n("../stream/GenericWorker");function l(s,u){a.call(this,"Nodejs stream input adapter for "+s),this._upstreamEnded=!1,this._bindStream(u)}i.inherits(l,a),l.prototype._bindStream=function(s){var u=this;(this._stream=s).pause(),s.on("data",function(y){u.push({data:y,meta:{percent:0}})}).on("error",function(y){u.isPaused?this.generatedError=y:u.error(y)}).on("end",function(){u.isPaused?u._upstreamEnded=!0:u.end()})},l.prototype.pause=function(){return!!a.prototype.pause.call(this)&&(this._stream.pause(),!0)},l.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(this._upstreamEnded?this.end():this._stream.resume(),!0)},r.exports=l},{"../stream/GenericWorker":28,"../utils":32}],13:[function(n,r,o){var i=n("readable-stream").Readable;function a(l,s,u){i.call(this,s),this._helper=l;var y=this;l.on("data",function(x,w){y.push(x)||y._helper.pause(),u&&u(w)}).on("error",function(x){y.emit("error",x)}).on("end",function(){y.push(null)})}n("../utils").inherits(a,i),a.prototype._read=function(){this._helper.resume()},r.exports=a},{"../utils":32,"readable-stream":16}],14:[function(n,r,o){r.exports={isNode:typeof Buffer<"u",newBufferFrom:function(i,a){if(Buffer.from&&Buffer.from!==Uint8Array.from)return Buffer.from(i,a);if(typeof i=="number")throw new Error('The "data" argument must not be a number');return new Buffer(i,a)},allocBuffer:function(i){if(Buffer.alloc)return Buffer.alloc(i);var a=new Buffer(i);return a.fill(0),a},isBuffer:function(i){return Buffer.isBuffer(i)},isStream:function(i){return i&&typeof i.on=="function"&&typeof i.pause=="function"&&typeof i.resume=="function"}}},{}],15:[function(n,r,o){function i(C,A,T){var R,L=l.getTypeOf(A),M=l.extend(T||{},y);M.date=M.date||new Date,M.compression!==null&&(M.compression=M.compression.toUpperCase()),typeof M.unixPermissions=="string"&&(M.unixPermissions=parseInt(M.unixPermissions,8)),M.unixPermissions&&16384&M.unixPermissions&&(M.dir=!0),M.dosPermissions&&16&M.dosPermissions&&(M.dir=!0),M.dir&&(C=p(C)),M.createFolders&&(R=v(C))&&d.call(this,R,!0);var ie=L==="string"&&M.binary===!1&&M.base64===!1;T&&T.binary!==void 0||(M.binary=!ie),(A instanceof x&&A.uncompressedSize===0||M.dir||!A||A.length===0)&&(M.base64=!1,M.binary=!0,A="",M.compression="STORE",L="string");var F=null;F=A instanceof x||A instanceof s?A:b.isNode&&b.isStream(A)?new f(C,A):l.prepareContent(C,A,M.binary,M.optimizedBinaryString,M.base64);var B=new w(C,F,M);this.files[C]=B}var a=n("./utf8"),l=n("./utils"),s=n("./stream/GenericWorker"),u=n("./stream/StreamHelper"),y=n("./defaults"),x=n("./compressedObject"),w=n("./zipObject"),h=n("./generate"),b=n("./nodejsUtils"),f=n("./nodejs/NodejsStreamInputAdapter"),v=function(C){C.slice(-1)==="/"&&(C=C.substring(0,C.length-1));var A=C.lastIndexOf("/");return 0<A?C.substring(0,A):""},p=function(C){return C.slice(-1)!=="/"&&(C+="/"),C},d=function(C,A){return A=A!==void 0?A:y.createFolders,C=p(C),this.files[C]||i.call(this,C,null,{dir:!0,createFolders:A}),this.files[C]};function g(C){return Object.prototype.toString.call(C)==="[object RegExp]"}var S={load:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},forEach:function(C){var A,T,R;for(A in this.files)R=this.files[A],(T=A.slice(this.root.length,A.length))&&A.slice(0,this.root.length)===this.root&&C(T,R)},filter:function(C){var A=[];return this.forEach(function(T,R){C(T,R)&&A.push(R)}),A},file:function(C,A,T){if(arguments.length!==1)return C=this.root+C,i.call(this,C,A,T),this;if(g(C)){var R=C;return this.filter(function(M,ie){return!ie.dir&&R.test(M)})}var L=this.files[this.root+C];return L&&!L.dir?L:null},folder:function(C){if(!C)return this;if(g(C))return this.filter(function(L,M){return M.dir&&C.test(L)});var A=this.root+C,T=d.call(this,A),R=this.clone();return R.root=T.name,R},remove:function(C){C=this.root+C;var A=this.files[C];if(A||(C.slice(-1)!=="/"&&(C+="/"),A=this.files[C]),A&&!A.dir)delete this.files[C];else for(var T=this.filter(function(L,M){return M.name.slice(0,C.length)===C}),R=0;R<T.length;R++)delete this.files[T[R].name];return this},generate:function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},generateInternalStream:function(C){var A,T={};try{if((T=l.extend(C||{},{streamFiles:!1,compression:"STORE",compressionOptions:null,type:"",platform:"DOS",comment:null,mimeType:"application/zip",encodeFileName:a.utf8encode})).type=T.type.toLowerCase(),T.compression=T.compression.toUpperCase(),T.type==="binarystring"&&(T.type="string"),!T.type)throw new Error("No output type specified.");l.checkSupport(T.type),T.platform!=="darwin"&&T.platform!=="freebsd"&&T.platform!=="linux"&&T.platform!=="sunos"||(T.platform="UNIX"),T.platform==="win32"&&(T.platform="DOS");var R=T.comment||this.comment||"";A=h.generateWorker(this,T,R)}catch(L){(A=new s("error")).error(L)}return new u(A,T.type||"string",T.mimeType)},generateAsync:function(C,A){return this.generateInternalStream(C).accumulate(A)},generateNodeStream:function(C,A){return(C=C||{}).type||(C.type="nodebuffer"),this.generateInternalStream(C).toNodejsStream(A)}};r.exports=S},{"./compressedObject":2,"./defaults":5,"./generate":9,"./nodejs/NodejsStreamInputAdapter":12,"./nodejsUtils":14,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31,"./utils":32,"./zipObject":35}],16:[function(n,r,o){r.exports=n("stream")},{stream:void 0}],17:[function(n,r,o){var i=n("./DataReader");function a(l){i.call(this,l);for(var s=0;s<this.data.length;s++)l[s]=255&l[s]}n("../utils").inherits(a,i),a.prototype.byteAt=function(l){return this.data[this.zero+l]},a.prototype.lastIndexOfSignature=function(l){for(var s=l.charCodeAt(0),u=l.charCodeAt(1),y=l.charCodeAt(2),x=l.charCodeAt(3),w=this.length-4;0<=w;--w)if(this.data[w]===s&&this.data[w+1]===u&&this.data[w+2]===y&&this.data[w+3]===x)return w-this.zero;return-1},a.prototype.readAndCheckSignature=function(l){var s=l.charCodeAt(0),u=l.charCodeAt(1),y=l.charCodeAt(2),x=l.charCodeAt(3),w=this.readData(4);return s===w[0]&&u===w[1]&&y===w[2]&&x===w[3]},a.prototype.readData=function(l){if(this.checkOffset(l),l===0)return[];var s=this.data.slice(this.zero+this.index,this.zero+this.index+l);return this.index+=l,s},r.exports=a},{"../utils":32,"./DataReader":18}],18:[function(n,r,o){var i=n("../utils");function a(l){this.data=l,this.length=l.length,this.index=0,this.zero=0}a.prototype={checkOffset:function(l){this.checkIndex(this.index+l)},checkIndex:function(l){if(this.length<this.zero+l||l<0)throw new Error("End of data reached (data length = "+this.length+", asked index = "+l+"). Corrupted zip ?")},setIndex:function(l){this.checkIndex(l),this.index=l},skip:function(l){this.setIndex(this.index+l)},byteAt:function(){},readInt:function(l){var s,u=0;for(this.checkOffset(l),s=this.index+l-1;s>=this.index;s--)u=(u<<8)+this.byteAt(s);return this.index+=l,u},readString:function(l){return i.transformTo("string",this.readData(l))},readData:function(){},lastIndexOfSignature:function(){},readAndCheckSignature:function(){},readDate:function(){var l=this.readInt(4);return new Date(Date.UTC(1980+(l>>25&127),(l>>21&15)-1,l>>16&31,l>>11&31,l>>5&63,(31&l)<<1))}},r.exports=a},{"../utils":32}],19:[function(n,r,o){var i=n("./Uint8ArrayReader");function a(l){i.call(this,l)}n("../utils").inherits(a,i),a.prototype.readData=function(l){this.checkOffset(l);var s=this.data.slice(this.zero+this.index,this.zero+this.index+l);return this.index+=l,s},r.exports=a},{"../utils":32,"./Uint8ArrayReader":21}],20:[function(n,r,o){var i=n("./DataReader");function a(l){i.call(this,l)}n("../utils").inherits(a,i),a.prototype.byteAt=function(l){return this.data.charCodeAt(this.zero+l)},a.prototype.lastIndexOfSignature=function(l){return this.data.lastIndexOf(l)-this.zero},a.prototype.readAndCheckSignature=function(l){return l===this.readData(4)},a.prototype.readData=function(l){this.checkOffset(l);var s=this.data.slice(this.zero+this.index,this.zero+this.index+l);return this.index+=l,s},r.exports=a},{"../utils":32,"./DataReader":18}],21:[function(n,r,o){var i=n("./ArrayReader");function a(l){i.call(this,l)}n("../utils").inherits(a,i),a.prototype.readData=function(l){if(this.checkOffset(l),l===0)return new Uint8Array(0);var s=this.data.subarray(this.zero+this.index,this.zero+this.index+l);return this.index+=l,s},r.exports=a},{"../utils":32,"./ArrayReader":17}],22:[function(n,r,o){var i=n("../utils"),a=n("../support"),l=n("./ArrayReader"),s=n("./StringReader"),u=n("./NodeBufferReader"),y=n("./Uint8ArrayReader");r.exports=function(x){var w=i.getTypeOf(x);return i.checkSupport(w),w!=="string"||a.uint8array?w==="nodebuffer"?new u(x):a.uint8array?new y(i.transformTo("uint8array",x)):new l(i.transformTo("array",x)):new s(x)}},{"../support":30,"../utils":32,"./ArrayReader":17,"./NodeBufferReader":19,"./StringReader":20,"./Uint8ArrayReader":21}],23:[function(n,r,o){o.LOCAL_FILE_HEADER="PK",o.CENTRAL_FILE_HEADER="PK",o.CENTRAL_DIRECTORY_END="PK",o.ZIP64_CENTRAL_DIRECTORY_LOCATOR="PK\x07",o.ZIP64_CENTRAL_DIRECTORY_END="PK",o.DATA_DESCRIPTOR="PK\x07\b"},{}],24:[function(n,r,o){var i=n("./GenericWorker"),a=n("../utils");function l(s){i.call(this,"ConvertWorker to "+s),this.destType=s}a.inherits(l,i),l.prototype.processChunk=function(s){this.push({data:a.transformTo(this.destType,s.data),meta:s.meta})},r.exports=l},{"../utils":32,"./GenericWorker":28}],25:[function(n,r,o){var i=n("./GenericWorker"),a=n("../crc32");function l(){i.call(this,"Crc32Probe"),this.withStreamInfo("crc32",0)}n("../utils").inherits(l,i),l.prototype.processChunk=function(s){this.streamInfo.crc32=a(s.data,this.streamInfo.crc32||0),this.push(s)},r.exports=l},{"../crc32":4,"../utils":32,"./GenericWorker":28}],26:[function(n,r,o){var i=n("../utils"),a=n("./GenericWorker");function l(s){a.call(this,"DataLengthProbe for "+s),this.propName=s,this.withStreamInfo(s,0)}i.inherits(l,a),l.prototype.processChunk=function(s){if(s){var u=this.streamInfo[this.propName]||0;this.streamInfo[this.propName]=u+s.data.length}a.prototype.processChunk.call(this,s)},r.exports=l},{"../utils":32,"./GenericWorker":28}],27:[function(n,r,o){var i=n("../utils"),a=n("./GenericWorker");function l(s){a.call(this,"DataWorker");var u=this;this.dataIsReady=!1,this.index=0,this.max=0,this.data=null,this.type="",this._tickScheduled=!1,s.then(function(y){u.dataIsReady=!0,u.data=y,u.max=y&&y.length||0,u.type=i.getTypeOf(y),u.isPaused||u._tickAndRepeat()},function(y){u.error(y)})}i.inherits(l,a),l.prototype.cleanUp=function(){a.prototype.cleanUp.call(this),this.data=null},l.prototype.resume=function(){return!!a.prototype.resume.call(this)&&(!this._tickScheduled&&this.dataIsReady&&(this._tickScheduled=!0,i.delay(this._tickAndRepeat,[],this)),!0)},l.prototype._tickAndRepeat=function(){this._tickScheduled=!1,this.isPaused||this.isFinished||(this._tick(),this.isFinished||(i.delay(this._tickAndRepeat,[],this),this._tickScheduled=!0))},l.prototype._tick=function(){if(this.isPaused||this.isFinished)return!1;var s=null,u=Math.min(this.max,this.index+16384);if(this.index>=this.max)return this.end();switch(this.type){case"string":s=this.data.substring(this.index,u);break;case"uint8array":s=this.data.subarray(this.index,u);break;case"array":case"nodebuffer":s=this.data.slice(this.index,u)}return this.index=u,this.push({data:s,meta:{percent:this.max?this.index/this.max*100:0}})},r.exports=l},{"../utils":32,"./GenericWorker":28}],28:[function(n,r,o){function i(a){this.name=a||"default",this.streamInfo={},this.generatedError=null,this.extraStreamInfo={},this.isPaused=!0,this.isFinished=!1,this.isLocked=!1,this._listeners={data:[],end:[],error:[]},this.previous=null}i.prototype={push:function(a){this.emit("data",a)},end:function(){if(this.isFinished)return!1;this.flush();try{this.emit("end"),this.cleanUp(),this.isFinished=!0}catch(a){this.emit("error",a)}return!0},error:function(a){return!this.isFinished&&(this.isPaused?this.generatedError=a:(this.isFinished=!0,this.emit("error",a),this.previous&&this.previous.error(a),this.cleanUp()),!0)},on:function(a,l){return this._listeners[a].push(l),this},cleanUp:function(){this.streamInfo=this.generatedError=this.extraStreamInfo=null,this._listeners=[]},emit:function(a,l){if(this._listeners[a])for(var s=0;s<this._listeners[a].length;s++)this._listeners[a][s].call(this,l)},pipe:function(a){return a.registerPrevious(this)},registerPrevious:function(a){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.streamInfo=a.streamInfo,this.mergeStreamInfo(),this.previous=a;var l=this;return a.on("data",function(s){l.processChunk(s)}),a.on("end",function(){l.end()}),a.on("error",function(s){l.error(s)}),this},pause:function(){return!this.isPaused&&!this.isFinished&&(this.isPaused=!0,this.previous&&this.previous.pause(),!0)},resume:function(){if(!this.isPaused||this.isFinished)return!1;var a=this.isPaused=!1;return this.generatedError&&(this.error(this.generatedError),a=!0),this.previous&&this.previous.resume(),!a},flush:function(){},processChunk:function(a){this.push(a)},withStreamInfo:function(a,l){return this.extraStreamInfo[a]=l,this.mergeStreamInfo(),this},mergeStreamInfo:function(){for(var a in this.extraStreamInfo)Object.prototype.hasOwnProperty.call(this.extraStreamInfo,a)&&(this.streamInfo[a]=this.extraStreamInfo[a])},lock:function(){if(this.isLocked)throw new Error("The stream '"+this+"' has already been used.");this.isLocked=!0,this.previous&&this.previous.lock()},toString:function(){var a="Worker "+this.name;return this.previous?this.previous+" -> "+a:a}},r.exports=i},{}],29:[function(n,r,o){var i=n("../utils"),a=n("./ConvertWorker"),l=n("./GenericWorker"),s=n("../base64"),u=n("../support"),y=n("../external"),x=null;if(u.nodestream)try{x=n("../nodejs/NodejsStreamOutputAdapter")}catch{}function w(b,f){return new y.Promise(function(v,p){var d=[],g=b._internalType,S=b._outputType,C=b._mimeType;b.on("data",function(A,T){d.push(A),f&&f(T)}).on("error",function(A){d=[],p(A)}).on("end",function(){try{var A=function(T,R,L){switch(T){case"blob":return i.newBlob(i.transformTo("arraybuffer",R),L);case"base64":return s.encode(R);default:return i.transformTo(T,R)}}(S,function(T,R){var L,M=0,ie=null,F=0;for(L=0;L<R.length;L++)F+=R[L].length;switch(T){case"string":return R.join("");case"array":return Array.prototype.concat.apply([],R);case"uint8array":for(ie=new Uint8Array(F),L=0;L<R.length;L++)ie.set(R[L],M),M+=R[L].length;return ie;case"nodebuffer":return Buffer.concat(R);default:throw new Error("concat : unsupported type '"+T+"'")}}(g,d),C);v(A)}catch(T){p(T)}d=[]}).resume()})}function h(b,f,v){var p=f;switch(f){case"blob":case"arraybuffer":p="uint8array";break;case"base64":p="string"}try{this._internalType=p,this._outputType=f,this._mimeType=v,i.checkSupport(p),this._worker=b.pipe(new a(p)),b.lock()}catch(d){this._worker=new l("error"),this._worker.error(d)}}h.prototype={accumulate:function(b){return w(this,b)},on:function(b,f){var v=this;return b==="data"?this._worker.on(b,function(p){f.call(v,p.data,p.meta)}):this._worker.on(b,function(){i.delay(f,arguments,v)}),this},resume:function(){return i.delay(this._worker.resume,[],this._worker),this},pause:function(){return this._worker.pause(),this},toNodejsStream:function(b){if(i.checkSupport("nodestream"),this._outputType!=="nodebuffer")throw new Error(this._outputType+" is not supported by this method");return new x(this,{objectMode:this._outputType!=="nodebuffer"},b)}},r.exports=h},{"../base64":1,"../external":6,"../nodejs/NodejsStreamOutputAdapter":13,"../support":30,"../utils":32,"./ConvertWorker":24,"./GenericWorker":28}],30:[function(n,r,o){if(o.base64=!0,o.array=!0,o.string=!0,o.arraybuffer=typeof ArrayBuffer<"u"&&typeof Uint8Array<"u",o.nodebuffer=typeof Buffer<"u",o.uint8array=typeof Uint8Array<"u",typeof ArrayBuffer>"u")o.blob=!1;else{var i=new ArrayBuffer(0);try{o.blob=new Blob([i],{type:"application/zip"}).size===0}catch{try{var a=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);a.append(i),o.blob=a.getBlob("application/zip").size===0}catch{o.blob=!1}}}try{o.nodestream=!!n("readable-stream").Readable}catch{o.nodestream=!1}},{"readable-stream":16}],31:[function(n,r,o){for(var i=n("./utils"),a=n("./support"),l=n("./nodejsUtils"),s=n("./stream/GenericWorker"),u=new Array(256),y=0;y<256;y++)u[y]=252<=y?6:248<=y?5:240<=y?4:224<=y?3:192<=y?2:1;u[254]=u[254]=1;function x(){s.call(this,"utf-8 decode"),this.leftOver=null}function w(){s.call(this,"utf-8 encode")}o.utf8encode=function(h){return a.nodebuffer?l.newBufferFrom(h,"utf-8"):function(b){var f,v,p,d,g,S=b.length,C=0;for(d=0;d<S;d++)(64512&(v=b.charCodeAt(d)))==55296&&d+1<S&&(64512&(p=b.charCodeAt(d+1)))==56320&&(v=65536+(v-55296<<10)+(p-56320),d++),C+=v<128?1:v<2048?2:v<65536?3:4;for(f=a.uint8array?new Uint8Array(C):new Array(C),d=g=0;g<C;d++)(64512&(v=b.charCodeAt(d)))==55296&&d+1<S&&(64512&(p=b.charCodeAt(d+1)))==56320&&(v=65536+(v-55296<<10)+(p-56320),d++),v<128?f[g++]=v:(v<2048?f[g++]=192|v>>>6:(v<65536?f[g++]=224|v>>>12:(f[g++]=240|v>>>18,f[g++]=128|v>>>12&63),f[g++]=128|v>>>6&63),f[g++]=128|63&v);return f}(h)},o.utf8decode=function(h){return a.nodebuffer?i.transformTo("nodebuffer",h).toString("utf-8"):function(b){var f,v,p,d,g=b.length,S=new Array(2*g);for(f=v=0;f<g;)if((p=b[f++])<128)S[v++]=p;else if(4<(d=u[p]))S[v++]=65533,f+=d-1;else{for(p&=d===2?31:d===3?15:7;1<d&&f<g;)p=p<<6|63&b[f++],d--;1<d?S[v++]=65533:p<65536?S[v++]=p:(p-=65536,S[v++]=55296|p>>10&1023,S[v++]=56320|1023&p)}return S.length!==v&&(S.subarray?S=S.subarray(0,v):S.length=v),i.applyFromCharCode(S)}(h=i.transformTo(a.uint8array?"uint8array":"array",h))},i.inherits(x,s),x.prototype.processChunk=function(h){var b=i.transformTo(a.uint8array?"uint8array":"array",h.data);if(this.leftOver&&this.leftOver.length){if(a.uint8array){var f=b;(b=new Uint8Array(f.length+this.leftOver.length)).set(this.leftOver,0),b.set(f,this.leftOver.length)}else b=this.leftOver.concat(b);this.leftOver=null}var v=function(d,g){var S;for((g=g||d.length)>d.length&&(g=d.length),S=g-1;0<=S&&(192&d[S])==128;)S--;return S<0||S===0?g:S+u[d[S]]>g?S:g}(b),p=b;v!==b.length&&(a.uint8array?(p=b.subarray(0,v),this.leftOver=b.subarray(v,b.length)):(p=b.slice(0,v),this.leftOver=b.slice(v,b.length))),this.push({data:o.utf8decode(p),meta:h.meta})},x.prototype.flush=function(){this.leftOver&&this.leftOver.length&&(this.push({data:o.utf8decode(this.leftOver),meta:{}}),this.leftOver=null)},o.Utf8DecodeWorker=x,i.inherits(w,s),w.prototype.processChunk=function(h){this.push({data:o.utf8encode(h.data),meta:h.meta})},o.Utf8EncodeWorker=w},{"./nodejsUtils":14,"./stream/GenericWorker":28,"./support":30,"./utils":32}],32:[function(n,r,o){var i=n("./support"),a=n("./base64"),l=n("./nodejsUtils"),s=n("./external");function u(f){return f}function y(f,v){for(var p=0;p<f.length;++p)v[p]=255&f.charCodeAt(p);return v}n("setimmediate"),o.newBlob=function(f,v){o.checkSupport("blob");try{return new Blob([f],{type:v})}catch{try{var p=new(self.BlobBuilder||self.WebKitBlobBuilder||self.MozBlobBuilder||self.MSBlobBuilder);return p.append(f),p.getBlob(v)}catch{throw new Error("Bug : can't construct the Blob.")}}};var x={stringifyByChunk:function(f,v,p){var d=[],g=0,S=f.length;if(S<=p)return String.fromCharCode.apply(null,f);for(;g<S;)v==="array"||v==="nodebuffer"?d.push(String.fromCharCode.apply(null,f.slice(g,Math.min(g+p,S)))):d.push(String.fromCharCode.apply(null,f.subarray(g,Math.min(g+p,S)))),g+=p;return d.join("")},stringifyByChar:function(f){for(var v="",p=0;p<f.length;p++)v+=String.fromCharCode(f[p]);return v},applyCanBeUsed:{uint8array:function(){try{return i.uint8array&&String.fromCharCode.apply(null,new Uint8Array(1)).length===1}catch{return!1}}(),nodebuffer:function(){try{return i.nodebuffer&&String.fromCharCode.apply(null,l.allocBuffer(1)).length===1}catch{return!1}}()}};function w(f){var v=65536,p=o.getTypeOf(f),d=!0;if(p==="uint8array"?d=x.applyCanBeUsed.uint8array:p==="nodebuffer"&&(d=x.applyCanBeUsed.nodebuffer),d)for(;1<v;)try{return x.stringifyByChunk(f,p,v)}catch{v=Math.floor(v/2)}return x.stringifyByChar(f)}function h(f,v){for(var p=0;p<f.length;p++)v[p]=f[p];return v}o.applyFromCharCode=w;var b={};b.string={string:u,array:function(f){return y(f,new Array(f.length))},arraybuffer:function(f){return b.string.uint8array(f).buffer},uint8array:function(f){return y(f,new Uint8Array(f.length))},nodebuffer:function(f){return y(f,l.allocBuffer(f.length))}},b.array={string:w,array:u,arraybuffer:function(f){return new Uint8Array(f).buffer},uint8array:function(f){return new Uint8Array(f)},nodebuffer:function(f){return l.newBufferFrom(f)}},b.arraybuffer={string:function(f){return w(new Uint8Array(f))},array:function(f){return h(new Uint8Array(f),new Array(f.byteLength))},arraybuffer:u,uint8array:function(f){return new Uint8Array(f)},nodebuffer:function(f){return l.newBufferFrom(new Uint8Array(f))}},b.uint8array={string:w,array:function(f){return h(f,new Array(f.length))},arraybuffer:function(f){return f.buffer},uint8array:u,nodebuffer:function(f){return l.newBufferFrom(f)}},b.nodebuffer={string:w,array:function(f){return h(f,new Array(f.length))},arraybuffer:function(f){return b.nodebuffer.uint8array(f).buffer},uint8array:function(f){return h(f,new Uint8Array(f.length))},nodebuffer:u},o.transformTo=function(f,v){if(v=v||"",!f)return v;o.checkSupport(f);var p=o.getTypeOf(v);return b[p][f](v)},o.resolve=function(f){for(var v=f.split("/"),p=[],d=0;d<v.length;d++){var g=v[d];g==="."||g===""&&d!==0&&d!==v.length-1||(g===".."?p.pop():p.push(g))}return p.join("/")},o.getTypeOf=function(f){return typeof f=="string"?"string":Object.prototype.toString.call(f)==="[object Array]"?"array":i.nodebuffer&&l.isBuffer(f)?"nodebuffer":i.uint8array&&f instanceof Uint8Array?"uint8array":i.arraybuffer&&f instanceof ArrayBuffer?"arraybuffer":void 0},o.checkSupport=function(f){if(!i[f.toLowerCase()])throw new Error(f+" is not supported by this platform")},o.MAX_VALUE_16BITS=65535,o.MAX_VALUE_32BITS=-1,o.pretty=function(f){var v,p,d="";for(p=0;p<(f||"").length;p++)d+="\\x"+((v=f.charCodeAt(p))<16?"0":"")+v.toString(16).toUpperCase();return d},o.delay=function(f,v,p){setImmediate(function(){f.apply(p||null,v||[])})},o.inherits=function(f,v){function p(){}p.prototype=v.prototype,f.prototype=new p},o.extend=function(){var f,v,p={};for(f=0;f<arguments.length;f++)for(v in arguments[f])Object.prototype.hasOwnProperty.call(arguments[f],v)&&p[v]===void 0&&(p[v]=arguments[f][v]);return p},o.prepareContent=function(f,v,p,d,g){return s.Promise.resolve(v).then(function(S){return i.blob&&(S instanceof Blob||["[object File]","[object Blob]"].indexOf(Object.prototype.toString.call(S))!==-1)&&typeof FileReader<"u"?new s.Promise(function(C,A){var T=new FileReader;T.onload=function(R){C(R.target.result)},T.onerror=function(R){A(R.target.error)},T.readAsArrayBuffer(S)}):S}).then(function(S){var C=o.getTypeOf(S);return C?(C==="arraybuffer"?S=o.transformTo("uint8array",S):C==="string"&&(g?S=a.decode(S):p&&d!==!0&&(S=function(A){return y(A,i.uint8array?new Uint8Array(A.length):new Array(A.length))}(S))),S):s.Promise.reject(new Error("Can't read the data of '"+f+"'. Is it in a supported JavaScript type (String, Blob, ArrayBuffer, etc) ?"))})}},{"./base64":1,"./external":6,"./nodejsUtils":14,"./support":30,setimmediate:54}],33:[function(n,r,o){var i=n("./reader/readerFor"),a=n("./utils"),l=n("./signature"),s=n("./zipEntry"),u=n("./support");function y(x){this.files=[],this.loadOptions=x}y.prototype={checkSignature:function(x){if(!this.reader.readAndCheckSignature(x)){this.reader.index-=4;var w=this.reader.readString(4);throw new Error("Corrupted zip or bug: unexpected signature ("+a.pretty(w)+", expected "+a.pretty(x)+")")}},isSignature:function(x,w){var h=this.reader.index;this.reader.setIndex(x);var b=this.reader.readString(4)===w;return this.reader.setIndex(h),b},readBlockEndOfCentral:function(){this.diskNumber=this.reader.readInt(2),this.diskWithCentralDirStart=this.reader.readInt(2),this.centralDirRecordsOnThisDisk=this.reader.readInt(2),this.centralDirRecords=this.reader.readInt(2),this.centralDirSize=this.reader.readInt(4),this.centralDirOffset=this.reader.readInt(4),this.zipCommentLength=this.reader.readInt(2);var x=this.reader.readData(this.zipCommentLength),w=u.uint8array?"uint8array":"array",h=a.transformTo(w,x);this.zipComment=this.loadOptions.decodeFileName(h)},readBlockZip64EndOfCentral:function(){this.zip64EndOfCentralSize=this.reader.readInt(8),this.reader.skip(4),this.diskNumber=this.reader.readInt(4),this.diskWithCentralDirStart=this.reader.readInt(4),this.centralDirRecordsOnThisDisk=this.reader.readInt(8),this.centralDirRecords=this.reader.readInt(8),this.centralDirSize=this.reader.readInt(8),this.centralDirOffset=this.reader.readInt(8),this.zip64ExtensibleData={};for(var x,w,h,b=this.zip64EndOfCentralSize-44;0<b;)x=this.reader.readInt(2),w=this.reader.readInt(4),h=this.reader.readData(w),this.zip64ExtensibleData[x]={id:x,length:w,value:h}},readBlockZip64EndOfCentralLocator:function(){if(this.diskWithZip64CentralDirStart=this.reader.readInt(4),this.relativeOffsetEndOfZip64CentralDir=this.reader.readInt(8),this.disksCount=this.reader.readInt(4),1<this.disksCount)throw new Error("Multi-volumes zip are not supported")},readLocalFiles:function(){var x,w;for(x=0;x<this.files.length;x++)w=this.files[x],this.reader.setIndex(w.localHeaderOffset),this.checkSignature(l.LOCAL_FILE_HEADER),w.readLocalPart(this.reader),w.handleUTF8(),w.processAttributes()},readCentralDir:function(){var x;for(this.reader.setIndex(this.centralDirOffset);this.reader.readAndCheckSignature(l.CENTRAL_FILE_HEADER);)(x=new s({zip64:this.zip64},this.loadOptions)).readCentralPart(this.reader),this.files.push(x);if(this.centralDirRecords!==this.files.length&&this.centralDirRecords!==0&&this.files.length===0)throw new Error("Corrupted zip or bug: expected "+this.centralDirRecords+" records in central dir, got "+this.files.length)},readEndOfCentral:function(){var x=this.reader.lastIndexOfSignature(l.CENTRAL_DIRECTORY_END);if(x<0)throw this.isSignature(0,l.LOCAL_FILE_HEADER)?new Error("Corrupted zip: can't find end of central directory"):new Error("Can't find end of central directory : is this a zip file ? If it is, see https://stuk.github.io/jszip/documentation/howto/read_zip.html");this.reader.setIndex(x);var w=x;if(this.checkSignature(l.CENTRAL_DIRECTORY_END),this.readBlockEndOfCentral(),this.diskNumber===a.MAX_VALUE_16BITS||this.diskWithCentralDirStart===a.MAX_VALUE_16BITS||this.centralDirRecordsOnThisDisk===a.MAX_VALUE_16BITS||this.centralDirRecords===a.MAX_VALUE_16BITS||this.centralDirSize===a.MAX_VALUE_32BITS||this.centralDirOffset===a.MAX_VALUE_32BITS){if(this.zip64=!0,(x=this.reader.lastIndexOfSignature(l.ZIP64_CENTRAL_DIRECTORY_LOCATOR))<0)throw new Error("Corrupted zip: can't find the ZIP64 end of central directory locator");if(this.reader.setIndex(x),this.checkSignature(l.ZIP64_CENTRAL_DIRECTORY_LOCATOR),this.readBlockZip64EndOfCentralLocator(),!this.isSignature(this.relativeOffsetEndOfZip64CentralDir,l.ZIP64_CENTRAL_DIRECTORY_END)&&(this.relativeOffsetEndOfZip64CentralDir=this.reader.lastIndexOfSignature(l.ZIP64_CENTRAL_DIRECTORY_END),this.relativeOffsetEndOfZip64CentralDir<0))throw new Error("Corrupted zip: can't find the ZIP64 end of central directory");this.reader.setIndex(this.relativeOffsetEndOfZip64CentralDir),this.checkSignature(l.ZIP64_CENTRAL_DIRECTORY_END),this.readBlockZip64EndOfCentral()}var h=this.centralDirOffset+this.centralDirSize;this.zip64&&(h+=20,h+=12+this.zip64EndOfCentralSize);var b=w-h;if(0<b)this.isSignature(w,l.CENTRAL_FILE_HEADER)||(this.reader.zero=b);else if(b<0)throw new Error("Corrupted zip: missing "+Math.abs(b)+" bytes.")},prepareReader:function(x){this.reader=i(x)},load:function(x){this.prepareReader(x),this.readEndOfCentral(),this.readCentralDir(),this.readLocalFiles()}},r.exports=y},{"./reader/readerFor":22,"./signature":23,"./support":30,"./utils":32,"./zipEntry":34}],34:[function(n,r,o){var i=n("./reader/readerFor"),a=n("./utils"),l=n("./compressedObject"),s=n("./crc32"),u=n("./utf8"),y=n("./compressions"),x=n("./support");function w(h,b){this.options=h,this.loadOptions=b}w.prototype={isEncrypted:function(){return(1&this.bitFlag)==1},useUTF8:function(){return(2048&this.bitFlag)==2048},readLocalPart:function(h){var b,f;if(h.skip(22),this.fileNameLength=h.readInt(2),f=h.readInt(2),this.fileName=h.readData(this.fileNameLength),h.skip(f),this.compressedSize===-1||this.uncompressedSize===-1)throw new Error("Bug or corrupted zip : didn't get enough information from the central directory (compressedSize === -1 || uncompressedSize === -1)");if((b=function(v){for(var p in y)if(Object.prototype.hasOwnProperty.call(y,p)&&y[p].magic===v)return y[p];return null}(this.compressionMethod))===null)throw new Error("Corrupted zip : compression "+a.pretty(this.compressionMethod)+" unknown (inner file : "+a.transformTo("string",this.fileName)+")");this.decompressed=new l(this.compressedSize,this.uncompressedSize,this.crc32,b,h.readData(this.compressedSize))},readCentralPart:function(h){this.versionMadeBy=h.readInt(2),h.skip(2),this.bitFlag=h.readInt(2),this.compressionMethod=h.readString(2),this.date=h.readDate(),this.crc32=h.readInt(4),this.compressedSize=h.readInt(4),this.uncompressedSize=h.readInt(4);var b=h.readInt(2);if(this.extraFieldsLength=h.readInt(2),this.fileCommentLength=h.readInt(2),this.diskNumberStart=h.readInt(2),this.internalFileAttributes=h.readInt(2),this.externalFileAttributes=h.readInt(4),this.localHeaderOffset=h.readInt(4),this.isEncrypted())throw new Error("Encrypted zip are not supported");h.skip(b),this.readExtraFields(h),this.parseZIP64ExtraField(h),this.fileComment=h.readData(this.fileCommentLength)},processAttributes:function(){this.unixPermissions=null,this.dosPermissions=null;var h=this.versionMadeBy>>8;this.dir=!!(16&this.externalFileAttributes),h==0&&(this.dosPermissions=63&this.externalFileAttributes),h==3&&(this.unixPermissions=this.externalFileAttributes>>16&65535),this.dir||this.fileNameStr.slice(-1)!=="/"||(this.dir=!0)},parseZIP64ExtraField:function(){if(this.extraFields[1]){var h=i(this.extraFields[1].value);this.uncompressedSize===a.MAX_VALUE_32BITS&&(this.uncompressedSize=h.readInt(8)),this.compressedSize===a.MAX_VALUE_32BITS&&(this.compressedSize=h.readInt(8)),this.localHeaderOffset===a.MAX_VALUE_32BITS&&(this.localHeaderOffset=h.readInt(8)),this.diskNumberStart===a.MAX_VALUE_32BITS&&(this.diskNumberStart=h.readInt(4))}},readExtraFields:function(h){var b,f,v,p=h.index+this.extraFieldsLength;for(this.extraFields||(this.extraFields={});h.index+4<p;)b=h.readInt(2),f=h.readInt(2),v=h.readData(f),this.extraFields[b]={id:b,length:f,value:v};h.setIndex(p)},handleUTF8:function(){var h=x.uint8array?"uint8array":"array";if(this.useUTF8())this.fileNameStr=u.utf8decode(this.fileName),this.fileCommentStr=u.utf8decode(this.fileComment);else{var b=this.findExtraFieldUnicodePath();if(b!==null)this.fileNameStr=b;else{var f=a.transformTo(h,this.fileName);this.fileNameStr=this.loadOptions.decodeFileName(f)}var v=this.findExtraFieldUnicodeComment();if(v!==null)this.fileCommentStr=v;else{var p=a.transformTo(h,this.fileComment);this.fileCommentStr=this.loadOptions.decodeFileName(p)}}},findExtraFieldUnicodePath:function(){var h=this.extraFields[28789];if(h){var b=i(h.value);return b.readInt(1)!==1||s(this.fileName)!==b.readInt(4)?null:u.utf8decode(b.readData(h.length-5))}return null},findExtraFieldUnicodeComment:function(){var h=this.extraFields[25461];if(h){var b=i(h.value);return b.readInt(1)!==1||s(this.fileComment)!==b.readInt(4)?null:u.utf8decode(b.readData(h.length-5))}return null}},r.exports=w},{"./compressedObject":2,"./compressions":3,"./crc32":4,"./reader/readerFor":22,"./support":30,"./utf8":31,"./utils":32}],35:[function(n,r,o){function i(b,f,v){this.name=b,this.dir=v.dir,this.date=v.date,this.comment=v.comment,this.unixPermissions=v.unixPermissions,this.dosPermissions=v.dosPermissions,this._data=f,this._dataBinary=v.binary,this.options={compression:v.compression,compressionOptions:v.compressionOptions}}var a=n("./stream/StreamHelper"),l=n("./stream/DataWorker"),s=n("./utf8"),u=n("./compressedObject"),y=n("./stream/GenericWorker");i.prototype={internalStream:function(b){var f=null,v="string";try{if(!b)throw new Error("No output type specified.");var p=(v=b.toLowerCase())==="string"||v==="text";v!=="binarystring"&&v!=="text"||(v="string"),f=this._decompressWorker();var d=!this._dataBinary;d&&!p&&(f=f.pipe(new s.Utf8EncodeWorker)),!d&&p&&(f=f.pipe(new s.Utf8DecodeWorker))}catch(g){(f=new y("error")).error(g)}return new a(f,v,"")},async:function(b,f){return this.internalStream(b).accumulate(f)},nodeStream:function(b,f){return this.internalStream(b||"nodebuffer").toNodejsStream(f)},_compressWorker:function(b,f){if(this._data instanceof u&&this._data.compression.magic===b.magic)return this._data.getCompressedWorker();var v=this._decompressWorker();return this._dataBinary||(v=v.pipe(new s.Utf8EncodeWorker)),u.createWorkerFrom(v,b,f)},_decompressWorker:function(){return this._data instanceof u?this._data.getContentWorker():this._data instanceof y?this._data:new l(this._data)}};for(var x=["asText","asBinary","asNodeBuffer","asUint8Array","asArrayBuffer"],w=function(){throw new Error("This method has been removed in JSZip 3.0, please check the upgrade guide.")},h=0;h<x.length;h++)i.prototype[x[h]]=w;r.exports=i},{"./compressedObject":2,"./stream/DataWorker":27,"./stream/GenericWorker":28,"./stream/StreamHelper":29,"./utf8":31}],36:[function(n,r,o){(function(i){var a,l,s=i.MutationObserver||i.WebKitMutationObserver;if(s){var u=0,y=new s(b),x=i.document.createTextNode("");y.observe(x,{characterData:!0}),a=function(){x.data=u=++u%2}}else if(i.setImmediate||i.MessageChannel===void 0)a="document"in i&&"onreadystatechange"in i.document.createElement("script")?function(){var f=i.document.createElement("script");f.onreadystatechange=function(){b(),f.onreadystatechange=null,f.parentNode.removeChild(f),f=null},i.document.documentElement.appendChild(f)}:function(){setTimeout(b,0)};else{var w=new i.MessageChannel;w.port1.onmessage=b,a=function(){w.port2.postMessage(0)}}var h=[];function b(){var f,v;l=!0;for(var p=h.length;p;){for(v=h,h=[],f=-1;++f<p;)v[f]();p=h.length}l=!1}r.exports=function(f){h.push(f)!==1||l||a()}}).call(this,typeof po<"u"?po:typeof self<"u"?self:typeof window<"u"?window:{})},{}],37:[function(n,r,o){var i=n("immediate");function a(){}var l={},s=["REJECTED"],u=["FULFILLED"],y=["PENDING"];function x(p){if(typeof p!="function")throw new TypeError("resolver must be a function");this.state=y,this.queue=[],this.outcome=void 0,p!==a&&f(this,p)}function w(p,d,g){this.promise=p,typeof d=="function"&&(this.onFulfilled=d,this.callFulfilled=this.otherCallFulfilled),typeof g=="function"&&(this.onRejected=g,this.callRejected=this.otherCallRejected)}function h(p,d,g){i(function(){var S;try{S=d(g)}catch(C){return l.reject(p,C)}S===p?l.reject(p,new TypeError("Cannot resolve promise with itself")):l.resolve(p,S)})}function b(p){var d=p&&p.then;if(p&&(typeof p=="object"||typeof p=="function")&&typeof d=="function")return function(){d.apply(p,arguments)}}function f(p,d){var g=!1;function S(T){g||(g=!0,l.reject(p,T))}function C(T){g||(g=!0,l.resolve(p,T))}var A=v(function(){d(C,S)});A.status==="error"&&S(A.value)}function v(p,d){var g={};try{g.value=p(d),g.status="success"}catch(S){g.status="error",g.value=S}return g}(r.exports=x).prototype.finally=function(p){if(typeof p!="function")return this;var d=this.constructor;return this.then(function(g){return d.resolve(p()).then(function(){return g})},function(g){return d.resolve(p()).then(function(){throw g})})},x.prototype.catch=function(p){return this.then(null,p)},x.prototype.then=function(p,d){if(typeof p!="function"&&this.state===u||typeof d!="function"&&this.state===s)return this;var g=new this.constructor(a);return this.state!==y?h(g,this.state===u?p:d,this.outcome):this.queue.push(new w(g,p,d)),g},w.prototype.callFulfilled=function(p){l.resolve(this.promise,p)},w.prototype.otherCallFulfilled=function(p){h(this.promise,this.onFulfilled,p)},w.prototype.callRejected=function(p){l.reject(this.promise,p)},w.prototype.otherCallRejected=function(p){h(this.promise,this.onRejected,p)},l.resolve=function(p,d){var g=v(b,d);if(g.status==="error")return l.reject(p,g.value);var S=g.value;if(S)f(p,S);else{p.state=u,p.outcome=d;for(var C=-1,A=p.queue.length;++C<A;)p.queue[C].callFulfilled(d)}return p},l.reject=function(p,d){p.state=s,p.outcome=d;for(var g=-1,S=p.queue.length;++g<S;)p.queue[g].callRejected(d);return p},x.resolve=function(p){return p instanceof this?p:l.resolve(new this(a),p)},x.reject=function(p){var d=new this(a);return l.reject(d,p)},x.all=function(p){var d=this;if(Object.prototype.toString.call(p)!=="[object Array]")return this.reject(new TypeError("must be an array"));var g=p.length,S=!1;if(!g)return this.resolve([]);for(var C=new Array(g),A=0,T=-1,R=new this(a);++T<g;)L(p[T],T);return R;function L(M,ie){d.resolve(M).then(function(F){C[ie]=F,++A!==g||S||(S=!0,l.resolve(R,C))},function(F){S||(S=!0,l.reject(R,F))})}},x.race=function(p){var d=this;if(Object.prototype.toString.call(p)!=="[object Array]")return this.reject(new TypeError("must be an array"));var g=p.length,S=!1;if(!g)return this.resolve([]);for(var C=-1,A=new this(a);++C<g;)T=p[C],d.resolve(T).then(function(R){S||(S=!0,l.resolve(A,R))},function(R){S||(S=!0,l.reject(A,R))});var T;return A}},{immediate:36}],38:[function(n,r,o){var i={};(0,n("./lib/utils/common").assign)(i,n("./lib/deflate"),n("./lib/inflate"),n("./lib/zlib/constants")),r.exports=i},{"./lib/deflate":39,"./lib/inflate":40,"./lib/utils/common":41,"./lib/zlib/constants":44}],39:[function(n,r,o){var i=n("./zlib/deflate"),a=n("./utils/common"),l=n("./utils/strings"),s=n("./zlib/messages"),u=n("./zlib/zstream"),y=Object.prototype.toString,x=0,w=-1,h=0,b=8;function f(p){if(!(this instanceof f))return new f(p);this.options=a.assign({level:w,method:b,chunkSize:16384,windowBits:15,memLevel:8,strategy:h,to:""},p||{});var d=this.options;d.raw&&0<d.windowBits?d.windowBits=-d.windowBits:d.gzip&&0<d.windowBits&&d.windowBits<16&&(d.windowBits+=16),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new u,this.strm.avail_out=0;var g=i.deflateInit2(this.strm,d.level,d.method,d.windowBits,d.memLevel,d.strategy);if(g!==x)throw new Error(s[g]);if(d.header&&i.deflateSetHeader(this.strm,d.header),d.dictionary){var S;if(S=typeof d.dictionary=="string"?l.string2buf(d.dictionary):y.call(d.dictionary)==="[object ArrayBuffer]"?new Uint8Array(d.dictionary):d.dictionary,(g=i.deflateSetDictionary(this.strm,S))!==x)throw new Error(s[g]);this._dict_set=!0}}function v(p,d){var g=new f(d);if(g.push(p,!0),g.err)throw g.msg||s[g.err];return g.result}f.prototype.push=function(p,d){var g,S,C=this.strm,A=this.options.chunkSize;if(this.ended)return!1;S=d===~~d?d:d===!0?4:0,typeof p=="string"?C.input=l.string2buf(p):y.call(p)==="[object ArrayBuffer]"?C.input=new Uint8Array(p):C.input=p,C.next_in=0,C.avail_in=C.input.length;do{if(C.avail_out===0&&(C.output=new a.Buf8(A),C.next_out=0,C.avail_out=A),(g=i.deflate(C,S))!==1&&g!==x)return this.onEnd(g),!(this.ended=!0);C.avail_out!==0&&(C.avail_in!==0||S!==4&&S!==2)||(this.options.to==="string"?this.onData(l.buf2binstring(a.shrinkBuf(C.output,C.next_out))):this.onData(a.shrinkBuf(C.output,C.next_out)))}while((0<C.avail_in||C.avail_out===0)&&g!==1);return S===4?(g=i.deflateEnd(this.strm),this.onEnd(g),this.ended=!0,g===x):S!==2||(this.onEnd(x),!(C.avail_out=0))},f.prototype.onData=function(p){this.chunks.push(p)},f.prototype.onEnd=function(p){p===x&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=a.flattenChunks(this.chunks)),this.chunks=[],this.err=p,this.msg=this.strm.msg},o.Deflate=f,o.deflate=v,o.deflateRaw=function(p,d){return(d=d||{}).raw=!0,v(p,d)},o.gzip=function(p,d){return(d=d||{}).gzip=!0,v(p,d)}},{"./utils/common":41,"./utils/strings":42,"./zlib/deflate":46,"./zlib/messages":51,"./zlib/zstream":53}],40:[function(n,r,o){var i=n("./zlib/inflate"),a=n("./utils/common"),l=n("./utils/strings"),s=n("./zlib/constants"),u=n("./zlib/messages"),y=n("./zlib/zstream"),x=n("./zlib/gzheader"),w=Object.prototype.toString;function h(f){if(!(this instanceof h))return new h(f);this.options=a.assign({chunkSize:16384,windowBits:0,to:""},f||{});var v=this.options;v.raw&&0<=v.windowBits&&v.windowBits<16&&(v.windowBits=-v.windowBits,v.windowBits===0&&(v.windowBits=-15)),!(0<=v.windowBits&&v.windowBits<16)||f&&f.windowBits||(v.windowBits+=32),15<v.windowBits&&v.windowBits<48&&!(15&v.windowBits)&&(v.windowBits|=15),this.err=0,this.msg="",this.ended=!1,this.chunks=[],this.strm=new y,this.strm.avail_out=0;var p=i.inflateInit2(this.strm,v.windowBits);if(p!==s.Z_OK)throw new Error(u[p]);this.header=new x,i.inflateGetHeader(this.strm,this.header)}function b(f,v){var p=new h(v);if(p.push(f,!0),p.err)throw p.msg||u[p.err];return p.result}h.prototype.push=function(f,v){var p,d,g,S,C,A,T=this.strm,R=this.options.chunkSize,L=this.options.dictionary,M=!1;if(this.ended)return!1;d=v===~~v?v:v===!0?s.Z_FINISH:s.Z_NO_FLUSH,typeof f=="string"?T.input=l.binstring2buf(f):w.call(f)==="[object ArrayBuffer]"?T.input=new Uint8Array(f):T.input=f,T.next_in=0,T.avail_in=T.input.length;do{if(T.avail_out===0&&(T.output=new a.Buf8(R),T.next_out=0,T.avail_out=R),(p=i.inflate(T,s.Z_NO_FLUSH))===s.Z_NEED_DICT&&L&&(A=typeof L=="string"?l.string2buf(L):w.call(L)==="[object ArrayBuffer]"?new Uint8Array(L):L,p=i.inflateSetDictionary(this.strm,A)),p===s.Z_BUF_ERROR&&M===!0&&(p=s.Z_OK,M=!1),p!==s.Z_STREAM_END&&p!==s.Z_OK)return this.onEnd(p),!(this.ended=!0);T.next_out&&(T.avail_out!==0&&p!==s.Z_STREAM_END&&(T.avail_in!==0||d!==s.Z_FINISH&&d!==s.Z_SYNC_FLUSH)||(this.options.to==="string"?(g=l.utf8border(T.output,T.next_out),S=T.next_out-g,C=l.buf2string(T.output,g),T.next_out=S,T.avail_out=R-S,S&&a.arraySet(T.output,T.output,g,S,0),this.onData(C)):this.onData(a.shrinkBuf(T.output,T.next_out)))),T.avail_in===0&&T.avail_out===0&&(M=!0)}while((0<T.avail_in||T.avail_out===0)&&p!==s.Z_STREAM_END);return p===s.Z_STREAM_END&&(d=s.Z_FINISH),d===s.Z_FINISH?(p=i.inflateEnd(this.strm),this.onEnd(p),this.ended=!0,p===s.Z_OK):d!==s.Z_SYNC_FLUSH||(this.onEnd(s.Z_OK),!(T.avail_out=0))},h.prototype.onData=function(f){this.chunks.push(f)},h.prototype.onEnd=function(f){f===s.Z_OK&&(this.options.to==="string"?this.result=this.chunks.join(""):this.result=a.flattenChunks(this.chunks)),this.chunks=[],this.err=f,this.msg=this.strm.msg},o.Inflate=h,o.inflate=b,o.inflateRaw=function(f,v){return(v=v||{}).raw=!0,b(f,v)},o.ungzip=b},{"./utils/common":41,"./utils/strings":42,"./zlib/constants":44,"./zlib/gzheader":47,"./zlib/inflate":49,"./zlib/messages":51,"./zlib/zstream":53}],41:[function(n,r,o){var i=typeof Uint8Array<"u"&&typeof Uint16Array<"u"&&typeof Int32Array<"u";o.assign=function(s){for(var u=Array.prototype.slice.call(arguments,1);u.length;){var y=u.shift();if(y){if(typeof y!="object")throw new TypeError(y+"must be non-object");for(var x in y)y.hasOwnProperty(x)&&(s[x]=y[x])}}return s},o.shrinkBuf=function(s,u){return s.length===u?s:s.subarray?s.subarray(0,u):(s.length=u,s)};var a={arraySet:function(s,u,y,x,w){if(u.subarray&&s.subarray)s.set(u.subarray(y,y+x),w);else for(var h=0;h<x;h++)s[w+h]=u[y+h]},flattenChunks:function(s){var u,y,x,w,h,b;for(u=x=0,y=s.length;u<y;u++)x+=s[u].length;for(b=new Uint8Array(x),u=w=0,y=s.length;u<y;u++)h=s[u],b.set(h,w),w+=h.length;return b}},l={arraySet:function(s,u,y,x,w){for(var h=0;h<x;h++)s[w+h]=u[y+h]},flattenChunks:function(s){return[].concat.apply([],s)}};o.setTyped=function(s){s?(o.Buf8=Uint8Array,o.Buf16=Uint16Array,o.Buf32=Int32Array,o.assign(o,a)):(o.Buf8=Array,o.Buf16=Array,o.Buf32=Array,o.assign(o,l))},o.setTyped(i)},{}],42:[function(n,r,o){var i=n("./common"),a=!0,l=!0;try{String.fromCharCode.apply(null,[0])}catch{a=!1}try{String.fromCharCode.apply(null,new Uint8Array(1))}catch{l=!1}for(var s=new i.Buf8(256),u=0;u<256;u++)s[u]=252<=u?6:248<=u?5:240<=u?4:224<=u?3:192<=u?2:1;function y(x,w){if(w<65537&&(x.subarray&&l||!x.subarray&&a))return String.fromCharCode.apply(null,i.shrinkBuf(x,w));for(var h="",b=0;b<w;b++)h+=String.fromCharCode(x[b]);return h}s[254]=s[254]=1,o.string2buf=function(x){var w,h,b,f,v,p=x.length,d=0;for(f=0;f<p;f++)(64512&(h=x.charCodeAt(f)))==55296&&f+1<p&&(64512&(b=x.charCodeAt(f+1)))==56320&&(h=65536+(h-55296<<10)+(b-56320),f++),d+=h<128?1:h<2048?2:h<65536?3:4;for(w=new i.Buf8(d),f=v=0;v<d;f++)(64512&(h=x.charCodeAt(f)))==55296&&f+1<p&&(64512&(b=x.charCodeAt(f+1)))==56320&&(h=65536+(h-55296<<10)+(b-56320),f++),h<128?w[v++]=h:(h<2048?w[v++]=192|h>>>6:(h<65536?w[v++]=224|h>>>12:(w[v++]=240|h>>>18,w[v++]=128|h>>>12&63),w[v++]=128|h>>>6&63),w[v++]=128|63&h);return w},o.buf2binstring=function(x){return y(x,x.length)},o.binstring2buf=function(x){for(var w=new i.Buf8(x.length),h=0,b=w.length;h<b;h++)w[h]=x.charCodeAt(h);return w},o.buf2string=function(x,w){var h,b,f,v,p=w||x.length,d=new Array(2*p);for(h=b=0;h<p;)if((f=x[h++])<128)d[b++]=f;else if(4<(v=s[f]))d[b++]=65533,h+=v-1;else{for(f&=v===2?31:v===3?15:7;1<v&&h<p;)f=f<<6|63&x[h++],v--;1<v?d[b++]=65533:f<65536?d[b++]=f:(f-=65536,d[b++]=55296|f>>10&1023,d[b++]=56320|1023&f)}return y(d,b)},o.utf8border=function(x,w){var h;for((w=w||x.length)>x.length&&(w=x.length),h=w-1;0<=h&&(192&x[h])==128;)h--;return h<0||h===0?w:h+s[x[h]]>w?h:w}},{"./common":41}],43:[function(n,r,o){r.exports=function(i,a,l,s){for(var u=65535&i|0,y=i>>>16&65535|0,x=0;l!==0;){for(l-=x=2e3<l?2e3:l;y=y+(u=u+a[s++]|0)|0,--x;);u%=65521,y%=65521}return u|y<<16|0}},{}],44:[function(n,r,o){r.exports={Z_NO_FLUSH:0,Z_PARTIAL_FLUSH:1,Z_SYNC_FLUSH:2,Z_FULL_FLUSH:3,Z_FINISH:4,Z_BLOCK:5,Z_TREES:6,Z_OK:0,Z_STREAM_END:1,Z_NEED_DICT:2,Z_ERRNO:-1,Z_STREAM_ERROR:-2,Z_DATA_ERROR:-3,Z_BUF_ERROR:-5,Z_NO_COMPRESSION:0,Z_BEST_SPEED:1,Z_BEST_COMPRESSION:9,Z_DEFAULT_COMPRESSION:-1,Z_FILTERED:1,Z_HUFFMAN_ONLY:2,Z_RLE:3,Z_FIXED:4,Z_DEFAULT_STRATEGY:0,Z_BINARY:0,Z_TEXT:1,Z_UNKNOWN:2,Z_DEFLATED:8}},{}],45:[function(n,r,o){var i=function(){for(var a,l=[],s=0;s<256;s++){a=s;for(var u=0;u<8;u++)a=1&a?3988292384^a>>>1:a>>>1;l[s]=a}return l}();r.exports=function(a,l,s,u){var y=i,x=u+s;a^=-1;for(var w=u;w<x;w++)a=a>>>8^y[255&(a^l[w])];return-1^a}},{}],46:[function(n,r,o){var i,a=n("../utils/common"),l=n("./trees"),s=n("./adler32"),u=n("./crc32"),y=n("./messages"),x=0,w=4,h=0,b=-2,f=-1,v=4,p=2,d=8,g=9,S=286,C=30,A=19,T=2*S+1,R=15,L=3,M=258,ie=M+L+1,F=42,B=113,k=1,H=2,ce=3,Q=4;function Z(m,W){return m.msg=y[W],W}function $(m){return(m<<1)-(4<m?9:0)}function O(m){for(var W=m.length;0<=--W;)m[W]=0}function P(m){var W=m.state,U=W.pending;U>m.avail_out&&(U=m.avail_out),U!==0&&(a.arraySet(m.output,W.pending_buf,W.pending_out,U,m.next_out),m.next_out+=U,W.pending_out+=U,m.total_out+=U,m.avail_out-=U,W.pending-=U,W.pending===0&&(W.pending_out=0))}function I(m,W){l._tr_flush_block(m,0<=m.block_start?m.block_start:-1,m.strstart-m.block_start,W),m.block_start=m.strstart,P(m.strm)}function re(m,W){m.pending_buf[m.pending++]=W}function te(m,W){m.pending_buf[m.pending++]=W>>>8&255,m.pending_buf[m.pending++]=255&W}function J(m,W){var U,j,E=m.max_chain_length,z=m.strstart,Y=m.prev_length,X=m.nice_match,D=m.strstart>m.w_size-ie?m.strstart-(m.w_size-ie):0,q=m.window,le=m.w_mask,ne=m.prev,se=m.strstart+M,_e=q[z+Y-1],me=q[z+Y];m.prev_length>=m.good_match&&(E>>=2),X>m.lookahead&&(X=m.lookahead);do if(q[(U=W)+Y]===me&&q[U+Y-1]===_e&&q[U]===q[z]&&q[++U]===q[z+1]){z+=2,U++;do;while(q[++z]===q[++U]&&q[++z]===q[++U]&&q[++z]===q[++U]&&q[++z]===q[++U]&&q[++z]===q[++U]&&q[++z]===q[++U]&&q[++z]===q[++U]&&q[++z]===q[++U]&&z<se);if(j=M-(se-z),z=se-M,Y<j){if(m.match_start=W,X<=(Y=j))break;_e=q[z+Y-1],me=q[z+Y]}}while((W=ne[W&le])>D&&--E!=0);return Y<=m.lookahead?Y:m.lookahead}function fe(m){var W,U,j,E,z,Y,X,D,q,le,ne=m.w_size;do{if(E=m.window_size-m.lookahead-m.strstart,m.strstart>=ne+(ne-ie)){for(a.arraySet(m.window,m.window,ne,ne,0),m.match_start-=ne,m.strstart-=ne,m.block_start-=ne,W=U=m.hash_size;j=m.head[--W],m.head[W]=ne<=j?j-ne:0,--U;);for(W=U=ne;j=m.prev[--W],m.prev[W]=ne<=j?j-ne:0,--U;);E+=ne}if(m.strm.avail_in===0)break;if(Y=m.strm,X=m.window,D=m.strstart+m.lookahead,q=E,le=void 0,le=Y.avail_in,q<le&&(le=q),U=le===0?0:(Y.avail_in-=le,a.arraySet(X,Y.input,Y.next_in,le,D),Y.state.wrap===1?Y.adler=s(Y.adler,X,le,D):Y.state.wrap===2&&(Y.adler=u(Y.adler,X,le,D)),Y.next_in+=le,Y.total_in+=le,le),m.lookahead+=U,m.lookahead+m.insert>=L)for(z=m.strstart-m.insert,m.ins_h=m.window[z],m.ins_h=(m.ins_h<<m.hash_shift^m.window[z+1])&m.hash_mask;m.insert&&(m.ins_h=(m.ins_h<<m.hash_shift^m.window[z+L-1])&m.hash_mask,m.prev[z&m.w_mask]=m.head[m.ins_h],m.head[m.ins_h]=z,z++,m.insert--,!(m.lookahead+m.insert<L)););}while(m.lookahead<ie&&m.strm.avail_in!==0)}function ee(m,W){for(var U,j;;){if(m.lookahead<ie){if(fe(m),m.lookahead<ie&&W===x)return k;if(m.lookahead===0)break}if(U=0,m.lookahead>=L&&(m.ins_h=(m.ins_h<<m.hash_shift^m.window[m.strstart+L-1])&m.hash_mask,U=m.prev[m.strstart&m.w_mask]=m.head[m.ins_h],m.head[m.ins_h]=m.strstart),U!==0&&m.strstart-U<=m.w_size-ie&&(m.match_length=J(m,U)),m.match_length>=L)if(j=l._tr_tally(m,m.strstart-m.match_start,m.match_length-L),m.lookahead-=m.match_length,m.match_length<=m.max_lazy_match&&m.lookahead>=L){for(m.match_length--;m.strstart++,m.ins_h=(m.ins_h<<m.hash_shift^m.window[m.strstart+L-1])&m.hash_mask,U=m.prev[m.strstart&m.w_mask]=m.head[m.ins_h],m.head[m.ins_h]=m.strstart,--m.match_length!=0;);m.strstart++}else m.strstart+=m.match_length,m.match_length=0,m.ins_h=m.window[m.strstart],m.ins_h=(m.ins_h<<m.hash_shift^m.window[m.strstart+1])&m.hash_mask;else j=l._tr_tally(m,0,m.window[m.strstart]),m.lookahead--,m.strstart++;if(j&&(I(m,!1),m.strm.avail_out===0))return k}return m.insert=m.strstart<L-1?m.strstart:L-1,W===w?(I(m,!0),m.strm.avail_out===0?ce:Q):m.last_lit&&(I(m,!1),m.strm.avail_out===0)?k:H}function oe(m,W){for(var U,j,E;;){if(m.lookahead<ie){if(fe(m),m.lookahead<ie&&W===x)return k;if(m.lookahead===0)break}if(U=0,m.lookahead>=L&&(m.ins_h=(m.ins_h<<m.hash_shift^m.window[m.strstart+L-1])&m.hash_mask,U=m.prev[m.strstart&m.w_mask]=m.head[m.ins_h],m.head[m.ins_h]=m.strstart),m.prev_length=m.match_length,m.prev_match=m.match_start,m.match_length=L-1,U!==0&&m.prev_length<m.max_lazy_match&&m.strstart-U<=m.w_size-ie&&(m.match_length=J(m,U),m.match_length<=5&&(m.strategy===1||m.match_length===L&&4096<m.strstart-m.match_start)&&(m.match_length=L-1)),m.prev_length>=L&&m.match_length<=m.prev_length){for(E=m.strstart+m.lookahead-L,j=l._tr_tally(m,m.strstart-1-m.prev_match,m.prev_length-L),m.lookahead-=m.prev_length-1,m.prev_length-=2;++m.strstart<=E&&(m.ins_h=(m.ins_h<<m.hash_shift^m.window[m.strstart+L-1])&m.hash_mask,U=m.prev[m.strstart&m.w_mask]=m.head[m.ins_h],m.head[m.ins_h]=m.strstart),--m.prev_length!=0;);if(m.match_available=0,m.match_length=L-1,m.strstart++,j&&(I(m,!1),m.strm.avail_out===0))return k}else if(m.match_available){if((j=l._tr_tally(m,0,m.window[m.strstart-1]))&&I(m,!1),m.strstart++,m.lookahead--,m.strm.avail_out===0)return k}else m.match_available=1,m.strstart++,m.lookahead--}return m.match_available&&(j=l._tr_tally(m,0,m.window[m.strstart-1]),m.match_available=0),m.insert=m.strstart<L-1?m.strstart:L-1,W===w?(I(m,!0),m.strm.avail_out===0?ce:Q):m.last_lit&&(I(m,!1),m.strm.avail_out===0)?k:H}function pe(m,W,U,j,E){this.good_length=m,this.max_lazy=W,this.nice_length=U,this.max_chain=j,this.func=E}function ue(){this.strm=null,this.status=0,this.pending_buf=null,this.pending_buf_size=0,this.pending_out=0,this.pending=0,this.wrap=0,this.gzhead=null,this.gzindex=0,this.method=d,this.last_flush=-1,this.w_size=0,this.w_bits=0,this.w_mask=0,this.window=null,this.window_size=0,this.prev=null,this.head=null,this.ins_h=0,this.hash_size=0,this.hash_bits=0,this.hash_mask=0,this.hash_shift=0,this.block_start=0,this.match_length=0,this.prev_match=0,this.match_available=0,this.strstart=0,this.match_start=0,this.lookahead=0,this.prev_length=0,this.max_chain_length=0,this.max_lazy_match=0,this.level=0,this.strategy=0,this.good_match=0,this.nice_match=0,this.dyn_ltree=new a.Buf16(2*T),this.dyn_dtree=new a.Buf16(2*(2*C+1)),this.bl_tree=new a.Buf16(2*(2*A+1)),O(this.dyn_ltree),O(this.dyn_dtree),O(this.bl_tree),this.l_desc=null,this.d_desc=null,this.bl_desc=null,this.bl_count=new a.Buf16(R+1),this.heap=new a.Buf16(2*S+1),O(this.heap),this.heap_len=0,this.heap_max=0,this.depth=new a.Buf16(2*S+1),O(this.depth),this.l_buf=0,this.lit_bufsize=0,this.last_lit=0,this.d_buf=0,this.opt_len=0,this.static_len=0,this.matches=0,this.insert=0,this.bi_buf=0,this.bi_valid=0}function ye(m){var W;return m&&m.state?(m.total_in=m.total_out=0,m.data_type=p,(W=m.state).pending=0,W.pending_out=0,W.wrap<0&&(W.wrap=-W.wrap),W.status=W.wrap?F:B,m.adler=W.wrap===2?0:1,W.last_flush=x,l._tr_init(W),h):Z(m,b)}function zt(m){var W=ye(m);return W===h&&function(U){U.window_size=2*U.w_size,O(U.head),U.max_lazy_match=i[U.level].max_lazy,U.good_match=i[U.level].good_length,U.nice_match=i[U.level].nice_length,U.max_chain_length=i[U.level].max_chain,U.strstart=0,U.block_start=0,U.lookahead=0,U.insert=0,U.match_length=U.prev_length=L-1,U.match_available=0,U.ins_h=0}(m.state),W}function Nt(m,W,U,j,E,z){if(!m)return b;var Y=1;if(W===f&&(W=6),j<0?(Y=0,j=-j):15<j&&(Y=2,j-=16),E<1||g<E||U!==d||j<8||15<j||W<0||9<W||z<0||v<z)return Z(m,b);j===8&&(j=9);var X=new ue;return(m.state=X).strm=m,X.wrap=Y,X.gzhead=null,X.w_bits=j,X.w_size=1<<X.w_bits,X.w_mask=X.w_size-1,X.hash_bits=E+7,X.hash_size=1<<X.hash_bits,X.hash_mask=X.hash_size-1,X.hash_shift=~~((X.hash_bits+L-1)/L),X.window=new a.Buf8(2*X.w_size),X.head=new a.Buf16(X.hash_size),X.prev=new a.Buf16(X.w_size),X.lit_bufsize=1<<E+6,X.pending_buf_size=4*X.lit_bufsize,X.pending_buf=new a.Buf8(X.pending_buf_size),X.d_buf=1*X.lit_bufsize,X.l_buf=3*X.lit_bufsize,X.level=W,X.strategy=z,X.method=U,zt(m)}i=[new pe(0,0,0,0,function(m,W){var U=65535;for(U>m.pending_buf_size-5&&(U=m.pending_buf_size-5);;){if(m.lookahead<=1){if(fe(m),m.lookahead===0&&W===x)return k;if(m.lookahead===0)break}m.strstart+=m.lookahead,m.lookahead=0;var j=m.block_start+U;if((m.strstart===0||m.strstart>=j)&&(m.lookahead=m.strstart-j,m.strstart=j,I(m,!1),m.strm.avail_out===0)||m.strstart-m.block_start>=m.w_size-ie&&(I(m,!1),m.strm.avail_out===0))return k}return m.insert=0,W===w?(I(m,!0),m.strm.avail_out===0?ce:Q):(m.strstart>m.block_start&&(I(m,!1),m.strm.avail_out),k)}),new pe(4,4,8,4,ee),new pe(4,5,16,8,ee),new pe(4,6,32,32,ee),new pe(4,4,16,16,oe),new pe(8,16,32,32,oe),new pe(8,16,128,128,oe),new pe(8,32,128,256,oe),new pe(32,128,258,1024,oe),new pe(32,258,258,4096,oe)],o.deflateInit=function(m,W){return Nt(m,W,d,15,8,0)},o.deflateInit2=Nt,o.deflateReset=zt,o.deflateResetKeep=ye,o.deflateSetHeader=function(m,W){return m&&m.state?m.state.wrap!==2?b:(m.state.gzhead=W,h):b},o.deflate=function(m,W){var U,j,E,z;if(!m||!m.state||5<W||W<0)return m?Z(m,b):b;if(j=m.state,!m.output||!m.input&&m.avail_in!==0||j.status===666&&W!==w)return Z(m,m.avail_out===0?-5:b);if(j.strm=m,U=j.last_flush,j.last_flush=W,j.status===F)if(j.wrap===2)m.adler=0,re(j,31),re(j,139),re(j,8),j.gzhead?(re(j,(j.gzhead.text?1:0)+(j.gzhead.hcrc?2:0)+(j.gzhead.extra?4:0)+(j.gzhead.name?8:0)+(j.gzhead.comment?16:0)),re(j,255&j.gzhead.time),re(j,j.gzhead.time>>8&255),re(j,j.gzhead.time>>16&255),re(j,j.gzhead.time>>24&255),re(j,j.level===9?2:2<=j.strategy||j.level<2?4:0),re(j,255&j.gzhead.os),j.gzhead.extra&&j.gzhead.extra.length&&(re(j,255&j.gzhead.extra.length),re(j,j.gzhead.extra.length>>8&255)),j.gzhead.hcrc&&(m.adler=u(m.adler,j.pending_buf,j.pending,0)),j.gzindex=0,j.status=69):(re(j,0),re(j,0),re(j,0),re(j,0),re(j,0),re(j,j.level===9?2:2<=j.strategy||j.level<2?4:0),re(j,3),j.status=B);else{var Y=d+(j.w_bits-8<<4)<<8;Y|=(2<=j.strategy||j.level<2?0:j.level<6?1:j.level===6?2:3)<<6,j.strstart!==0&&(Y|=32),Y+=31-Y%31,j.status=B,te(j,Y),j.strstart!==0&&(te(j,m.adler>>>16),te(j,65535&m.adler)),m.adler=1}if(j.status===69)if(j.gzhead.extra){for(E=j.pending;j.gzindex<(65535&j.gzhead.extra.length)&&(j.pending!==j.pending_buf_size||(j.gzhead.hcrc&&j.pending>E&&(m.adler=u(m.adler,j.pending_buf,j.pending-E,E)),P(m),E=j.pending,j.pending!==j.pending_buf_size));)re(j,255&j.gzhead.extra[j.gzindex]),j.gzindex++;j.gzhead.hcrc&&j.pending>E&&(m.adler=u(m.adler,j.pending_buf,j.pending-E,E)),j.gzindex===j.gzhead.extra.length&&(j.gzindex=0,j.status=73)}else j.status=73;if(j.status===73)if(j.gzhead.name){E=j.pending;do{if(j.pending===j.pending_buf_size&&(j.gzhead.hcrc&&j.pending>E&&(m.adler=u(m.adler,j.pending_buf,j.pending-E,E)),P(m),E=j.pending,j.pending===j.pending_buf_size)){z=1;break}z=j.gzindex<j.gzhead.name.length?255&j.gzhead.name.charCodeAt(j.gzindex++):0,re(j,z)}while(z!==0);j.gzhead.hcrc&&j.pending>E&&(m.adler=u(m.adler,j.pending_buf,j.pending-E,E)),z===0&&(j.gzindex=0,j.status=91)}else j.status=91;if(j.status===91)if(j.gzhead.comment){E=j.pending;do{if(j.pending===j.pending_buf_size&&(j.gzhead.hcrc&&j.pending>E&&(m.adler=u(m.adler,j.pending_buf,j.pending-E,E)),P(m),E=j.pending,j.pending===j.pending_buf_size)){z=1;break}z=j.gzindex<j.gzhead.comment.length?255&j.gzhead.comment.charCodeAt(j.gzindex++):0,re(j,z)}while(z!==0);j.gzhead.hcrc&&j.pending>E&&(m.adler=u(m.adler,j.pending_buf,j.pending-E,E)),z===0&&(j.status=103)}else j.status=103;if(j.status===103&&(j.gzhead.hcrc?(j.pending+2>j.pending_buf_size&&P(m),j.pending+2<=j.pending_buf_size&&(re(j,255&m.adler),re(j,m.adler>>8&255),m.adler=0,j.status=B)):j.status=B),j.pending!==0){if(P(m),m.avail_out===0)return j.last_flush=-1,h}else if(m.avail_in===0&&$(W)<=$(U)&&W!==w)return Z(m,-5);if(j.status===666&&m.avail_in!==0)return Z(m,-5);if(m.avail_in!==0||j.lookahead!==0||W!==x&&j.status!==666){var X=j.strategy===2?function(D,q){for(var le;;){if(D.lookahead===0&&(fe(D),D.lookahead===0)){if(q===x)return k;break}if(D.match_length=0,le=l._tr_tally(D,0,D.window[D.strstart]),D.lookahead--,D.strstart++,le&&(I(D,!1),D.strm.avail_out===0))return k}return D.insert=0,q===w?(I(D,!0),D.strm.avail_out===0?ce:Q):D.last_lit&&(I(D,!1),D.strm.avail_out===0)?k:H}(j,W):j.strategy===3?function(D,q){for(var le,ne,se,_e,me=D.window;;){if(D.lookahead<=M){if(fe(D),D.lookahead<=M&&q===x)return k;if(D.lookahead===0)break}if(D.match_length=0,D.lookahead>=L&&0<D.strstart&&(ne=me[se=D.strstart-1])===me[++se]&&ne===me[++se]&&ne===me[++se]){_e=D.strstart+M;do;while(ne===me[++se]&&ne===me[++se]&&ne===me[++se]&&ne===me[++se]&&ne===me[++se]&&ne===me[++se]&&ne===me[++se]&&ne===me[++se]&&se<_e);D.match_length=M-(_e-se),D.match_length>D.lookahead&&(D.match_length=D.lookahead)}if(D.match_length>=L?(le=l._tr_tally(D,1,D.match_length-L),D.lookahead-=D.match_length,D.strstart+=D.match_length,D.match_length=0):(le=l._tr_tally(D,0,D.window[D.strstart]),D.lookahead--,D.strstart++),le&&(I(D,!1),D.strm.avail_out===0))return k}return D.insert=0,q===w?(I(D,!0),D.strm.avail_out===0?ce:Q):D.last_lit&&(I(D,!1),D.strm.avail_out===0)?k:H}(j,W):i[j.level].func(j,W);if(X!==ce&&X!==Q||(j.status=666),X===k||X===ce)return m.avail_out===0&&(j.last_flush=-1),h;if(X===H&&(W===1?l._tr_align(j):W!==5&&(l._tr_stored_block(j,0,0,!1),W===3&&(O(j.head),j.lookahead===0&&(j.strstart=0,j.block_start=0,j.insert=0))),P(m),m.avail_out===0))return j.last_flush=-1,h}return W!==w?h:j.wrap<=0?1:(j.wrap===2?(re(j,255&m.adler),re(j,m.adler>>8&255),re(j,m.adler>>16&255),re(j,m.adler>>24&255),re(j,255&m.total_in),re(j,m.total_in>>8&255),re(j,m.total_in>>16&255),re(j,m.total_in>>24&255)):(te(j,m.adler>>>16),te(j,65535&m.adler)),P(m),0<j.wrap&&(j.wrap=-j.wrap),j.pending!==0?h:1)},o.deflateEnd=function(m){var W;return m&&m.state?(W=m.state.status)!==F&&W!==69&&W!==73&&W!==91&&W!==103&&W!==B&&W!==666?Z(m,b):(m.state=null,W===B?Z(m,-3):h):b},o.deflateSetDictionary=function(m,W){var U,j,E,z,Y,X,D,q,le=W.length;if(!m||!m.state||(z=(U=m.state).wrap)===2||z===1&&U.status!==F||U.lookahead)return b;for(z===1&&(m.adler=s(m.adler,W,le,0)),U.wrap=0,le>=U.w_size&&(z===0&&(O(U.head),U.strstart=0,U.block_start=0,U.insert=0),q=new a.Buf8(U.w_size),a.arraySet(q,W,le-U.w_size,U.w_size,0),W=q,le=U.w_size),Y=m.avail_in,X=m.next_in,D=m.input,m.avail_in=le,m.next_in=0,m.input=W,fe(U);U.lookahead>=L;){for(j=U.strstart,E=U.lookahead-(L-1);U.ins_h=(U.ins_h<<U.hash_shift^U.window[j+L-1])&U.hash_mask,U.prev[j&U.w_mask]=U.head[U.ins_h],U.head[U.ins_h]=j,j++,--E;);U.strstart=j,U.lookahead=L-1,fe(U)}return U.strstart+=U.lookahead,U.block_start=U.strstart,U.insert=U.lookahead,U.lookahead=0,U.match_length=U.prev_length=L-1,U.match_available=0,m.next_in=X,m.input=D,m.avail_in=Y,U.wrap=z,h},o.deflateInfo="pako deflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./messages":51,"./trees":52}],47:[function(n,r,o){r.exports=function(){this.text=0,this.time=0,this.xflags=0,this.os=0,this.extra=null,this.extra_len=0,this.name="",this.comment="",this.hcrc=0,this.done=!1}},{}],48:[function(n,r,o){r.exports=function(i,a){var l,s,u,y,x,w,h,b,f,v,p,d,g,S,C,A,T,R,L,M,ie,F,B,k,H;l=i.state,s=i.next_in,k=i.input,u=s+(i.avail_in-5),y=i.next_out,H=i.output,x=y-(a-i.avail_out),w=y+(i.avail_out-257),h=l.dmax,b=l.wsize,f=l.whave,v=l.wnext,p=l.window,d=l.hold,g=l.bits,S=l.lencode,C=l.distcode,A=(1<<l.lenbits)-1,T=(1<<l.distbits)-1;e:do{g<15&&(d+=k[s++]<<g,g+=8,d+=k[s++]<<g,g+=8),R=S[d&A];t:for(;;){if(d>>>=L=R>>>24,g-=L,(L=R>>>16&255)===0)H[y++]=65535&R;else{if(!(16&L)){if(!(64&L)){R=S[(65535&R)+(d&(1<<L)-1)];continue t}if(32&L){l.mode=12;break e}i.msg="invalid literal/length code",l.mode=30;break e}M=65535&R,(L&=15)&&(g<L&&(d+=k[s++]<<g,g+=8),M+=d&(1<<L)-1,d>>>=L,g-=L),g<15&&(d+=k[s++]<<g,g+=8,d+=k[s++]<<g,g+=8),R=C[d&T];n:for(;;){if(d>>>=L=R>>>24,g-=L,!(16&(L=R>>>16&255))){if(!(64&L)){R=C[(65535&R)+(d&(1<<L)-1)];continue n}i.msg="invalid distance code",l.mode=30;break e}if(ie=65535&R,g<(L&=15)&&(d+=k[s++]<<g,(g+=8)<L&&(d+=k[s++]<<g,g+=8)),h<(ie+=d&(1<<L)-1)){i.msg="invalid distance too far back",l.mode=30;break e}if(d>>>=L,g-=L,(L=y-x)<ie){if(f<(L=ie-L)&&l.sane){i.msg="invalid distance too far back",l.mode=30;break e}if(B=p,(F=0)===v){if(F+=b-L,L<M){for(M-=L;H[y++]=p[F++],--L;);F=y-ie,B=H}}else if(v<L){if(F+=b+v-L,(L-=v)<M){for(M-=L;H[y++]=p[F++],--L;);if(F=0,v<M){for(M-=L=v;H[y++]=p[F++],--L;);F=y-ie,B=H}}}else if(F+=v-L,L<M){for(M-=L;H[y++]=p[F++],--L;);F=y-ie,B=H}for(;2<M;)H[y++]=B[F++],H[y++]=B[F++],H[y++]=B[F++],M-=3;M&&(H[y++]=B[F++],1<M&&(H[y++]=B[F++]))}else{for(F=y-ie;H[y++]=H[F++],H[y++]=H[F++],H[y++]=H[F++],2<(M-=3););M&&(H[y++]=H[F++],1<M&&(H[y++]=H[F++]))}break}}break}}while(s<u&&y<w);s-=M=g>>3,d&=(1<<(g-=M<<3))-1,i.next_in=s,i.next_out=y,i.avail_in=s<u?u-s+5:5-(s-u),i.avail_out=y<w?w-y+257:257-(y-w),l.hold=d,l.bits=g}},{}],49:[function(n,r,o){var i=n("../utils/common"),a=n("./adler32"),l=n("./crc32"),s=n("./inffast"),u=n("./inftrees"),y=1,x=2,w=0,h=-2,b=1,f=852,v=592;function p(F){return(F>>>24&255)+(F>>>8&65280)+((65280&F)<<8)+((255&F)<<24)}function d(){this.mode=0,this.last=!1,this.wrap=0,this.havedict=!1,this.flags=0,this.dmax=0,this.check=0,this.total=0,this.head=null,this.wbits=0,this.wsize=0,this.whave=0,this.wnext=0,this.window=null,this.hold=0,this.bits=0,this.length=0,this.offset=0,this.extra=0,this.lencode=null,this.distcode=null,this.lenbits=0,this.distbits=0,this.ncode=0,this.nlen=0,this.ndist=0,this.have=0,this.next=null,this.lens=new i.Buf16(320),this.work=new i.Buf16(288),this.lendyn=null,this.distdyn=null,this.sane=0,this.back=0,this.was=0}function g(F){var B;return F&&F.state?(B=F.state,F.total_in=F.total_out=B.total=0,F.msg="",B.wrap&&(F.adler=1&B.wrap),B.mode=b,B.last=0,B.havedict=0,B.dmax=32768,B.head=null,B.hold=0,B.bits=0,B.lencode=B.lendyn=new i.Buf32(f),B.distcode=B.distdyn=new i.Buf32(v),B.sane=1,B.back=-1,w):h}function S(F){var B;return F&&F.state?((B=F.state).wsize=0,B.whave=0,B.wnext=0,g(F)):h}function C(F,B){var k,H;return F&&F.state?(H=F.state,B<0?(k=0,B=-B):(k=1+(B>>4),B<48&&(B&=15)),B&&(B<8||15<B)?h:(H.window!==null&&H.wbits!==B&&(H.window=null),H.wrap=k,H.wbits=B,S(F))):h}function A(F,B){var k,H;return F?(H=new d,(F.state=H).window=null,(k=C(F,B))!==w&&(F.state=null),k):h}var T,R,L=!0;function M(F){if(L){var B;for(T=new i.Buf32(512),R=new i.Buf32(32),B=0;B<144;)F.lens[B++]=8;for(;B<256;)F.lens[B++]=9;for(;B<280;)F.lens[B++]=7;for(;B<288;)F.lens[B++]=8;for(u(y,F.lens,0,288,T,0,F.work,{bits:9}),B=0;B<32;)F.lens[B++]=5;u(x,F.lens,0,32,R,0,F.work,{bits:5}),L=!1}F.lencode=T,F.lenbits=9,F.distcode=R,F.distbits=5}function ie(F,B,k,H){var ce,Q=F.state;return Q.window===null&&(Q.wsize=1<<Q.wbits,Q.wnext=0,Q.whave=0,Q.window=new i.Buf8(Q.wsize)),H>=Q.wsize?(i.arraySet(Q.window,B,k-Q.wsize,Q.wsize,0),Q.wnext=0,Q.whave=Q.wsize):(H<(ce=Q.wsize-Q.wnext)&&(ce=H),i.arraySet(Q.window,B,k-H,ce,Q.wnext),(H-=ce)?(i.arraySet(Q.window,B,k-H,H,0),Q.wnext=H,Q.whave=Q.wsize):(Q.wnext+=ce,Q.wnext===Q.wsize&&(Q.wnext=0),Q.whave<Q.wsize&&(Q.whave+=ce))),0}o.inflateReset=S,o.inflateReset2=C,o.inflateResetKeep=g,o.inflateInit=function(F){return A(F,15)},o.inflateInit2=A,o.inflate=function(F,B){var k,H,ce,Q,Z,$,O,P,I,re,te,J,fe,ee,oe,pe,ue,ye,zt,Nt,m,W,U,j,E=0,z=new i.Buf8(4),Y=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15];if(!F||!F.state||!F.output||!F.input&&F.avail_in!==0)return h;(k=F.state).mode===12&&(k.mode=13),Z=F.next_out,ce=F.output,O=F.avail_out,Q=F.next_in,H=F.input,$=F.avail_in,P=k.hold,I=k.bits,re=$,te=O,W=w;e:for(;;)switch(k.mode){case b:if(k.wrap===0){k.mode=13;break}for(;I<16;){if($===0)break e;$--,P+=H[Q++]<<I,I+=8}if(2&k.wrap&&P===35615){z[k.check=0]=255&P,z[1]=P>>>8&255,k.check=l(k.check,z,2,0),I=P=0,k.mode=2;break}if(k.flags=0,k.head&&(k.head.done=!1),!(1&k.wrap)||(((255&P)<<8)+(P>>8))%31){F.msg="incorrect header check",k.mode=30;break}if((15&P)!=8){F.msg="unknown compression method",k.mode=30;break}if(I-=4,m=8+(15&(P>>>=4)),k.wbits===0)k.wbits=m;else if(m>k.wbits){F.msg="invalid window size",k.mode=30;break}k.dmax=1<<m,F.adler=k.check=1,k.mode=512&P?10:12,I=P=0;break;case 2:for(;I<16;){if($===0)break e;$--,P+=H[Q++]<<I,I+=8}if(k.flags=P,(255&k.flags)!=8){F.msg="unknown compression method",k.mode=30;break}if(57344&k.flags){F.msg="unknown header flags set",k.mode=30;break}k.head&&(k.head.text=P>>8&1),512&k.flags&&(z[0]=255&P,z[1]=P>>>8&255,k.check=l(k.check,z,2,0)),I=P=0,k.mode=3;case 3:for(;I<32;){if($===0)break e;$--,P+=H[Q++]<<I,I+=8}k.head&&(k.head.time=P),512&k.flags&&(z[0]=255&P,z[1]=P>>>8&255,z[2]=P>>>16&255,z[3]=P>>>24&255,k.check=l(k.check,z,4,0)),I=P=0,k.mode=4;case 4:for(;I<16;){if($===0)break e;$--,P+=H[Q++]<<I,I+=8}k.head&&(k.head.xflags=255&P,k.head.os=P>>8),512&k.flags&&(z[0]=255&P,z[1]=P>>>8&255,k.check=l(k.check,z,2,0)),I=P=0,k.mode=5;case 5:if(1024&k.flags){for(;I<16;){if($===0)break e;$--,P+=H[Q++]<<I,I+=8}k.length=P,k.head&&(k.head.extra_len=P),512&k.flags&&(z[0]=255&P,z[1]=P>>>8&255,k.check=l(k.check,z,2,0)),I=P=0}else k.head&&(k.head.extra=null);k.mode=6;case 6:if(1024&k.flags&&($<(J=k.length)&&(J=$),J&&(k.head&&(m=k.head.extra_len-k.length,k.head.extra||(k.head.extra=new Array(k.head.extra_len)),i.arraySet(k.head.extra,H,Q,J,m)),512&k.flags&&(k.check=l(k.check,H,J,Q)),$-=J,Q+=J,k.length-=J),k.length))break e;k.length=0,k.mode=7;case 7:if(2048&k.flags){if($===0)break e;for(J=0;m=H[Q+J++],k.head&&m&&k.length<65536&&(k.head.name+=String.fromCharCode(m)),m&&J<$;);if(512&k.flags&&(k.check=l(k.check,H,J,Q)),$-=J,Q+=J,m)break e}else k.head&&(k.head.name=null);k.length=0,k.mode=8;case 8:if(4096&k.flags){if($===0)break e;for(J=0;m=H[Q+J++],k.head&&m&&k.length<65536&&(k.head.comment+=String.fromCharCode(m)),m&&J<$;);if(512&k.flags&&(k.check=l(k.check,H,J,Q)),$-=J,Q+=J,m)break e}else k.head&&(k.head.comment=null);k.mode=9;case 9:if(512&k.flags){for(;I<16;){if($===0)break e;$--,P+=H[Q++]<<I,I+=8}if(P!==(65535&k.check)){F.msg="header crc mismatch",k.mode=30;break}I=P=0}k.head&&(k.head.hcrc=k.flags>>9&1,k.head.done=!0),F.adler=k.check=0,k.mode=12;break;case 10:for(;I<32;){if($===0)break e;$--,P+=H[Q++]<<I,I+=8}F.adler=k.check=p(P),I=P=0,k.mode=11;case 11:if(k.havedict===0)return F.next_out=Z,F.avail_out=O,F.next_in=Q,F.avail_in=$,k.hold=P,k.bits=I,2;F.adler=k.check=1,k.mode=12;case 12:if(B===5||B===6)break e;case 13:if(k.last){P>>>=7&I,I-=7&I,k.mode=27;break}for(;I<3;){if($===0)break e;$--,P+=H[Q++]<<I,I+=8}switch(k.last=1&P,I-=1,3&(P>>>=1)){case 0:k.mode=14;break;case 1:if(M(k),k.mode=20,B!==6)break;P>>>=2,I-=2;break e;case 2:k.mode=17;break;case 3:F.msg="invalid block type",k.mode=30}P>>>=2,I-=2;break;case 14:for(P>>>=7&I,I-=7&I;I<32;){if($===0)break e;$--,P+=H[Q++]<<I,I+=8}if((65535&P)!=(P>>>16^65535)){F.msg="invalid stored block lengths",k.mode=30;break}if(k.length=65535&P,I=P=0,k.mode=15,B===6)break e;case 15:k.mode=16;case 16:if(J=k.length){if($<J&&(J=$),O<J&&(J=O),J===0)break e;i.arraySet(ce,H,Q,J,Z),$-=J,Q+=J,O-=J,Z+=J,k.length-=J;break}k.mode=12;break;case 17:for(;I<14;){if($===0)break e;$--,P+=H[Q++]<<I,I+=8}if(k.nlen=257+(31&P),P>>>=5,I-=5,k.ndist=1+(31&P),P>>>=5,I-=5,k.ncode=4+(15&P),P>>>=4,I-=4,286<k.nlen||30<k.ndist){F.msg="too many length or distance symbols",k.mode=30;break}k.have=0,k.mode=18;case 18:for(;k.have<k.ncode;){for(;I<3;){if($===0)break e;$--,P+=H[Q++]<<I,I+=8}k.lens[Y[k.have++]]=7&P,P>>>=3,I-=3}for(;k.have<19;)k.lens[Y[k.have++]]=0;if(k.lencode=k.lendyn,k.lenbits=7,U={bits:k.lenbits},W=u(0,k.lens,0,19,k.lencode,0,k.work,U),k.lenbits=U.bits,W){F.msg="invalid code lengths set",k.mode=30;break}k.have=0,k.mode=19;case 19:for(;k.have<k.nlen+k.ndist;){for(;pe=(E=k.lencode[P&(1<<k.lenbits)-1])>>>16&255,ue=65535&E,!((oe=E>>>24)<=I);){if($===0)break e;$--,P+=H[Q++]<<I,I+=8}if(ue<16)P>>>=oe,I-=oe,k.lens[k.have++]=ue;else{if(ue===16){for(j=oe+2;I<j;){if($===0)break e;$--,P+=H[Q++]<<I,I+=8}if(P>>>=oe,I-=oe,k.have===0){F.msg="invalid bit length repeat",k.mode=30;break}m=k.lens[k.have-1],J=3+(3&P),P>>>=2,I-=2}else if(ue===17){for(j=oe+3;I<j;){if($===0)break e;$--,P+=H[Q++]<<I,I+=8}I-=oe,m=0,J=3+(7&(P>>>=oe)),P>>>=3,I-=3}else{for(j=oe+7;I<j;){if($===0)break e;$--,P+=H[Q++]<<I,I+=8}I-=oe,m=0,J=11+(127&(P>>>=oe)),P>>>=7,I-=7}if(k.have+J>k.nlen+k.ndist){F.msg="invalid bit length repeat",k.mode=30;break}for(;J--;)k.lens[k.have++]=m}}if(k.mode===30)break;if(k.lens[256]===0){F.msg="invalid code -- missing end-of-block",k.mode=30;break}if(k.lenbits=9,U={bits:k.lenbits},W=u(y,k.lens,0,k.nlen,k.lencode,0,k.work,U),k.lenbits=U.bits,W){F.msg="invalid literal/lengths set",k.mode=30;break}if(k.distbits=6,k.distcode=k.distdyn,U={bits:k.distbits},W=u(x,k.lens,k.nlen,k.ndist,k.distcode,0,k.work,U),k.distbits=U.bits,W){F.msg="invalid distances set",k.mode=30;break}if(k.mode=20,B===6)break e;case 20:k.mode=21;case 21:if(6<=$&&258<=O){F.next_out=Z,F.avail_out=O,F.next_in=Q,F.avail_in=$,k.hold=P,k.bits=I,s(F,te),Z=F.next_out,ce=F.output,O=F.avail_out,Q=F.next_in,H=F.input,$=F.avail_in,P=k.hold,I=k.bits,k.mode===12&&(k.back=-1);break}for(k.back=0;pe=(E=k.lencode[P&(1<<k.lenbits)-1])>>>16&255,ue=65535&E,!((oe=E>>>24)<=I);){if($===0)break e;$--,P+=H[Q++]<<I,I+=8}if(pe&&!(240&pe)){for(ye=oe,zt=pe,Nt=ue;pe=(E=k.lencode[Nt+((P&(1<<ye+zt)-1)>>ye)])>>>16&255,ue=65535&E,!(ye+(oe=E>>>24)<=I);){if($===0)break e;$--,P+=H[Q++]<<I,I+=8}P>>>=ye,I-=ye,k.back+=ye}if(P>>>=oe,I-=oe,k.back+=oe,k.length=ue,pe===0){k.mode=26;break}if(32&pe){k.back=-1,k.mode=12;break}if(64&pe){F.msg="invalid literal/length code",k.mode=30;break}k.extra=15&pe,k.mode=22;case 22:if(k.extra){for(j=k.extra;I<j;){if($===0)break e;$--,P+=H[Q++]<<I,I+=8}k.length+=P&(1<<k.extra)-1,P>>>=k.extra,I-=k.extra,k.back+=k.extra}k.was=k.length,k.mode=23;case 23:for(;pe=(E=k.distcode[P&(1<<k.distbits)-1])>>>16&255,ue=65535&E,!((oe=E>>>24)<=I);){if($===0)break e;$--,P+=H[Q++]<<I,I+=8}if(!(240&pe)){for(ye=oe,zt=pe,Nt=ue;pe=(E=k.distcode[Nt+((P&(1<<ye+zt)-1)>>ye)])>>>16&255,ue=65535&E,!(ye+(oe=E>>>24)<=I);){if($===0)break e;$--,P+=H[Q++]<<I,I+=8}P>>>=ye,I-=ye,k.back+=ye}if(P>>>=oe,I-=oe,k.back+=oe,64&pe){F.msg="invalid distance code",k.mode=30;break}k.offset=ue,k.extra=15&pe,k.mode=24;case 24:if(k.extra){for(j=k.extra;I<j;){if($===0)break e;$--,P+=H[Q++]<<I,I+=8}k.offset+=P&(1<<k.extra)-1,P>>>=k.extra,I-=k.extra,k.back+=k.extra}if(k.offset>k.dmax){F.msg="invalid distance too far back",k.mode=30;break}k.mode=25;case 25:if(O===0)break e;if(J=te-O,k.offset>J){if((J=k.offset-J)>k.whave&&k.sane){F.msg="invalid distance too far back",k.mode=30;break}fe=J>k.wnext?(J-=k.wnext,k.wsize-J):k.wnext-J,J>k.length&&(J=k.length),ee=k.window}else ee=ce,fe=Z-k.offset,J=k.length;for(O<J&&(J=O),O-=J,k.length-=J;ce[Z++]=ee[fe++],--J;);k.length===0&&(k.mode=21);break;case 26:if(O===0)break e;ce[Z++]=k.length,O--,k.mode=21;break;case 27:if(k.wrap){for(;I<32;){if($===0)break e;$--,P|=H[Q++]<<I,I+=8}if(te-=O,F.total_out+=te,k.total+=te,te&&(F.adler=k.check=k.flags?l(k.check,ce,te,Z-te):a(k.check,ce,te,Z-te)),te=O,(k.flags?P:p(P))!==k.check){F.msg="incorrect data check",k.mode=30;break}I=P=0}k.mode=28;case 28:if(k.wrap&&k.flags){for(;I<32;){if($===0)break e;$--,P+=H[Q++]<<I,I+=8}if(P!==(4294967295&k.total)){F.msg="incorrect length check",k.mode=30;break}I=P=0}k.mode=29;case 29:W=1;break e;case 30:W=-3;break e;case 31:return-4;case 32:default:return h}return F.next_out=Z,F.avail_out=O,F.next_in=Q,F.avail_in=$,k.hold=P,k.bits=I,(k.wsize||te!==F.avail_out&&k.mode<30&&(k.mode<27||B!==4))&&ie(F,F.output,F.next_out,te-F.avail_out)?(k.mode=31,-4):(re-=F.avail_in,te-=F.avail_out,F.total_in+=re,F.total_out+=te,k.total+=te,k.wrap&&te&&(F.adler=k.check=k.flags?l(k.check,ce,te,F.next_out-te):a(k.check,ce,te,F.next_out-te)),F.data_type=k.bits+(k.last?64:0)+(k.mode===12?128:0)+(k.mode===20||k.mode===15?256:0),(re==0&&te===0||B===4)&&W===w&&(W=-5),W)},o.inflateEnd=function(F){if(!F||!F.state)return h;var B=F.state;return B.window&&(B.window=null),F.state=null,w},o.inflateGetHeader=function(F,B){var k;return F&&F.state&&2&(k=F.state).wrap?((k.head=B).done=!1,w):h},o.inflateSetDictionary=function(F,B){var k,H=B.length;return F&&F.state?(k=F.state).wrap!==0&&k.mode!==11?h:k.mode===11&&a(1,B,H,0)!==k.check?-3:ie(F,B,H,H)?(k.mode=31,-4):(k.havedict=1,w):h},o.inflateInfo="pako inflate (from Nodeca project)"},{"../utils/common":41,"./adler32":43,"./crc32":45,"./inffast":48,"./inftrees":50}],50:[function(n,r,o){var i=n("../utils/common"),a=[3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258,0,0],l=[16,16,16,16,16,16,16,16,17,17,17,17,18,18,18,18,19,19,19,19,20,20,20,20,21,21,21,21,16,72,78],s=[1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577,0,0],u=[16,16,16,16,17,17,18,18,19,19,20,20,21,21,22,22,23,23,24,24,25,25,26,26,27,27,28,28,29,29,64,64];r.exports=function(y,x,w,h,b,f,v,p){var d,g,S,C,A,T,R,L,M,ie=p.bits,F=0,B=0,k=0,H=0,ce=0,Q=0,Z=0,$=0,O=0,P=0,I=null,re=0,te=new i.Buf16(16),J=new i.Buf16(16),fe=null,ee=0;for(F=0;F<=15;F++)te[F]=0;for(B=0;B<h;B++)te[x[w+B]]++;for(ce=ie,H=15;1<=H&&te[H]===0;H--);if(H<ce&&(ce=H),H===0)return b[f++]=20971520,b[f++]=20971520,p.bits=1,0;for(k=1;k<H&&te[k]===0;k++);for(ce<k&&(ce=k),F=$=1;F<=15;F++)if($<<=1,($-=te[F])<0)return-1;if(0<$&&(y===0||H!==1))return-1;for(J[1]=0,F=1;F<15;F++)J[F+1]=J[F]+te[F];for(B=0;B<h;B++)x[w+B]!==0&&(v[J[x[w+B]]++]=B);if(T=y===0?(I=fe=v,19):y===1?(I=a,re-=257,fe=l,ee-=257,256):(I=s,fe=u,-1),F=k,A=f,Z=B=P=0,S=-1,C=(O=1<<(Q=ce))-1,y===1&&852<O||y===2&&592<O)return 1;for(;;){for(R=F-Z,M=v[B]<T?(L=0,v[B]):v[B]>T?(L=fe[ee+v[B]],I[re+v[B]]):(L=96,0),d=1<<F-Z,k=g=1<<Q;b[A+(P>>Z)+(g-=d)]=R<<24|L<<16|M|0,g!==0;);for(d=1<<F-1;P&d;)d>>=1;if(d!==0?(P&=d-1,P+=d):P=0,B++,--te[F]==0){if(F===H)break;F=x[w+v[B]]}if(ce<F&&(P&C)!==S){for(Z===0&&(Z=ce),A+=k,$=1<<(Q=F-Z);Q+Z<H&&!(($-=te[Q+Z])<=0);)Q++,$<<=1;if(O+=1<<Q,y===1&&852<O||y===2&&592<O)return 1;b[S=P&C]=ce<<24|Q<<16|A-f|0}}return P!==0&&(b[A+P]=F-Z<<24|4194304|0),p.bits=ce,0}},{"../utils/common":41}],51:[function(n,r,o){r.exports={2:"need dictionary",1:"stream end",0:"","-1":"file error","-2":"stream error","-3":"data error","-4":"insufficient memory","-5":"buffer error","-6":"incompatible version"}},{}],52:[function(n,r,o){var i=n("../utils/common"),a=0,l=1;function s(E){for(var z=E.length;0<=--z;)E[z]=0}var u=0,y=29,x=256,w=x+1+y,h=30,b=19,f=2*w+1,v=15,p=16,d=7,g=256,S=16,C=17,A=18,T=[0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0],R=[0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13],L=[0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,2,3,7],M=[16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15],ie=new Array(2*(w+2));s(ie);var F=new Array(2*h);s(F);var B=new Array(512);s(B);var k=new Array(256);s(k);var H=new Array(y);s(H);var ce,Q,Z,$=new Array(h);function O(E,z,Y,X,D){this.static_tree=E,this.extra_bits=z,this.extra_base=Y,this.elems=X,this.max_length=D,this.has_stree=E&&E.length}function P(E,z){this.dyn_tree=E,this.max_code=0,this.stat_desc=z}function I(E){return E<256?B[E]:B[256+(E>>>7)]}function re(E,z){E.pending_buf[E.pending++]=255&z,E.pending_buf[E.pending++]=z>>>8&255}function te(E,z,Y){E.bi_valid>p-Y?(E.bi_buf|=z<<E.bi_valid&65535,re(E,E.bi_buf),E.bi_buf=z>>p-E.bi_valid,E.bi_valid+=Y-p):(E.bi_buf|=z<<E.bi_valid&65535,E.bi_valid+=Y)}function J(E,z,Y){te(E,Y[2*z],Y[2*z+1])}function fe(E,z){for(var Y=0;Y|=1&E,E>>>=1,Y<<=1,0<--z;);return Y>>>1}function ee(E,z,Y){var X,D,q=new Array(v+1),le=0;for(X=1;X<=v;X++)q[X]=le=le+Y[X-1]<<1;for(D=0;D<=z;D++){var ne=E[2*D+1];ne!==0&&(E[2*D]=fe(q[ne]++,ne))}}function oe(E){var z;for(z=0;z<w;z++)E.dyn_ltree[2*z]=0;for(z=0;z<h;z++)E.dyn_dtree[2*z]=0;for(z=0;z<b;z++)E.bl_tree[2*z]=0;E.dyn_ltree[2*g]=1,E.opt_len=E.static_len=0,E.last_lit=E.matches=0}function pe(E){8<E.bi_valid?re(E,E.bi_buf):0<E.bi_valid&&(E.pending_buf[E.pending++]=E.bi_buf),E.bi_buf=0,E.bi_valid=0}function ue(E,z,Y,X){var D=2*z,q=2*Y;return E[D]<E[q]||E[D]===E[q]&&X[z]<=X[Y]}function ye(E,z,Y){for(var X=E.heap[Y],D=Y<<1;D<=E.heap_len&&(D<E.heap_len&&ue(z,E.heap[D+1],E.heap[D],E.depth)&&D++,!ue(z,X,E.heap[D],E.depth));)E.heap[Y]=E.heap[D],Y=D,D<<=1;E.heap[Y]=X}function zt(E,z,Y){var X,D,q,le,ne=0;if(E.last_lit!==0)for(;X=E.pending_buf[E.d_buf+2*ne]<<8|E.pending_buf[E.d_buf+2*ne+1],D=E.pending_buf[E.l_buf+ne],ne++,X===0?J(E,D,z):(J(E,(q=k[D])+x+1,z),(le=T[q])!==0&&te(E,D-=H[q],le),J(E,q=I(--X),Y),(le=R[q])!==0&&te(E,X-=$[q],le)),ne<E.last_lit;);J(E,g,z)}function Nt(E,z){var Y,X,D,q=z.dyn_tree,le=z.stat_desc.static_tree,ne=z.stat_desc.has_stree,se=z.stat_desc.elems,_e=-1;for(E.heap_len=0,E.heap_max=f,Y=0;Y<se;Y++)q[2*Y]!==0?(E.heap[++E.heap_len]=_e=Y,E.depth[Y]=0):q[2*Y+1]=0;for(;E.heap_len<2;)q[2*(D=E.heap[++E.heap_len]=_e<2?++_e:0)]=1,E.depth[D]=0,E.opt_len--,ne&&(E.static_len-=le[2*D+1]);for(z.max_code=_e,Y=E.heap_len>>1;1<=Y;Y--)ye(E,q,Y);for(D=se;Y=E.heap[1],E.heap[1]=E.heap[E.heap_len--],ye(E,q,1),X=E.heap[1],E.heap[--E.heap_max]=Y,E.heap[--E.heap_max]=X,q[2*D]=q[2*Y]+q[2*X],E.depth[D]=(E.depth[Y]>=E.depth[X]?E.depth[Y]:E.depth[X])+1,q[2*Y+1]=q[2*X+1]=D,E.heap[1]=D++,ye(E,q,1),2<=E.heap_len;);E.heap[--E.heap_max]=E.heap[1],function(me,yt){var ao,Rt,lo,Ie,$i,Ss,Zt=yt.dyn_tree,Dd=yt.max_code,h0=yt.stat_desc.static_tree,m0=yt.stat_desc.has_stree,g0=yt.stat_desc.extra_bits,Od=yt.stat_desc.extra_base,so=yt.stat_desc.max_length,Ui=0;for(Ie=0;Ie<=v;Ie++)me.bl_count[Ie]=0;for(Zt[2*me.heap[me.heap_max]+1]=0,ao=me.heap_max+1;ao<f;ao++)so<(Ie=Zt[2*Zt[2*(Rt=me.heap[ao])+1]+1]+1)&&(Ie=so,Ui++),Zt[2*Rt+1]=Ie,Dd<Rt||(me.bl_count[Ie]++,$i=0,Od<=Rt&&($i=g0[Rt-Od]),Ss=Zt[2*Rt],me.opt_len+=Ss*(Ie+$i),m0&&(me.static_len+=Ss*(h0[2*Rt+1]+$i)));if(Ui!==0){do{for(Ie=so-1;me.bl_count[Ie]===0;)Ie--;me.bl_count[Ie]--,me.bl_count[Ie+1]+=2,me.bl_count[so]--,Ui-=2}while(0<Ui);for(Ie=so;Ie!==0;Ie--)for(Rt=me.bl_count[Ie];Rt!==0;)Dd<(lo=me.heap[--ao])||(Zt[2*lo+1]!==Ie&&(me.opt_len+=(Ie-Zt[2*lo+1])*Zt[2*lo],Zt[2*lo+1]=Ie),Rt--)}}(E,z),ee(q,_e,E.bl_count)}function m(E,z,Y){var X,D,q=-1,le=z[1],ne=0,se=7,_e=4;for(le===0&&(se=138,_e=3),z[2*(Y+1)+1]=65535,X=0;X<=Y;X++)D=le,le=z[2*(X+1)+1],++ne<se&&D===le||(ne<_e?E.bl_tree[2*D]+=ne:D!==0?(D!==q&&E.bl_tree[2*D]++,E.bl_tree[2*S]++):ne<=10?E.bl_tree[2*C]++:E.bl_tree[2*A]++,q=D,_e=(ne=0)===le?(se=138,3):D===le?(se=6,3):(se=7,4))}function W(E,z,Y){var X,D,q=-1,le=z[1],ne=0,se=7,_e=4;for(le===0&&(se=138,_e=3),X=0;X<=Y;X++)if(D=le,le=z[2*(X+1)+1],!(++ne<se&&D===le)){if(ne<_e)for(;J(E,D,E.bl_tree),--ne!=0;);else D!==0?(D!==q&&(J(E,D,E.bl_tree),ne--),J(E,S,E.bl_tree),te(E,ne-3,2)):ne<=10?(J(E,C,E.bl_tree),te(E,ne-3,3)):(J(E,A,E.bl_tree),te(E,ne-11,7));q=D,_e=(ne=0)===le?(se=138,3):D===le?(se=6,3):(se=7,4)}}s($);var U=!1;function j(E,z,Y,X){te(E,(u<<1)+(X?1:0),3),function(D,q,le,ne){pe(D),re(D,le),re(D,~le),i.arraySet(D.pending_buf,D.window,q,le,D.pending),D.pending+=le}(E,z,Y)}o._tr_init=function(E){U||(function(){var z,Y,X,D,q,le=new Array(v+1);for(D=X=0;D<y-1;D++)for(H[D]=X,z=0;z<1<<T[D];z++)k[X++]=D;for(k[X-1]=D,D=q=0;D<16;D++)for($[D]=q,z=0;z<1<<R[D];z++)B[q++]=D;for(q>>=7;D<h;D++)for($[D]=q<<7,z=0;z<1<<R[D]-7;z++)B[256+q++]=D;for(Y=0;Y<=v;Y++)le[Y]=0;for(z=0;z<=143;)ie[2*z+1]=8,z++,le[8]++;for(;z<=255;)ie[2*z+1]=9,z++,le[9]++;for(;z<=279;)ie[2*z+1]=7,z++,le[7]++;for(;z<=287;)ie[2*z+1]=8,z++,le[8]++;for(ee(ie,w+1,le),z=0;z<h;z++)F[2*z+1]=5,F[2*z]=fe(z,5);ce=new O(ie,T,x+1,w,v),Q=new O(F,R,0,h,v),Z=new O(new Array(0),L,0,b,d)}(),U=!0),E.l_desc=new P(E.dyn_ltree,ce),E.d_desc=new P(E.dyn_dtree,Q),E.bl_desc=new P(E.bl_tree,Z),E.bi_buf=0,E.bi_valid=0,oe(E)},o._tr_stored_block=j,o._tr_flush_block=function(E,z,Y,X){var D,q,le=0;0<E.level?(E.strm.data_type===2&&(E.strm.data_type=function(ne){var se,_e=4093624447;for(se=0;se<=31;se++,_e>>>=1)if(1&_e&&ne.dyn_ltree[2*se]!==0)return a;if(ne.dyn_ltree[18]!==0||ne.dyn_ltree[20]!==0||ne.dyn_ltree[26]!==0)return l;for(se=32;se<x;se++)if(ne.dyn_ltree[2*se]!==0)return l;return a}(E)),Nt(E,E.l_desc),Nt(E,E.d_desc),le=function(ne){var se;for(m(ne,ne.dyn_ltree,ne.l_desc.max_code),m(ne,ne.dyn_dtree,ne.d_desc.max_code),Nt(ne,ne.bl_desc),se=b-1;3<=se&&ne.bl_tree[2*M[se]+1]===0;se--);return ne.opt_len+=3*(se+1)+5+5+4,se}(E),D=E.opt_len+3+7>>>3,(q=E.static_len+3+7>>>3)<=D&&(D=q)):D=q=Y+5,Y+4<=D&&z!==-1?j(E,z,Y,X):E.strategy===4||q===D?(te(E,2+(X?1:0),3),zt(E,ie,F)):(te(E,4+(X?1:0),3),function(ne,se,_e,me){var yt;for(te(ne,se-257,5),te(ne,_e-1,5),te(ne,me-4,4),yt=0;yt<me;yt++)te(ne,ne.bl_tree[2*M[yt]+1],3);W(ne,ne.dyn_ltree,se-1),W(ne,ne.dyn_dtree,_e-1)}(E,E.l_desc.max_code+1,E.d_desc.max_code+1,le+1),zt(E,E.dyn_ltree,E.dyn_dtree)),oe(E),X&&pe(E)},o._tr_tally=function(E,z,Y){return E.pending_buf[E.d_buf+2*E.last_lit]=z>>>8&255,E.pending_buf[E.d_buf+2*E.last_lit+1]=255&z,E.pending_buf[E.l_buf+E.last_lit]=255&Y,E.last_lit++,z===0?E.dyn_ltree[2*Y]++:(E.matches++,z--,E.dyn_ltree[2*(k[Y]+x+1)]++,E.dyn_dtree[2*I(z)]++),E.last_lit===E.lit_bufsize-1},o._tr_align=function(E){te(E,2,3),J(E,g,ie),function(z){z.bi_valid===16?(re(z,z.bi_buf),z.bi_buf=0,z.bi_valid=0):8<=z.bi_valid&&(z.pending_buf[z.pending++]=255&z.bi_buf,z.bi_buf>>=8,z.bi_valid-=8)}(E)}},{"../utils/common":41}],53:[function(n,r,o){r.exports=function(){this.input=null,this.next_in=0,this.avail_in=0,this.total_in=0,this.output=null,this.next_out=0,this.avail_out=0,this.total_out=0,this.msg="",this.state=null,this.data_type=2,this.adler=0}},{}],54:[function(n,r,o){(function(i){(function(a,l){if(!a.setImmediate){var s,u,y,x,w=1,h={},b=!1,f=a.document,v=Object.getPrototypeOf&&Object.getPrototypeOf(a);v=v&&v.setTimeout?v:a,s={}.toString.call(a.process)==="[object process]"?function(S){process.nextTick(function(){d(S)})}:function(){if(a.postMessage&&!a.importScripts){var S=!0,C=a.onmessage;return a.onmessage=function(){S=!1},a.postMessage("","*"),a.onmessage=C,S}}()?(x="setImmediate$"+Math.random()+"$",a.addEventListener?a.addEventListener("message",g,!1):a.attachEvent("onmessage",g),function(S){a.postMessage(x+S,"*")}):a.MessageChannel?((y=new MessageChannel).port1.onmessage=function(S){d(S.data)},function(S){y.port2.postMessage(S)}):f&&"onreadystatechange"in f.createElement("script")?(u=f.documentElement,function(S){var C=f.createElement("script");C.onreadystatechange=function(){d(S),C.onreadystatechange=null,u.removeChild(C),C=null},u.appendChild(C)}):function(S){setTimeout(d,0,S)},v.setImmediate=function(S){typeof S!="function"&&(S=new Function(""+S));for(var C=new Array(arguments.length-1),A=0;A<C.length;A++)C[A]=arguments[A+1];var T={callback:S,args:C};return h[w]=T,s(w),w++},v.clearImmediate=p}function p(S){delete h[S]}function d(S){if(b)setTimeout(d,0,S);else{var C=h[S];if(C){b=!0;try{(function(A){var T=A.callback,R=A.args;switch(R.length){case 0:T();break;case 1:T(R[0]);break;case 2:T(R[0],R[1]);break;case 3:T(R[0],R[1],R[2]);break;default:T.apply(l,R)}})(C)}finally{p(S),b=!1}}}}function g(S){S.source===a&&typeof S.data=="string"&&S.data.indexOf(x)===0&&d(+S.data.slice(x.length))}})(typeof self>"u"?i===void 0?this:i:self)}).call(this,typeof po<"u"?po:typeof self<"u"?self:typeof window<"u"?window:{})},{}]},{},[10])(10)})})(Jp);var Nm=Jp.exports;const Fi=Kd(Nm);function jm(e,t){const n=e.images[0];switch(t.mode){case"single":return{htmlRef:"(see §HTML below)",cssRef:"(see §CSS below)",jsRef:"(see §JS below)",imageRef:"(embedded inline)"};case"mdFiles":case"zip":return{htmlRef:"./index.html",cssRef:"./style.css",jsRef:"./script.js",imageRef:n?`./images/${n.name}`:"(no image)"};case"share":{if(!t.shareRefs)throw new Error("share mode requires shareRefs");return t.shareRefs}}}function rs(e,t){return Kp(jm(e,t))}function Fm(){return new Date().toISOString().replace(/[:.]/g,"-").slice(0,19)}function Tm(e){return(e||"page").replace(/^www\./,"").replace(/[^a-z0-9_-]+/gi,"_")}function os(e,t){const n=document.createElement("a");n.href=URL.createObjectURL(e),n.download=t,n.click(),setTimeout(()=>URL.revokeObjectURL(n.href),1e3)}function Am(e){return e===co.FullPage?"fullpage":"element"}function is(e){return`inspect-page-${Am(e.flow)}-${Tm(e.domain)}-${Fm()}`}function Pm(e){const n=[rs(e,{mode:"single"}),"","## HTML","","```html",e.html||"","```",""];e.css&&n.push("## CSS","","```css",e.css,"```",""),e.js&&n.push("## JS","","```javascript",e.js,"```","");for(const r of e.images)n.push(`## ${r.name}`,"",`![${r.name}](data:${r.mime};base64,${r.base64})`,"");return n.join(`
`)}function Im(e){return`${rs(e,{mode:"mdFiles"})}

_See \`./index.html\`, \`./style.css\`, and the \`./images/\` folder for the captured assets._
`}function qp(e){const t=atob(e),n=new Uint8Array(t.length);for(let r=0;r<t.length;r+=1)n[r]=t.charCodeAt(r);return n}function as({artifacts:e,shareEnabled:t=!1,onShare:n}){const[r,o]=G.useState({phase:"idle"}),[i,a]=G.useState(Date.now());G.useEffect(()=>{if(r.phase!=="done")return;const x=setInterval(()=>a(Date.now()),1e3);return()=>clearInterval(x)},[r.phase]);const l=G.useCallback(()=>{const x=Pm(e);os(new Blob([x],{type:"text/markdown;charset=utf-8"}),`${is(e)}.md`)},[e]),s=G.useCallback(async()=>{if(n){o({phase:"uploading"});try{await n(e),o({phase:"done",expiresAt:Date.now()+24*60*60*1e3})}catch(x){o({phase:"error",message:x instanceof Error?x.message:String(x)})}}},[e,n]),u=G.useCallback(async()=>{const x=new Fi;x.file("prompt.md",Im(e)),e.html&&x.file("index.html",e.html),e.css&&x.file("style.css",e.css);for(const h of e.images)x.file(`images/${h.name}`,qp(h.base64));const w=await x.generateAsync({type:"blob"});os(w,`${is(e)}-mdfiles.zip`)},[e]),y=G.useCallback(async()=>{const x=new Fi;x.file("prompt.md",rs(e,{mode:"zip"})),e.html&&x.file("index.html",e.html),e.css&&x.file("style.css",e.css),e.js&&x.file("script.js",e.js);for(const h of e.images)x.file(`images/${h.name}`,qp(h.base64));x.file("manifest.json",`${JSON.stringify(e.meta,null,2)}
`);const w=await x.generateAsync({type:"blob"});os(w,`${is(e)}.zip`)},[e]);return c.jsxs("div",{className:"lpe-export-modes","aria-label":N.exportModesHeader,children:[c.jsx("div",{className:"lpe-debug-title",children:N.exportModesHeader}),c.jsxs("div",{className:"lpe-debug-actions",children:[c.jsx("button",{type:"button",className:"lpe-btn",onClick:l,children:N.exportModeMd}),c.jsx("button",{type:"button",className:"lpe-btn",onClick:u,children:N.exportModeMdFiles}),c.jsx("button",{type:"button",className:"lpe-btn lpe-btn-primary",onClick:y,children:N.exportModeZip}),c.jsx("button",{type:"button",className:"lpe-btn",onClick:s,disabled:!t||r.phase==="uploading",title:t?void 0:N.exportModeShareDisabledTip,children:r.phase==="uploading"?N.shareUploading:N.exportModeShare})]}),r.phase==="done"&&c.jsxs("div",{className:"lpe-debug-note",children:["✓ ",N.shareCopied," · ",N.shareExpiresInPrefix," ",zm(r.expiresAt-i)]}),r.phase==="error"&&c.jsxs("div",{className:"lpe-debug-note",role:"alert",children:["⚠ ",r.message]})]})}function zm(e){if(e<=0)return"expired";const t=Math.floor(e/1e3),n=Math.floor(t/3600),r=Math.floor(t%3600/60);return`${n}h ${r}m`}const ls="inspect-page.onboarding";function Rm(e){return typeof e!="object"||e===null?!1:typeof e.dismissed=="boolean"}async function Lm(){const t=(await chrome.storage.local.get(ls))[ls];return Rm(t)?t:{dismissed:!1}}async function Dm(){await chrome.storage.local.set({[ls]:{dismissed:!0}})}const Om={siteUrl:Ns,userId:0,displayName:"",email:"",nonce:"",signedInAtIso:""};function Mm(e){if(typeof e!="object"||e===null)return!1;const t=e;return typeof t.siteUrl=="string"&&typeof t.userId=="number"&&typeof t.displayName=="string"&&typeof t.email=="string"&&typeof t.nonce=="string"&&typeof t.signedInAtIso=="string"}async function ed(){const t=(await chrome.storage.local.get(Es))[Es];return{...Mm(t)?t:{...Om},siteUrl:Ns}}function Bm(e){return!!(e.siteUrl&&e.nonce&&e.userId)}function td(e){return e.replace(/\/+$/,"")}async function $m(e){const t=await e.getShareSettings();if(!t.siteUrl||!t.nonce)throw new He(ke.E_SHARE_AUTH,"Sign in to your WordPress site in Settings → Smart Share.");const n=`${td(t.siteUrl)}/wp-json/inspect-page/v1/billing/checkout`,r=e.fetchImpl??fetch,o={};e.successUrl&&(o.success_url=e.successUrl),e.cancelUrl&&(o.cancel_url=e.cancelUrl),e.workspaceId&&e.workspaceId>0&&(o.workspace_id=String(e.workspaceId));let i;try{i=await r(n,{method:"POST",headers:{"X-WP-Nonce":t.nonce,Accept:"application/json","Content-Type":"application/json"},credentials:"include",body:JSON.stringify(o)})}catch(s){throw new He(ke.E_SHARE_NETWORK,"Could not reach WordPress site",s instanceof Error?s.message:String(s))}if(i.status===401||i.status===403)throw new He(ke.E_SHARE_AUTH,"Sign in to your WordPress site in Settings → Smart Share.");let a=null;try{a=await i.json()}catch{}if(!i.ok){const s=a&&typeof a=="object"&&"message"in a&&typeof a.message=="string"?a.message:`Billing checkout failed (HTTP ${i.status})`;throw new He(ke.E_SHARE_NETWORK,s)}if(!a||typeof a!="object"||typeof a.url!="string")throw new He(ke.E_SHARE_NETWORK,"Stripe Checkout URL missing in response");const l=a;return{url:l.url,id:typeof l.id=="string"?l.id:""}}async function Um(e){const t=await e.getShareSettings();if(!t.siteUrl||!t.nonce)throw new He(ke.E_SHARE_AUTH,"Sign in to your WordPress site in Settings → Smart Share.");const n=`${td(t.siteUrl)}/wp-json/inspect-page/v1/billing/status`,r=e.workspaceId&&e.workspaceId>0?`${n}?workspace_id=${encodeURIComponent(String(e.workspaceId))}`:n,o=e.fetchImpl??fetch;let i;try{i=await o(r,{method:"GET",headers:{"X-WP-Nonce":t.nonce,Accept:"application/json"},credentials:"include"})}catch(v){throw new He(ke.E_SHARE_NETWORK,"Could not reach WordPress site",v instanceof Error?v.message:String(v))}if(i.status===401||i.status===403)throw new He(ke.E_SHARE_AUTH,"Sign in to your WordPress site in Settings → Smart Share.");let a=null;try{a=await i.json()}catch{}if(!i.ok||!a||typeof a!="object")throw new He(ke.E_SHARE_NETWORK,`Billing status failed (HTTP ${i.status})`);const l=a,s=!!l.has_license,u=l.plan==="pro"?"pro":"free",y=typeof l.lifetime_used=="number"?l.lifetime_used:0,x=typeof l.free_limit=="number"?l.free_limit:0,w=l.remaining===null?null:typeof l.remaining=="number"?l.remaining:Math.max(0,x-y),h={hasLicense:s,plan:u,configured:!!l.configured,subscription:typeof l.subscription=="string"?l.subscription:"",lifetimeUsed:y,freeLimit:x,remaining:s?null:w},b=l.price;if(b&&typeof b=="object"){const v=b;typeof v.id=="string"&&v.id&&(h.price={id:v.id,unitAmount:typeof v.unit_amount=="number"?v.unit_amount:null,currency:typeof v.currency=="string"?v.currency:null,interval:typeof v.interval=="string"?v.interval:null,nickname:typeof v.nickname=="string"?v.nickname:null})}const f=l.workspace;if(f&&typeof f=="object"){const v=f,p=v.role==="owner"||v.role==="admin"?v.role:"member",d=v.license_status==="active"||v.license_status==="past_due"||v.license_status==="canceled"?v.license_status:"free";typeof v.id=="number"&&v.id>0&&(h.workspace={id:v.id,name:typeof v.name=="string"?v.name:"",role:p,licenseStatus:d,hasLicense:!!v.has_license,canManage:!!v.can_manage,stripeCustomerId:typeof v.stripe_customer_id=="string"?v.stripe_customer_id:null,stripeSubscriptionId:typeof v.stripe_subscription_id=="string"?v.stripe_subscription_id:null})}return h}const Hm="inspect-page:billing-changed";function Wm(e){const t=Math.max(500,e.intervalMs??3e3),n=Math.max(t,e.timeoutMs??5*60*1e3),r=e.setTimeoutImpl??setTimeout,o=e.clearTimeoutImpl??clearTimeout,i=e.dispatchImpl??(w=>{typeof window<"u"&&window.dispatchEvent(new CustomEvent(w))});let a=!1,l=null;const s=Date.now();let u=null,y=null;return{done:new Promise(w=>{y=w;const h=async()=>{if(a){w(u);return}try{const b=await Um(e);if(u=b,b.plan==="pro"){i(Hm),w(b);return}}catch{}if(Date.now()-s>=n){w(u);return}l=r(h,t)};l=r(h,t)}),cancel:()=>{a=!0,l&&o(l),y&&(y(u),y=null)}}}function ss(e,t,n={}){be.info(ve.Billing,e.toUpperCase(),`billing.${e}`,{surface:t,...n})}function Vm(e){const{snapshot:t,thumbnailDataUrl:n,onOpenDocs:r}=e,{pageInfo:o}=t;return c.jsxs("section",{className:"lpe-overview","aria-label":N.inspectOverviewTitle,children:[c.jsx("header",{className:"lpe-overview-header",children:c.jsx("h2",{className:"lpe-overview-title",children:N.inspectOverviewTitle})}),n?c.jsx("div",{className:"lpe-overview-hero",children:c.jsx("img",{src:n,alt:o.title||o.url,className:"lpe-overview-thumb"})}):c.jsx("div",{className:"lpe-overview-hero lpe-overview-hero-empty","aria-hidden":"true"}),c.jsxs("div",{className:"lpe-overview-meta",children:[c.jsx("div",{className:"lpe-overview-page-title",title:o.title,children:o.title||o.origin}),c.jsx("a",{className:"lpe-overview-url",href:o.url,target:"_blank",rel:"noopener noreferrer",title:o.url,children:o.url})]}),c.jsx("button",{type:"button",className:"lpe-btn",onClick:r,children:N.inspectOpenDocs})]})}function Gm({snapshot:e}){const[t,n]=G.useState(!1),r=G.useMemo(()=>nd(e.fonts,"heading"),[e.fonts]),o=G.useMemo(()=>nd(e.fonts,"body"),[e.fonts]);return e.fonts.length===0?c.jsxs("section",{className:"lpe-typo","aria-label":N.inspectTypographyTitle,children:[c.jsx("header",{className:"lpe-section-header",children:c.jsx("h2",{className:"lpe-section-title",children:N.inspectTypographyTitle})}),c.jsx("div",{className:"lpe-inspect-empty",children:c.jsx("span",{children:N.inspectTypoNone})})]}):c.jsxs("section",{className:"lpe-typo","aria-label":N.inspectTypographyTitle,children:[c.jsxs("header",{className:"lpe-section-header",children:[c.jsx("h2",{className:"lpe-section-title",children:N.inspectTypographyTitle}),c.jsx("button",{type:"button",className:"lpe-link",onClick:()=>n(!0),children:N.inspectTypoShowAll})]}),c.jsxs("div",{className:"lpe-typo-grid",children:[c.jsx(rd,{label:N.inspectTypoHeadings,font:r}),c.jsx(rd,{label:N.inspectTypoBody,font:o})]}),t&&c.jsx(Zm,{fonts:e.fonts,onClose:()=>n(!1)})]})}function nd(e,t){return e.find(n=>n.group===t)??null}function rd({label:e,font:t}){if(!t)return c.jsxs("div",{className:"lpe-typo-card lpe-typo-card-empty",children:[c.jsx("span",{className:"lpe-typo-card-label",children:e}),c.jsx("span",{className:"lpe-typo-card-empty-text",children:"—"})]});const n=t.sizesPx.length;return c.jsxs("div",{className:"lpe-typo-card",children:[c.jsx("span",{className:"lpe-typo-card-label",children:e}),c.jsx("span",{className:"lpe-typo-card-family",style:{fontFamily:t.stack},title:t.stack,children:t.family}),c.jsx("span",{className:"lpe-typo-chip",children:t.generic}),c.jsxs("span",{className:"lpe-typo-meta",children:[xt(N.inspectTypoWeights,{n:t.weights.length})," · ",xt(N.inspectTypoStyles,{n})]})]})}function Zm({fonts:e,onClose:t}){return c.jsx("div",{className:"lpe-modal-backdrop",role:"dialog","aria-modal":"true","aria-label":N.inspectTypoModalTitle,children:c.jsxs("div",{className:"lpe-modal",children:[c.jsxs("header",{className:"lpe-modal-header",children:[c.jsx("h3",{children:N.inspectTypoModalTitle}),c.jsx("button",{type:"button",className:"lpe-header-btn",onClick:t,"aria-label":N.inspectClose,children:"✕"})]}),c.jsx("div",{className:"lpe-modal-body",children:e.map(n=>c.jsxs("div",{className:"lpe-typo-row",children:[c.jsx("span",{className:"lpe-typo-row-group",children:n.group}),c.jsx("span",{className:"lpe-typo-row-family",style:{fontFamily:n.stack},children:n.family}),c.jsx("span",{className:"lpe-typo-chip",children:n.generic}),c.jsxs("span",{className:"lpe-typo-meta",children:[n.weights.join(", ")," · ",n.sizesPx.length," sizes · ",n.sampleCount,"×"]})]},`${n.group}-${n.family}`))})]})})}const Ym=/^#([0-9a-f]{6})([0-9a-f]{2})?$/i;function Qm(e){const t=Ym.exec(e.trim());if(!t)return null;const n=t[1],r=parseInt(n.slice(0,2),16),o=parseInt(n.slice(2,4),16),i=parseInt(n.slice(4,6),16),a=t[2]?parseInt(t[2],16)/255:1;return{r,g:o,b:i,a}}function Xm(e){const t=e.r/255,n=e.g/255,r=e.b/255,o=Math.max(t,n,r),i=Math.min(t,n,r),a=(o+i)/2;let l=0,s=0;if(o!==i){const u=o-i;switch(s=a>.5?u/(2-o-i):u/(o+i),o){case t:l=(n-r)/u+(n<r?6:0);break;case n:l=(r-t)/u+2;break;case r:l=(t-n)/u+4;break}l*=60}return{h:Math.round(l),s:Math.round(s*100),l:Math.round(a*100),a:e.a}}function Km(e){return e.a>=.999?`rgb(${e.r}, ${e.g}, ${e.b})`:`rgba(${e.r}, ${e.g}, ${e.b}, ${od(e.a)})`}function Jm(e){return e.a>=.999?`hsl(${e.h}, ${e.s}%, ${e.l}%)`:`hsla(${e.h}, ${e.s}%, ${e.l}%, ${od(e.a)})`}function od(e){return Number(e.toFixed(3)).toString()}function qm({color:e,onClose:t}){const[n,r]=G.useState(null),o=Qm(e.value),i=o?Xm(o):null,a=o?Km(o):e.value,l=i?Jm(i):e.value,s=G.useCallback(async(u,y)=>{try{await navigator.clipboard.writeText(y)}catch{}r(u),window.setTimeout(()=>r(x=>x===u?null:x),1200)},[]);return G.useEffect(()=>{const u=y=>{y.key==="Escape"&&t()};return window.addEventListener("keydown",u),()=>window.removeEventListener("keydown",u)},[t]),c.jsx("div",{className:"lpe-modal-backdrop",role:"dialog","aria-modal":"true","aria-label":N.inspectDetailTitle,onClick:t,children:c.jsxs("div",{className:"lpe-modal lpe-modal-detail",onClick:u=>u.stopPropagation(),children:[c.jsxs("div",{className:"lpe-modal-header",children:[c.jsx("h3",{children:N.inspectDetailTitle}),c.jsx("button",{type:"button",className:"lpe-btn",onClick:t,"aria-label":N.inspectClose,children:N.inspectClose})]}),c.jsxs("div",{className:"lpe-modal-body lpe-detail-body",children:[c.jsx("div",{className:`lpe-detail-swatch ${e.transparent?"is-transparent":""}`,style:e.transparent?void 0:{background:e.value},"aria-hidden":"true"}),c.jsxs("dl",{className:"lpe-detail-grid",children:[c.jsx(cs,{label:N.inspectDetailHex,value:e.value,copyLabel:N.inspectDetailCopyHex,copied:n==="hex",onCopy:()=>void s("hex",e.value)}),c.jsx(cs,{label:N.inspectDetailRgb,value:a,copyLabel:N.inspectDetailCopyRgb,copied:n==="rgb",onCopy:()=>void s("rgb",a)}),c.jsx(cs,{label:N.inspectDetailHsl,value:l,copyLabel:N.inspectDetailCopyHsl,copied:n==="hsl",onCopy:()=>void s("hsl",l)}),o&&o.a<.999&&c.jsx(us,{label:N.inspectDetailAlpha,value:Number(o.a.toFixed(3)).toString()}),c.jsx(us,{label:N.inspectDetailCategory,value:e.category}),c.jsx(us,{label:N.inspectDetailInstances,value:`${e.instances}×`})]})]})]})})}function cs({label:e,value:t,copyLabel:n,copied:r,onCopy:o}){return c.jsxs("div",{className:"lpe-detail-row",children:[c.jsx("dt",{children:e}),c.jsx("dd",{className:"lpe-detail-value",title:t,children:t}),c.jsx("button",{type:"button",className:"lpe-link",onClick:o,"aria-label":n,children:r?N.inspectDetailCopied:n})]})}function us({label:e,value:t}){return c.jsxs("div",{className:"lpe-detail-row lpe-detail-row-static",children:[c.jsx("dt",{children:e}),c.jsx("dd",{children:t})]})}function id(e){const t=e==null?"":String(e);return/[",\r\n]/.test(t)?`"${t.replace(/"/g,'""')}"`:t}function ad(e,t){const n=e.map(id).join(","),r=t.map(o=>o.map(id).join(",")).join(`
`);return r?`${n}
${r}
`:`${n}
`}function ld(e){return ad(["value","category","instances","transparent"],e.map(t=>[t.value,t.category,t.instances,t.transparent]))}function eg(e){return ad(["family","group","generic","weights","sizesPx","sampleCount","stack"],e.map(t=>[t.family,t.group,t.generic,t.weights.join("|"),t.sizesPx.join("|"),t.sampleCount,t.stack]))}function tg(e){const t={pageInfo:e.pageInfo,fonts:e.fonts,colors:e.colors,cssStats:e.cssStats,textNodes:e.textNodes,computedSamples:e.computedSamples,collectedAt:e.collectedAt};return`${JSON.stringify(t,null,2)}
`}function ng(e){const{pageInfo:t,fonts:n,colors:r,cssStats:o}=e,i=[];if(i.push("# Inspect Page report"),i.push(""),i.push(`- **URL:** ${t.url}`),t.title&&i.push(`- **Title:** ${t.title}`),i.push(`- **Viewport:** ${t.viewport.w} × ${t.viewport.h}`),i.push(`- **Document:** ${t.documentSize.w} × ${t.documentSize.h}`),i.push(`- **Collected:** ${new Date(e.collectedAt).toISOString()}`),i.push(""),i.push("## CSS"),i.push(`- Rule count: ${o.ruleCount}`),i.push(`- Inlined CSS bytes: ${o.cssBytes}`),i.push(`- External stylesheets: ${o.externalSheetCount}`),i.push(`- \`<style>\` tags: ${o.inlineStyleTagCount}`),i.push(`- Unreachable (CORS) sheets: ${o.unreachableSheetCount}`),i.push(""),n.length>0){i.push("## Fonts"),i.push("| Group | Family | Weights | Sizes (px) | Samples |"),i.push("| --- | --- | --- | --- | --- |");for(const a of n)i.push(`| ${a.group} | ${sd(a.family)} | ${a.weights.join(", ")} | ${a.sizesPx.join(", ")} | ${a.sampleCount} |`);i.push("")}if(r.length>0){i.push("## Colors"),i.push("| Value | Category | Instances |"),i.push("| --- | --- | --- |");for(const a of r)i.push(`| \`${sd(a.value)}\` | ${a.category} | ${a.instances} |`);i.push("")}return i.join(`
`)}function sd(e){return e.replace(/\|/g,"\\|")}function cd(e,t="inspect-page"){let n="snapshot";try{n=new URL(e.pageInfo.url).hostname.replace(/^www\./,"")||"snapshot"}catch{}const r=n.toLowerCase().replace(/[^a-z0-9]+/g,"-").replace(/^-+|-+$/g,""),o=new Date(e.collectedAt).toISOString().slice(0,10);return`${t}-${r||"snapshot"}-${o}`}function ro(e){switch(e){case"csv":return{mime:"text/csv;charset=utf-8",ext:"csv"};case"json":return{mime:"application/json;charset=utf-8",ext:"json"};case"md":return{mime:"text/markdown;charset=utf-8",ext:"md"}}}function oo(e,t,n){const r=new Blob([e],{type:n}),o=URL.createObjectURL(r),i=document.createElement("a");i.href=o,i.download=t,document.body.appendChild(i),i.click(),i.remove(),setTimeout(()=>URL.revokeObjectURL(o),1e3)}function rg({snapshot:e}){const[t,n]=G.useState("palette"),[r,o]=G.useState(null),[i,a]=G.useState(null),[l,s]=G.useState(null),u=G.useMemo(()=>sg(e.colors),[e.colors]),y=async b=>{try{await navigator.clipboard.writeText(b),o(b),setTimeout(()=>o(f=>f===b?null:f),1200)}catch{}},x=async b=>{try{const v=(await Me(xe.LocateColor,{tabId:-1,target:b})).count,p=v===0?N.inspectColorLocateNone:v===1?N.inspectColorLocateCount:N.inspectColorLocateCountPlural;s(xt(p,{n:v,value:b}))}catch{s(xt(N.inspectColorLocateError,{value:b}))}window.setTimeout(()=>s(f=>f&&f.includes(b)?null:f),2e3)},w=b=>{b.category!=="gradient"&&a(b)},h=()=>{const b=ld(e.colors),{mime:f,ext:v}=ro("csv");oo(b,`${cd(e)}-colors.${v}`,f)};return c.jsxs("section",{className:"lpe-colors","aria-label":"Colors",children:[c.jsxs("header",{className:"lpe-section-header",children:[c.jsx("h2",{className:"lpe-section-title",children:xt(N.inspectColorsTitle,{n:u.length})}),c.jsx("button",{type:"button",className:"lpe-link",onClick:h,disabled:e.colors.length===0,children:N.inspectColorsExportAll})]}),c.jsxs("div",{className:"lpe-subtabs",role:"tablist","aria-label":"Color view",children:[c.jsx("button",{type:"button",role:"tab","aria-selected":t==="palette",className:"lpe-subtab","data-active":t==="palette"?"true":"false",onClick:()=>n("palette"),children:N.inspectColorsPalette}),c.jsx("button",{type:"button",role:"tab","aria-selected":t==="categories",className:"lpe-subtab","data-active":t==="categories"?"true":"false",onClick:()=>n("categories"),children:N.inspectColorsCategories})]}),t==="palette"&&(u.length===0?c.jsx("div",{className:"lpe-inspect-empty",children:c.jsx("span",{children:N.inspectColorsNone})}):c.jsx(cg,{items:u,copied:r,onCopy:y,onLocate:x,onOpenDetail:w})),t==="categories"&&c.jsx(ag,{colors:e.colors,copied:r,onCopy:y,onLocate:x,onOpenDetail:w}),i&&c.jsx(qm,{color:i,onClose:()=>a(null)}),l&&c.jsx("div",{className:"lpe-locate-toast",role:"status","aria-live":"polite",children:l})]})}const og=["background","text","border","fill","stroke","gradient","shadow","other"];function ig(e){switch(e){case"background":return N.inspectColorCatBackground;case"text":return N.inspectColorCatText;case"border":return N.inspectColorCatBorder;case"fill":return N.inspectColorCatFill;case"stroke":return N.inspectColorCatStroke;case"gradient":return N.inspectColorCatGradient;case"shadow":return N.inspectColorCatShadow;case"other":return N.inspectColorCatOther}}function ag(e){const{colors:t,copied:n,onCopy:r,onLocate:o,onOpenDetail:i}=e,a=G.useMemo(()=>lg(t),[t]);return t.length===0?c.jsx("div",{className:"lpe-inspect-empty",children:c.jsx("span",{children:N.inspectColorsNone})}):c.jsx("div",{className:"lpe-color-categories",children:og.flatMap(l=>{const s=a.get(l);return!s||s.length===0?[]:[c.jsxs("div",{className:"lpe-color-category",children:[c.jsxs("header",{className:"lpe-color-category-header",children:[c.jsx("span",{className:"lpe-color-category-title",children:ig(l)}),c.jsx("span",{className:"lpe-color-category-count",children:s.length})]}),c.jsx("div",{className:"lpe-color-grid",children:s.map(u=>c.jsx(ud,{color:u,copied:n===u.value,onCopy:r,onLocate:o,onOpenDetail:i},`${l}-${u.value}`))})]},l)]})})}function lg(e){const t=new Map;for(const n of e){const r=t.get(n.category)??[];r.push(n),t.set(n.category,r)}for(const n of t.values())n.sort((r,o)=>o.instances-r.instances);return t}function sg(e){const t=new Map;for(const n of e){if(n.category==="gradient")continue;const r=t.get(n.value);r?r.instances+=n.instances:t.set(n.value,{...n})}return Array.from(t.values()).sort((n,r)=>r.instances-n.instances)}function cg({items:e,copied:t,onCopy:n,onLocate:r,onOpenDetail:o}){return c.jsx("div",{className:"lpe-color-grid",children:e.map(i=>c.jsx(ud,{color:i,copied:t===i.value,onCopy:n,onLocate:r,onOpenDetail:o},i.value))})}function ud({color:e,copied:t,onCopy:n,onLocate:r,onOpenDetail:o}){const i=!!o&&e.category!=="gradient";return c.jsxs("div",{className:"lpe-color-row",children:[i?c.jsx("button",{type:"button",className:`lpe-color-swatch ${e.transparent?"is-transparent":""}`,style:e.transparent?void 0:{background:e.value},onClick:()=>o(e),"aria-label":`Details for ${e.value}`,title:`Details for ${e.value}`}):c.jsx("span",{className:`lpe-color-swatch ${e.transparent?"is-transparent":""}`,style:e.transparent?void 0:{background:e.value},"aria-hidden":"true"}),i?c.jsx("button",{type:"button",className:"lpe-color-hex lpe-color-hex-btn",onClick:()=>o(e),title:e.value,children:e.value}):c.jsx("span",{className:"lpe-color-hex",title:e.value,children:e.value}),c.jsxs("span",{className:"lpe-color-instances",children:[e.instances,"×"]}),c.jsx("button",{type:"button",className:"lpe-color-btn",onClick:()=>r(e.value),"aria-label":`${N.inspectColorLocate} ${e.value}`,title:N.inspectColorLocate,children:"⌖"}),c.jsx("button",{type:"button",className:"lpe-color-btn",onClick:()=>n(e.value),"aria-label":`${N.inspectColorCopy} ${e.value}`,title:t?N.inspectColorCopied:N.inspectColorCopy,children:t?"✓":"⧉"})]})}function ps(e){const t=/^#([0-9a-fA-F]{6})([0-9a-fA-F]{2})?$/.exec(e);if(!t)return null;const n=t[1];return{r:parseInt(n.slice(0,2),16),g:parseInt(n.slice(2,4),16),b:parseInt(n.slice(4,6),16),a:t[2]?parseInt(t[2],16)/255:1}}function ug(e,t){const n=e.a+t.a*(1-e.a);return{r:(e.r*e.a+t.r*t.a*(1-e.a))/(n||1),g:(e.g*e.a+t.g*t.a*(1-e.a))/(n||1),b:(e.b*e.a+t.b*t.a*(1-e.a))/(n||1),a:1}}function pd(e){const t=n=>{const r=n/255;return r<=.03928?r/12.92:Math.pow((r+.055)/1.055,2.4)};return .2126*t(e.r)+.7152*t(e.g)+.0722*t(e.b)}function ds(e,t){const n=ps(e),r=ps(t);if(!n||!r)return 1;const o=n.a<1?ug(n,{...r,a:1}):n,i=pd(o),a=pd({...r}),[l,s]=i>a?[i,a]:[a,i];return Math.round((l+.05)/(s+.05)*100)/100}function fs(e){return{ratio:e,label:e>=7?"Excellent":e>=4.5?"Good":e>=3?"Poor":"Fail",normalAA:e>=4.5,normalAAA:e>=7,largeAA:e>=3,largeAAA:e>=4.5}}function hs(e,t){return e>=24||e>=18.66&&t>=700}const pg="#ffffff";function dg(e){const t=new Map;for(const n of e){const r=ps(n.color)?.a!==void 0?n.color:null;if(!r)continue;const o=/^#[0-9a-f]{6}$/i.test(n.backgroundColor)?n.backgroundColor:pg,i=ds(r,o),a=hs(n.fontSizePx,n.fontWeight),l=`${r.toLowerCase()}|${o.toLowerCase()}|${a?"L":"N"}`,s=t.get(l);s?s.instances++:t.set(l,{fg:r.toLowerCase(),bg:o.toLowerCase(),ratio:i,verdict:fs(i),isLarge:a,instances:1,sample:n.text})}return Array.from(t.values()).sort((n,r)=>n.ratio-r.ratio)}function fg({snapshot:e}){const t=G.useMemo(()=>dg(e.textNodes),[e.textNodes]),n=t.filter(a=>dd(a)),r=t.filter(a=>!dd(a)),[o,i]=G.useState(!1);return c.jsxs("section",{className:"lpe-contrast","aria-label":N.inspectContrastTitle,children:[c.jsxs("header",{className:"lpe-section-header",children:[c.jsx("h2",{className:"lpe-section-title",children:N.inspectContrastTitle}),t.length>0&&c.jsx("button",{type:"button",className:"lpe-link",onClick:()=>i(!0),children:N.inspectContrastShowAll})]}),t.length===0?c.jsx("div",{className:"lpe-inspect-empty",children:c.jsx("span",{children:N.inspectContrastNone})}):c.jsxs("div",{className:"lpe-contrast-summary",children:[c.jsxs("span",{className:"lpe-contrast-badge lpe-contrast-badge-fail",children:[n.length," fail"]}),c.jsxs("span",{className:"lpe-contrast-badge lpe-contrast-badge-pass",children:[r.length," pass"]})]}),o&&c.jsx(hg,{failing:n,passing:r,onClose:()=>i(!1)})]})}function dd(e){return e.isLarge?!e.verdict.largeAA:!e.verdict.normalAA}function hg({failing:e,passing:t,onClose:n}){const[r,o]=G.useState("failing"),i=r==="failing"?e:t;return c.jsx("div",{className:"lpe-modal-backdrop",role:"dialog","aria-modal":"true",children:c.jsxs("div",{className:"lpe-modal lpe-modal-wide",children:[c.jsxs("header",{className:"lpe-modal-header",children:[c.jsx("button",{type:"button",className:"lpe-header-btn",onClick:n,"aria-label":N.inspectContrastBack,title:N.inspectContrastBack,children:"←"}),c.jsx("h3",{children:N.inspectContrastTitle}),c.jsx("span",{style:{flex:1}}),c.jsx("button",{type:"button",className:"lpe-header-btn",onClick:n,"aria-label":N.inspectClose,children:"✕"})]}),c.jsxs("div",{className:"lpe-subtabs",style:{margin:"8px 12px 0"},role:"tablist",children:[c.jsxs("button",{type:"button",role:"tab","aria-selected":r==="failing",className:"lpe-subtab","data-active":r==="failing"?"true":"false",onClick:()=>o("failing"),children:[N.inspectContrastFailing," (",e.length,")"]}),c.jsxs("button",{type:"button",role:"tab","aria-selected":r==="passing",className:"lpe-subtab","data-active":r==="passing"?"true":"false",onClick:()=>o("passing"),children:[N.inspectContrastPassing," (",t.length,")"]})]}),c.jsx("div",{className:"lpe-modal-body",children:i.length===0?c.jsx("div",{className:"lpe-inspect-empty",children:c.jsx("span",{children:"—"})}):i.map((a,l)=>c.jsx(mg,{pair:a},`${a.fg}-${a.bg}-${a.isLarge}-${l}`))})]})})}function mg({pair:e}){const[t,n]=G.useState(!1),{ratio:r,verdict:o,isLarge:i}=e;return c.jsxs("div",{className:"lpe-pair-card",children:[c.jsxs("div",{className:"lpe-pair-head",children:[c.jsx("div",{className:"lpe-pair-preview",style:{background:e.bg,color:e.fg},children:"Aa"}),c.jsxs("div",{className:"lpe-pair-stats",children:[c.jsx("div",{className:"lpe-pair-ratio",children:r.toFixed(2)}),c.jsxs("div",{className:`lpe-pair-verdict lpe-pair-verdict-${o.label.toLowerCase()}`,children:[o.label," · ",i?N.inspectContrastLarge:N.inspectContrastNormal]}),c.jsx("div",{className:"lpe-pair-instances",children:xt(N.inspectContrastInstances,{n:e.instances})})]}),c.jsx("button",{type:"button",className:"lpe-link",onClick:()=>n(a=>!a),children:t?N.inspectContrastHideDetails:N.inspectContrastShowDetails})]}),t&&c.jsxs("div",{className:"lpe-pair-details",children:[c.jsxs("div",{className:"lpe-pair-swatches",children:[c.jsx(fd,{label:N.inspectContrastText,value:e.fg}),c.jsx(fd,{label:N.inspectContrastBackground,value:e.bg})]}),c.jsx(gg,{v:o})]})]})}function fd({label:e,value:t}){return c.jsxs("div",{className:"lpe-pair-swatch",children:[c.jsx("span",{className:"lpe-pair-swatch-label",children:e}),c.jsxs("div",{className:"lpe-pair-swatch-row",children:[c.jsx("span",{className:"lpe-color-swatch",style:{background:t},"aria-hidden":"true"}),c.jsx("span",{className:"lpe-color-hex",children:t})]})]})}function gg({v:e}){return c.jsxs("table",{className:"lpe-aa-grid",children:[c.jsx("thead",{children:c.jsxs("tr",{children:[c.jsx("th",{}),c.jsx("th",{children:"AA"}),c.jsx("th",{children:"AAA"})]})}),c.jsxs("tbody",{children:[c.jsxs("tr",{children:[c.jsx("th",{scope:"row",children:N.inspectContrastNormal}),c.jsx("td",{children:c.jsx(Ti,{ok:e.normalAA})}),c.jsx("td",{children:c.jsx(Ti,{ok:e.normalAAA})})]}),c.jsxs("tr",{children:[c.jsx("th",{scope:"row",children:N.inspectContrastLarge}),c.jsx("td",{children:c.jsx(Ti,{ok:e.largeAA})}),c.jsx("td",{children:c.jsx(Ti,{ok:e.largeAAA})})]})]})]})}function Ti({ok:e}){return c.jsx("span",{className:`lpe-aa-pill ${e?"is-pass":"is-fail"}`,children:e?"Pass":"Fail"})}function xg({snapshot:e}){const t=e.cssStats,n=t.ruleCount===0&&t.inlineStyleTagCount===0&&t.externalSheetCount===0;return c.jsxs("section",{className:"lpe-cssinfo","aria-label":N.inspectCssTitle,children:[c.jsx("header",{className:"lpe-section-header",children:c.jsx("h2",{className:"lpe-section-title",children:N.inspectCssTitle})}),n?c.jsx("div",{className:"lpe-inspect-empty",children:c.jsx("span",{children:N.inspectCssNone})}):c.jsxs(c.Fragment,{children:[c.jsxs("div",{className:"lpe-cssinfo-grid",children:[c.jsx(Ai,{label:N.inspectCssRules,value:ms(t.ruleCount)}),c.jsx(Ai,{label:N.inspectCssSize,value:vg(t.cssBytes)}),c.jsx(Ai,{label:N.inspectCssExternalSheets,value:ms(t.externalSheetCount)}),c.jsx(Ai,{label:N.inspectCssInlineTags,value:ms(t.inlineStyleTagCount)})]}),t.unreachableSheetCount>0&&c.jsxs("div",{className:"lpe-cssinfo-warn",role:"note",children:[c.jsxs("strong",{children:[N.inspectCssUnreachable,": ",t.unreachableSheetCount]}),c.jsx("span",{children:N.inspectCssUnreachableHint})]})]})]})}function Ai({label:e,value:t}){return c.jsxs("div",{className:"lpe-cssinfo-stat",children:[c.jsx("span",{className:"lpe-cssinfo-stat-value",children:t}),c.jsx("span",{className:"lpe-cssinfo-stat-label",children:e})]})}function ms(e){return new Intl.NumberFormat(void 0).format(e)}function vg(e){if(!Number.isFinite(e)||e<=0)return"0 B";if(e<1024)return`${e} B`;const t=e/1024;if(t<1024)return t>=100?`${Math.round(t)} KB`:`${t.toFixed(1)} KB`;const n=t/1024;return n>=100?`${Math.round(n)} MB`:`${n.toFixed(1)} MB`}function yg(e,t){const n=e.x+e.w,r=e.y+e.h,o=t.x+t.w,i=t.y+t.h,a=Math.round(e.x-t.x),l=Math.round(o-n),s=Math.round(e.y-t.y),u=Math.round(i-r),y=Math.round(t.x>=n?t.x-n:e.x>=o?e.x-o:-Math.min(n,o)+Math.max(e.x,t.x)),x=Math.round(t.y>=r?t.y-r:e.y>=i?e.y-i:-Math.min(r,i)+Math.max(e.y,t.y)),w=y<0&&x<0;return{left:a,right:l,top:s,bottom:u,hGap:y,vGap:x,overlap:w}}const bg=[["display","display"],["position","position"],["color","color"],["backgroundColor","background-color"],["fontFamily","font-family"],["fontSize","font-size"],["fontWeight","font-weight"],["lineHeight","line-height"],["margin","margin"],["padding","padding"],["border","border"]];function wg(e){const t=e.tagName||"div",n=e.classList.length>0?` class="${kg(e.classList.join(" "))}"`:"",r=`<${t}${n}>
  <!-- … -->
</${t}>`,o=bg.map(([a,l])=>{const s=(e.styles[a]??"").trim();return s?`  ${l}: ${s};`:null}).filter(a=>a!==null).join(`
`),i=`${e.selector} {
${o}
}`;return{html:r,css:i}}function kg(e){return e.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;")}function Sg({sample:e,onClose:t}){const n=G.useMemo(()=>wg(e),[e]),[r,o]=G.useState("html"),[i,a]=G.useState(!1),l=G.useCallback(async()=>{const s=r==="html"?n.html:n.css;try{await navigator.clipboard.writeText(s)}catch{}a(!0),window.setTimeout(()=>a(!1),1200)},[r,n]);return G.useEffect(()=>{const s=u=>{u.key==="Escape"&&t()};return window.addEventListener("keydown",s),()=>window.removeEventListener("keydown",s)},[t]),c.jsx("div",{className:"lpe-modal-backdrop",role:"dialog","aria-modal":"true","aria-label":N.inspectShowCodeTitle,onClick:t,children:c.jsxs("div",{className:"lpe-modal lpe-modal-code",onClick:s=>s.stopPropagation(),children:[c.jsxs("div",{className:"lpe-modal-header",children:[c.jsxs("h3",{children:[N.inspectShowCodeTitle," — ",c.jsx("span",{className:"lpe-modal-code-selector",children:e.selector})]}),c.jsx("button",{type:"button",className:"lpe-btn",onClick:t,"aria-label":N.inspectClose,children:N.inspectClose})]}),c.jsxs("div",{className:"lpe-modal-body",children:[c.jsxs("div",{className:"lpe-subtabs",role:"tablist","aria-label":"Code view",children:[c.jsx("button",{type:"button",role:"tab",className:"lpe-subtab","aria-selected":r==="html","data-active":r==="html"?"true":"false",onClick:()=>o("html"),children:N.inspectShowCodeTabHtml}),c.jsx("button",{type:"button",role:"tab",className:"lpe-subtab","aria-selected":r==="css","data-active":r==="css"?"true":"false",onClick:()=>o("css"),children:N.inspectShowCodeTabCss})]}),c.jsx("pre",{className:"lpe-modal-code-pre",children:c.jsx("code",{children:r==="html"?n.html:n.css})}),c.jsxs("div",{className:"lpe-modal-code-footer",children:[c.jsx("button",{type:"button",className:"lpe-btn",onClick:()=>void l(),children:i?N.inspectShowCodeCopied:N.inspectShowCodeCopy}),c.jsx("span",{className:"lpe-modal-code-note",children:N.inspectShowCodeNote})]})]})]})})}const hd=8,_g=["display","position","color","backgroundColor","fontFamily","fontSize","fontWeight","lineHeight","margin","padding","border"];function Cg({snapshot:e}){const t=G.useMemo(()=>Ng(e.computedSamples),[e.computedSamples]),[n,r]=G.useState(new Set),[o,i]=G.useState(!1),[a,l]=G.useState(null),[s,u]=G.useState(null),[y,x]=G.useState(null),w=o?t:t.slice(0,hd),h=s!==null?t[s]??null:null,b=y!==null?t[y]??null:null,f=p=>{r(d=>{const g=new Set(d);return g.has(p)?g.delete(p):g.add(p),g})},v=async(p,d)=>{try{await navigator.clipboard.writeText(d)}catch{}l(p),window.setTimeout(()=>l(g=>g===p?null:g),1200)};return c.jsxs("section",{className:"lpe-inspector","aria-label":N.inspectInspectorTitle,children:[c.jsx("header",{className:"lpe-section-header",children:c.jsx("h2",{className:"lpe-section-title",children:N.inspectInspectorTitle})}),t.length===0?c.jsx("div",{className:"lpe-inspect-empty",children:c.jsx("span",{children:N.inspectInspectorEmpty})}):c.jsxs(c.Fragment,{children:[c.jsx("p",{className:"lpe-inspector-hint",children:N.inspectInspectorHint}),h&&c.jsxs("div",{className:"lpe-inspector-anchor-banner",children:[c.jsx("span",{title:h.selector,children:xt(N.inspectInspectorAnchorBanner,{selector:h.selector})}),c.jsx("button",{type:"button",className:"lpe-link",onClick:()=>u(null),children:N.inspectInspectorClearAnchor})]}),c.jsx("ul",{className:"lpe-inspector-list",children:w.map((p,d)=>{const g=n.has(d),S=xt(N.inspectInspectorRect,{w:p.rect.w,h:p.rect.h}),C=s===d;return c.jsxs("li",{className:"lpe-inspector-item",children:[c.jsxs("button",{type:"button",className:`lpe-inspector-row${C?" is-anchor":""}`,"aria-expanded":g,onClick:()=>f(d),children:[c.jsx("span",{className:"lpe-inspector-tag",children:p.tagName}),c.jsx("span",{className:"lpe-inspector-selector",title:p.selector,children:p.selector}),c.jsx("span",{className:"lpe-inspector-dims",children:S}),c.jsx("span",{className:"lpe-inspector-caret","aria-hidden":"true",children:g?"▾":"▸"})]}),g&&c.jsxs("div",{className:"lpe-inspector-detail",children:[c.jsx("dl",{className:"lpe-inspector-styles",children:_g.map(A=>{const T=p.styles[A];return T?c.jsxs("div",{className:"lpe-inspector-style-row",children:[c.jsx("dt",{children:A}),c.jsx("dd",{title:T,children:T})]},A):null})}),h&&!C&&c.jsx(Eg,{anchor:h.rect,target:p.rect}),h&&C&&c.jsx("p",{className:"lpe-inspector-dist-self",children:N.inspectInspectorDistSelf}),c.jsxs("div",{className:"lpe-inspector-actions",children:[c.jsx("button",{type:"button",className:"lpe-link",onClick:()=>void v(d,p.selector),children:a===d?N.inspectInspectorCopied:N.inspectInspectorCopySelector}),c.jsx("button",{type:"button",className:"lpe-link",onClick:()=>u(C?null:d),children:C?N.inspectInspectorClearAnchor:N.inspectInspectorAnchor}),c.jsx("button",{type:"button",className:"lpe-link",onClick:()=>x(d),children:N.inspectInspectorShowCode})]})]})]},`${p.selector}-${d}`)})}),t.length>hd&&c.jsx("button",{type:"button",className:"lpe-link",onClick:()=>i(p=>!p),children:o?N.inspectInspectorShowLess:N.inspectInspectorShowMore})]}),b&&c.jsx(Sg,{sample:b,onClose:()=>x(null)})]})}function Eg({anchor:e,target:t}){const n=yg(e,t);return c.jsxs("div",{className:"lpe-inspector-dist",role:"group","aria-label":N.inspectInspectorDistTitle,children:[c.jsx("div",{className:"lpe-inspector-dist-title",children:N.inspectInspectorDistTitle}),c.jsxs("dl",{className:"lpe-inspector-dist-grid",children:[c.jsx(pr,{label:N.inspectInspectorDistLeft,value:n.left}),c.jsx(pr,{label:N.inspectInspectorDistRight,value:n.right}),c.jsx(pr,{label:N.inspectInspectorDistTop,value:n.top}),c.jsx(pr,{label:N.inspectInspectorDistBottom,value:n.bottom}),c.jsx(pr,{label:N.inspectInspectorDistHGap,value:n.hGap}),c.jsx(pr,{label:N.inspectInspectorDistVGap,value:n.vGap})]}),n.overlap&&c.jsx("span",{className:"lpe-inspector-dist-chip",children:N.inspectInspectorDistOverlap})]})}function pr({label:e,value:t}){return c.jsxs("div",{className:"lpe-inspector-dist-row",children:[c.jsx("dt",{children:e}),c.jsxs("dd",{children:[t,"px"]})]})}function Ng(e){return e.filter(t=>t.rect.w>0&&t.rect.h>0).filter(t=>t.tagName!=="html"&&t.tagName!=="body").slice().sort((t,n)=>n.rect.w*n.rect.h-t.rect.w*t.rect.h)}function jg({snapshot:e}){const[t,n]=G.useState(!1),r=G.useRef(null);G.useEffect(()=>{if(!t)return;const a=s=>{r.current?.contains(s.target)||n(!1)},l=s=>{s.key==="Escape"&&n(!1)};return document.addEventListener("mousedown",a,!0),window.addEventListener("keydown",l),()=>{document.removeEventListener("mousedown",a,!0),window.removeEventListener("keydown",l)}},[t]);const o=cd(e),i=[{label:N.inspectExportJson,run:()=>{const{mime:a,ext:l}=ro("json");oo(tg(e),`${o}.${l}`,a)}},{label:N.inspectExportMarkdown,run:()=>{const{mime:a,ext:l}=ro("md");oo(ng(e),`${o}.${l}`,a)}},{label:N.inspectExportColorsCsv,run:()=>{const{mime:a,ext:l}=ro("csv");oo(ld(e.colors),`${o}-colors.${l}`,a)}},{label:N.inspectExportFontsCsv,run:()=>{const{mime:a,ext:l}=ro("csv");oo(eg(e.fonts),`${o}-fonts.${l}`,a)}}];return c.jsxs("div",{className:"lpe-export-menu",ref:r,children:[c.jsxs("button",{type:"button",className:"lpe-link","aria-haspopup":"menu","aria-expanded":t,onClick:()=>n(a=>!a),children:[N.inspectExportReport," ▾"]}),t&&c.jsx("ul",{className:"lpe-export-menu-pop",role:"menu",children:i.map(a=>c.jsx("li",{children:c.jsx("button",{type:"button",role:"menuitem",className:"lpe-export-menu-item",onClick:()=>{a.run(),n(!1)},children:a.label})},a.label))})]})}let xn=null;function Fg(e){const t=globalThis.requestIdleCallback;typeof t=="function"?t(e,{timeout:200}):setTimeout(e,0)}function Tg(){const[e,t]=G.useState(()=>xn?{status:"ready",snapshot:xn.data.snapshot,thumbnailDataUrl:xn.data.thumbnailDataUrl}:{status:"loading"}),n=G.useRef(!0),r=G.useCallback(async(i=!1)=>{if(!i&&xn){t({status:"ready",snapshot:xn.data.snapshot,thumbnailDataUrl:xn.data.thumbnailDataUrl});return}t({status:"loading"});try{const a=await Me(xe.CollectInspectSnapshot,{tabId:-1});if(xn={key:"_",data:a},!n.current)return;t({status:"ready",snapshot:a.snapshot,thumbnailDataUrl:a.thumbnailDataUrl})}catch(a){if(!n.current)return;t({status:"error",error:a instanceof Error?a.message:String(a)})}},[]);G.useEffect(()=>(n.current=!0,xn||Fg(()=>{r()}),()=>{n.current=!1}),[r]);const o=G.useCallback(()=>{try{window.open(Vd,"_blank","noopener,noreferrer")}catch{}},[]);return c.jsxs("div",{className:"lpe-inspect-shell",role:"region","aria-label":N.inspectModeTitle,children:[e.status==="ready"&&e.snapshot&&c.jsxs("header",{className:"lpe-inspect-shell-header",children:[c.jsx(jg,{snapshot:e.snapshot}),c.jsx("button",{type:"button",className:"lpe-btn",onClick:()=>void r(!0),title:N.inspectRetry,style:{width:"auto",padding:"4px 10px",fontSize:12},children:"↻"})]}),e.status==="loading"&&c.jsxs("div",{className:"lpe-inspect-skeleton","aria-busy":"true","aria-live":"polite",children:[c.jsx("span",{className:"lpe-inspect-skeleton-label",children:N.inspectLoading}),c.jsx("div",{className:"lpe-skel lpe-skel-block"}),c.jsx("div",{className:"lpe-skel lpe-skel-line",style:{width:"70%"}}),c.jsx("div",{className:"lpe-skel lpe-skel-line",style:{width:"55%"}}),c.jsx("div",{className:"lpe-skel lpe-skel-block"}),c.jsx("div",{className:"lpe-skel lpe-skel-line",style:{width:"80%"}})]}),e.status==="error"&&c.jsxs("div",{className:"lpe-inspect-empty",children:[c.jsx("strong",{children:N.inspectError}),c.jsx("span",{children:e.error}),c.jsx("button",{type:"button",className:"lpe-btn",onClick:()=>void r(!0),children:N.inspectRetry})]}),e.status==="ready"&&e.snapshot&&c.jsxs(c.Fragment,{children:[c.jsx(Vm,{snapshot:e.snapshot,thumbnailDataUrl:e.thumbnailDataUrl??"",onOpenDocs:o}),c.jsx(Gm,{snapshot:e.snapshot}),c.jsx(rg,{snapshot:e.snapshot}),c.jsx(fg,{snapshot:e.snapshot}),c.jsx(xg,{snapshot:e.snapshot}),c.jsx(Cg,{snapshot:e.snapshot}),c.jsx("footer",{className:"lpe-inspect-footer",children:c.jsx("span",{children:xt(N.inspectFooterLabel,{version:"2.5.0"})})})]})]})}function Ag(e){const{snapshot:t,onShowCode:n,onBack:r,onTogglePickerLock:o,pickerLocked:i}=e,{identity:a,text:l,selection:s}=t,u=G.useCallback(async y=>{try{await navigator.clipboard.writeText(y)}catch{}},[]);return c.jsxs("div",{className:"lpe-eli","aria-label":"Element inspector",children:[c.jsxs("div",{className:"lpe-eli-header",children:[r&&c.jsx("button",{type:"button",className:"lpe-header-btn",onClick:r,"aria-label":"Back",children:"←"}),c.jsx("span",{className:"lpe-eli-title",children:"Inspector"}),c.jsx("span",{className:"lpe-spacer"}),c.jsx("button",{type:"button",className:"lpe-btn lpe-eli-show-code",onClick:n,"aria-label":"Show code",children:"Show code"})]}),c.jsxs("div",{className:"lpe-eli-identity",children:[c.jsx("div",{className:"lpe-eli-label",children:a.label}),c.jsxs("div",{className:"lpe-eli-selector",title:a.selectorPath,children:[c.jsx("span",{className:"lpe-eli-tag",children:a.tag}),a.classList.slice(0,3).map(y=>c.jsxs("span",{className:"lpe-eli-class",children:[".",y]},y))]})]}),c.jsxs("label",{className:"lpe-eli-toggle",children:[c.jsx("input",{type:"checkbox",checked:!!i,onChange:y=>o?.(y.target.checked)}),c.jsx("span",{children:"Context menu while hovering"})]}),c.jsx(Ig,{snapshot:t}),c.jsxs("section",{className:"lpe-eli-section","aria-label":"Text properties",children:[c.jsx("h4",{className:"lpe-eli-h4",children:"Text properties"}),c.jsx(vn,{label:"Font Family",value:l.fontFamily,mono:!0,onCopy:()=>u(l.fontFamily)}),c.jsx(vn,{label:"Font Size",value:`${Math.round(l.fontSizePx)}px`}),c.jsx(vn,{label:"Line Height",value:l.lineHeightPx==null?"normal":`${Math.round(l.lineHeightPx)}px`}),c.jsx(vn,{label:"Font Weight",value:`${Pg(l.fontWeight)} (${l.fontWeight})`}),c.jsx(vn,{label:"Letter Spacing",value:l.letterSpacing||"normal"}),c.jsx(vn,{label:"Text color",value:l.color,swatch:l.color,onCopy:()=>u(l.color)})]}),c.jsx(zg,{selection:s,onCopy:u})]})}function Pg(e){return e<=300?"Light":e===400?"Regular":e===500?"Medium":e===600?"Semibold":e===700?"Bold":e>=800?"Black":"Custom"}function vn({label:e,value:t,mono:n,swatch:r,onCopy:o}){return c.jsxs("div",{className:"lpe-eli-row",children:[c.jsx("span",{className:"lpe-eli-rowlabel",children:e}),c.jsxs("span",{className:`lpe-eli-rowvalue${n?" is-mono":""}`,children:[r&&c.jsx("span",{className:"lpe-eli-swatch",style:{background:r},"aria-hidden":"true"}),c.jsx("span",{className:"lpe-eli-rowtext",title:t,children:t}),o&&c.jsx("button",{type:"button",className:"lpe-eli-copy",onClick:o,"aria-label":`Copy ${e}`,title:`Copy ${e}`,children:"⎘"})]})]})}function Ig({snapshot:e}){const{box:t}=e,n=r=>r===0?"-":String(Math.round(r));return c.jsx("div",{className:"lpe-bm","aria-label":"Box model",children:c.jsxs("div",{className:"lpe-bm-margin",children:[c.jsx("span",{className:"lpe-bm-tag",children:"margin"}),c.jsx("span",{className:"lpe-bm-tl",children:n(t.margin.top)}),c.jsx("span",{className:"lpe-bm-tr",children:n(t.margin.right)}),c.jsx("span",{className:"lpe-bm-br",children:n(t.margin.bottom)}),c.jsx("span",{className:"lpe-bm-bl",children:n(t.margin.left)}),c.jsxs("div",{className:"lpe-bm-border",children:[c.jsx("span",{className:"lpe-bm-tag",children:"border"}),c.jsx("span",{className:"lpe-bm-tl",children:n(t.border.top)}),c.jsx("span",{className:"lpe-bm-tr",children:n(t.border.right)}),c.jsx("span",{className:"lpe-bm-br",children:n(t.border.bottom)}),c.jsx("span",{className:"lpe-bm-bl",children:n(t.border.left)}),c.jsxs("div",{className:"lpe-bm-padding",children:[c.jsx("span",{className:"lpe-bm-tag",children:"padding"}),c.jsx("span",{className:"lpe-bm-tl",children:n(t.padding.top)}),c.jsx("span",{className:"lpe-bm-tr",children:n(t.padding.right)}),c.jsx("span",{className:"lpe-bm-br",children:n(t.padding.bottom)}),c.jsx("span",{className:"lpe-bm-bl",children:n(t.padding.left)}),c.jsxs("div",{className:"lpe-bm-content",children:[Math.round(t.content.w)," × ",Math.round(t.content.h)]})]})]})]})})}function zg({selection:e,onCopy:t}){const{fg:n,bg:r,contrast:o}=e,i=o.ratio.toFixed(2),a=o.verdict,l=a.label==="Excellent"?"is-excellent":a.label==="Good"?"is-good":a.label==="Poor"?"is-poor":"is-fail";return c.jsxs("section",{className:"lpe-eli-section","aria-label":"Selection colors and contrast",children:[c.jsx("h4",{className:"lpe-eli-h4",children:"Selection colors"}),c.jsx(vn,{label:"Foreground",value:n,swatch:n,onCopy:()=>t(n)}),c.jsx(vn,{label:"Background",value:r,swatch:r,onCopy:()=>t(r)}),c.jsxs("div",{className:"lpe-eli-row",children:[c.jsx("span",{className:"lpe-eli-rowlabel",children:"Contrast"}),c.jsxs("span",{className:"lpe-eli-rowvalue",children:[c.jsx("span",{className:"lpe-eli-sample",style:{color:n,background:r},children:"Aa"}),c.jsxs("span",{className:"lpe-eli-rowtext",children:[i,":1"]}),c.jsx("span",{className:`lpe-eli-verdict ${l}`,children:a.label})]})]}),c.jsxs("div",{className:"lpe-eli-wcag","aria-label":"WCAG conformance",children:[c.jsx(md,{ok:o.isLarge?a.largeAA:a.normalAA,children:"AA"}),c.jsx(md,{ok:o.isLarge?a.largeAAA:a.normalAAA,children:"AAA"}),c.jsx("span",{className:"lpe-eli-wcag-note",children:o.isLarge?"Large text":"Normal text"})]})]})}function md({ok:e,children:t}){return c.jsxs("span",{className:`lpe-eli-tagpill ${e?"is-pass":"is-fail"}`,children:[e?"✓":"×"," ",t]})}function Rg({snapshot:e,onClose:t}){const[n,r]=G.useState("base"),[o,i]=G.useState("layout"),a=e.matched[n]||"/* no rules */",l=G.useMemo(()=>Lg(e.groupedDiff[o]),[e,o]),s=G.useCallback(async u=>{try{await navigator.clipboard.writeText(u)}catch{}},[]);return c.jsxs("div",{className:"lpe-cdr",role:"dialog","aria-label":"Element code",children:[c.jsxs("div",{className:"lpe-cdr-header",children:[c.jsx("span",{className:"lpe-cdr-title",children:"Code"}),c.jsx("span",{className:"lpe-spacer"}),c.jsx("button",{type:"button",className:"lpe-header-btn",onClick:t,"aria-label":"Close",children:"×"})]}),c.jsxs("section",{className:"lpe-cdr-section",children:[c.jsxs("div",{className:"lpe-cdr-tabs",role:"tablist","aria-label":"State",children:[["base","hover","focus","active","disabled"].map(u=>c.jsx("button",{type:"button",role:"tab","aria-selected":n===u,className:`lpe-cdr-tab ${n===u?"is-active":""}`,onClick:()=>r(u),children:u},u)),c.jsx("span",{className:"lpe-spacer"}),c.jsx("button",{type:"button",className:"lpe-cdr-copy",onClick:()=>s(a),"aria-label":"Copy matched CSS",children:"Copy"})]}),c.jsx("pre",{className:"lpe-cdr-pre",children:c.jsx("code",{children:a})})]}),c.jsxs("section",{className:"lpe-cdr-section",children:[c.jsxs("div",{className:"lpe-cdr-tabs",role:"tablist","aria-label":"Computed group",children:[["layout","typography","background","border","effects","other"].map(u=>c.jsx("button",{type:"button",role:"tab","aria-selected":o===u,className:`lpe-cdr-tab ${o===u?"is-active":""}`,onClick:()=>i(u),children:u},u)),c.jsx("span",{className:"lpe-spacer"}),c.jsx("button",{type:"button",className:"lpe-cdr-copy",onClick:()=>s(l),"aria-label":"Copy computed styles",children:"Copy"})]}),c.jsx("pre",{className:"lpe-cdr-pre",children:c.jsx("code",{children:l})})]})]})}function Lg(e){const t=Object.keys(e).sort();return t.length===0?"/* no overrides */":t.map(n=>`${n}: ${e[n]};`).join(`
`)}const gd="inspect-page:theme",Dg=["chrome://","edge://","about:","chrome-extension://","view-source:"];function Og(e){return e?Dg.some(t=>e.startsWith(t)):!1}function Mg(e){switch(e.status){case de.Idle:return N.statusIdle;case de.Collecting:return N.statusCollecting;case de.Capturing:return xt(N.statusCapturing,{done:e.progress?.done??0,total:e.progress?.total??0});case de.Stitching:return N.statusStitching;case de.Bundling:return N.statusBundling;case de.Downloading:return N.statusDownloading;case de.PickerActive:return N.statusPicker;case de.Selecting:return N.statusSelecting;case de.Success:return xt(N.statusSuccess,{filename:e.successFilename??""});case de.Error:return xt(N.statusError,{message:e.message??"",code:e.errorCode??""})}}const Bg=new Set([de.Collecting,de.Capturing,de.Stitching,de.Bundling,de.Downloading,de.PickerActive,de.Selecting]);function $g(e){const{surface:t,activeUrl:n,activeTabId:r,onMinimize:o,onClose:i,onPopOut:a}=e,[l,s]=G.useState({status:de.Idle}),[u,y]=G.useState(null),[x,w]=G.useState(null),[h,b]=G.useState(null),[f,v]=G.useState(null),[p,d]=G.useState(!0),[g,S]=G.useState("export"),[C,A]=G.useState(!1),T=G.useRef(null),[R,L]=G.useState(()=>{try{return globalThis.localStorage?.getItem(gd)==="dark"?"dark":"light"}catch{return"light"}}),M=G.useCallback(()=>{L(ee=>{const oe=ee==="light"?"dark":"light";try{globalThis.localStorage?.setItem(gd,oe)}catch{}return oe})},[]),ie=G.useCallback(()=>{A(ee=>!ee)},[]),F=G.useCallback(()=>{A(!1),T.current?.focus()},[]);G.useEffect(()=>{if(!C)return;const ee=oe=>{oe.key==="Escape"&&(oe.preventDefault(),F())};return window.addEventListener("keydown",ee),()=>window.removeEventListener("keydown",ee)},[C,F]);const B=Og(n);G.useEffect(()=>{let ee=!0;return Lm().then(oe=>{ee&&d(oe.dismissed)}).catch(()=>{}),()=>{ee=!1}},[]);const k=G.useCallback(async()=>{d(!0);try{await Dm()}catch{}},[]);G.useEffect(()=>{let ee=!0;return Me(xe.GetSettings,{}).then(oe=>{ee&&y(oe)}).catch(oe=>{if(!ee)return;const pe=oe instanceof Error?oe.message:String(oe);w(pe)}),()=>{ee=!1}},[]),G.useEffect(()=>{let ee=!0;return Me(xe.GetShareSettings,{}).then(oe=>{ee&&b(oe)}).catch(()=>{}),()=>{ee=!1}},[]),G.useEffect(()=>{const ee=ue=>{s(ye=>({...ye,status:ue.status,message:ue.message??ye.message,progress:ue.progress,...ue.status===de.Error?{errorCode:ue.errorCode,errorDetail:ue.errorDetail}:{},...ue.debugPreview?{debugPreview:ue.debugPreview}:{},...ue.elementSnapshot?{elementSnapshot:ue.elementSnapshot}:{},...ue.status===de.Success&&ue.telemetry?{successTelemetry:ue.telemetry}:{},...ue.status===de.Success&&ue.fullPageArtifacts?{fullPageArtifacts:ue.fullPageArtifacts}:{},...ue.status===de.Success&&ue.message?{successFilename:ue.message}:{}}))},oe=ue=>{if(typeof ue!="object"||ue===null)return;const ye=ue;ye.kind===xe.StatusUpdate&&ee(ye.payload)},pe=ue=>{const ye=ue;ye.detail&&ee(ye.detail)};return chrome?.runtime?.onMessage?.addListener?.(oe),window.addEventListener("inspect-page:status",pe),()=>{chrome?.runtime?.onMessage?.removeListener?.(oe),window.removeEventListener("inspect-page:status",pe)}},[]);const H=G.useCallback(async ee=>{if(B)return;const oe=r??-1;s({status:de.Collecting,lastAction:ee});try{if(ee==="fullPage"){const pe=await Me(xe.RunFullPageExport,{tabId:oe,settings:u});s({status:de.Success,successFilename:pe.bundleFilename,successTelemetry:pe.telemetry,fullPageArtifacts:pe.artifacts,lastAction:ee})}else await Me(xe.EnterPickerMode,{tabId:oe}),s({status:de.PickerActive,lastAction:ee})}catch(pe){const ue=pe instanceof He?pe:null;s({status:de.Error,message:ue?.message??(pe instanceof Error?pe.message:String(pe)),errorCode:ue?.code,errorDetail:ue?.detail,lastAction:ee})}},[B,r,u]),ce=G.useCallback(()=>void H("fullPage"),[H]),Q=G.useCallback(()=>void H("pick"),[H]),Z=G.useCallback(async()=>{if(l.lastAction==="pick")try{await Me(xe.ExitPickerMode,{tabId:r??-1})}catch{}s({status:de.Idle})},[r,l.lastAction]),$=G.useCallback(()=>{l.lastAction&&H(l.lastAction)},[H,l.lastAction]),O=G.useCallback(async()=>{const ee=JSON.stringify({code:l.errorCode,message:l.message,detail:l.errorDetail},null,2);try{await navigator.clipboard.writeText(ee)}catch{}},[l.errorCode,l.message,l.errorDetail]),P=G.useCallback(async ee=>{try{const oe=await Me(xe.SetSettings,ee);y(oe)}catch(oe){w(oe instanceof Error?oe.message:String(oe))}},[]),I=G.useCallback(async ee=>{try{const oe=await Me(xe.SetShareSettings,ee);b(oe)}catch{}},[]),re=G.useCallback(async ee=>{const oe=ee.images[0];if(!oe)throw new Error("No image to upload — Share Links requires a screenshot.");const pe=await Me(xe.CreateShareSession,{kind:ee.flow,sourceUrl:n??ee.meta?.url??"",html:ee.html,css:ee.css,js:ee.js,imageBase64:oe.base64,imageMime:oe.mime});v(pe)},[n]),te=G.useCallback(async()=>{if(r!==void 0)try{await Me(xe.MountFloatingPanel,{tabId:r}),window.close()}catch(ee){const oe=ee instanceof He?ee:null;s({status:de.Error,message:oe?.message??(ee instanceof Error?ee.message:String(ee)),errorCode:oe?.code})}},[r]),J=G.useCallback(async()=>{{s({status:de.Error,message:N.shareNotConfiguredMsg,errorCode:ke.E_SHARE_AUTH});return}},[p]),fe=G.useMemo(()=>Bg.has(l.status),[l.status]);return c.jsxs("div",{className:"lpe-root","data-lpe-theme":R,"data-lpe-surface":t,role:"region","aria-label":N.appName,children:[c.jsxs("header",{className:"lpe-header","data-draggable":t==="floating"?"true":"false","data-drag-handle":t==="floating"?"true":void 0,children:[c.jsx("button",{ref:T,type:"button",className:"lpe-header-btn",onClick:ie,"aria-label":N.settingsHeader,"aria-expanded":C,"aria-haspopup":"dialog",title:N.settingsHeader,children:"≡"}),c.jsx("span",{className:"lpe-header-title",children:N.appName}),c.jsx("button",{type:"button",className:"lpe-header-btn",onClick:M,"aria-label":R==="light"?N.btnThemeDark:N.btnThemeLight,title:R==="light"?N.btnThemeDark:N.btnThemeLight,children:R==="light"?"☾":"☀"}),t==="floating"&&c.jsxs(c.Fragment,{children:[c.jsx("button",{type:"button",className:"lpe-header-btn",onClick:a,"aria-label":N.btnPopOut,title:N.btnPopOut,children:"⧉"}),c.jsx("button",{type:"button",className:"lpe-header-btn",onClick:o,"aria-label":N.btnMinimize,children:"─"}),c.jsx("button",{type:"button",className:"lpe-header-btn",onClick:i,"aria-label":N.btnClose,children:"✕"})]})]}),C&&c.jsxs("div",{className:"lpe-settings-popover",role:"dialog","aria-label":N.settingsHeader,children:[c.jsxs("div",{className:"lpe-settings-popover-head",children:[c.jsx("strong",{children:N.settingsHeader}),c.jsx("button",{type:"button",className:"lpe-header-btn",onClick:F,"aria-label":N.btnClose,children:"✕"})]}),c.jsxs("div",{className:"lpe-settings-popover-body",children:[u&&c.jsx(Ug,{settings:u,error:x,onPatch:P}),h&&c.jsx(Zg,{settings:h,onPatch:I})]})]}),c.jsx("div",{className:"lpe-tabs",role:"tablist","aria-label":N.appName,children:["export","pick","inspect"].map(ee=>c.jsx("button",{type:"button",role:"tab","aria-selected":g===ee,className:"lpe-tab","data-active":g===ee?"true":"false",onClick:()=>S(ee),children:ee==="export"?N.tabExport:ee==="pick"?N.tabPick:N.tabInspect},ee))}),t==="popup"&&!p&&!Bm(h??{siteUrl:"",userId:0,nonce:""})&&c.jsxs("div",{className:"lpe-onboarding",role:"status",children:[c.jsxs("div",{children:[c.jsx("strong",{children:N.onboardingTitle}),c.jsx("span",{children:N.onboardingBody})]}),c.jsxs("div",{className:"lpe-onboarding-actions",children:[c.jsx("button",{type:"button",className:"lpe-btn lpe-btn-primary",onClick:()=>void J(),children:N.onboardingSignIn}),c.jsx("button",{type:"button",className:"lpe-btn",onClick:k,children:N.onboardingDismiss})]})]}),c.jsxs("div",{className:"lpe-body","data-mode":g,children:[g==="inspect"?c.jsx(Tg,{}):B?c.jsx("div",{className:"lpe-not-available",role:"alert",children:N.notAvailable}):c.jsxs(c.Fragment,{children:[g==="export"&&c.jsxs(c.Fragment,{children:[c.jsxs("button",{type:"button",className:"lpe-btn lpe-btn-primary lpe-btn-hero",onClick:ce,disabled:fe||u===null,children:[c.jsxs("svg",{className:"lpe-btn-ico",viewBox:"0 0 20 20",fill:"none","aria-hidden":"true",children:[c.jsx("rect",{x:"2.5",y:"3.5",width:"15",height:"13",rx:"2.5",stroke:"currentColor",strokeWidth:"1.6"}),c.jsx("path",{d:"M6 8h8M6 11h8M6 14h5",stroke:"currentColor",strokeWidth:"1.6",strokeLinecap:"round"})]}),c.jsx("span",{children:N.btnFullPage}),c.jsx("span",{className:"lpe-btn-kbd","aria-hidden":"true",children:"⌥⇧E"})]}),c.jsx(vd,{shareSettings:h,hasArtifacts:!!l.fullPageArtifacts,busy:fe,artifacts:l.fullPageArtifacts?xd(l.fullPageArtifacts,n):null,onShare:re,onSignIn:()=>void J()})]}),g==="pick"&&c.jsxs(c.Fragment,{children:[c.jsx("button",{type:"button",className:"lpe-btn lpe-btn-primary",onClick:Q,disabled:fe||u===null,children:N.btnPick}),c.jsx(vd,{shareSettings:h,hasArtifacts:!!l.debugPreview,busy:fe,artifacts:l.debugPreview?gs(l.debugPreview,n):null,onShare:re,onSignIn:()=>void J()})]}),t==="popup"&&c.jsx("button",{type:"button",className:"lpe-btn",onClick:te,disabled:fe,children:N.btnOpenPanel})]}),c.jsxs("div",{className:"lpe-status","data-status":l.status,role:"status","aria-live":"polite",hidden:l.status===de.Idle,children:[l.status!==de.Idle&&Mg(l),l.status===de.Capturing&&l.progress&&c.jsx("div",{className:"lpe-progress","aria-hidden":"true",children:c.jsx("div",{className:"lpe-progress-bar",style:{width:`${l.progress.done/Math.max(1,l.progress.total)*100}%`}})}),fe&&l.status!==de.PickerActive&&c.jsx("div",{style:{marginTop:6},children:c.jsx("button",{type:"button",className:"lpe-btn",onClick:Z,children:N.btnCancel})}),l.status===de.PickerActive&&c.jsx("div",{style:{marginTop:6},children:c.jsx("button",{type:"button",className:"lpe-btn",onClick:Z,children:N.btnCancelPicker})}),l.status===de.Error&&c.jsxs("div",{className:"lpe-row",style:{marginTop:8},children:[c.jsx("button",{type:"button",className:"lpe-btn",onClick:O,children:N.btnCopyDetails}),c.jsx("button",{type:"button",className:"lpe-btn lpe-btn-primary",onClick:$,children:N.btnRetry}),l.errorCode===ke.E_SHARE_QUOTA_FREE&&c.jsx("button",{type:"button",className:"lpe-btn lpe-btn-primary",onClick:async()=>{ss("upgrade_clicked","inline_quota_error");try{const{url:ee}=await $m({getShareSettings:ed});typeof window<"u"&&ee&&(ss("checkout_opened","inline_quota_error"),window.open(ee,"_blank","noopener,noreferrer"),Wm({getShareSettings:ed}))}catch(ee){ss("checkout_failed","inline_quota_error",{reason:ee instanceof Error?ee.message:String(ee)}),typeof window<"u"&&window.open(Wd,"_blank","noopener,noreferrer")}},children:N.shareUpgradeBtn})]}),l.status===de.Success&&l.successTelemetry&&c.jsx(Hg,{counts:l.successTelemetry})]}),l.status===de.Success&&l.fullPageArtifacts&&c.jsx(Gg,{artifacts:l.fullPageArtifacts,activeUrl:n,shareEnabled:!!h&&!!h.nonce&&!!h.siteUrl,onShare:re}),l.elementSnapshot&&!fe&&c.jsx(Xg,{snapshot:l.elementSnapshot,preview:l.debugPreview,activeUrl:n,shareEnabled:!!h&&!!h.nonce&&!!h.siteUrl,onShare:re,onBack:()=>s(ee=>({...ee,elementSnapshot:void 0,debugPreview:void 0,status:de.Idle}))}),l.debugPreview&&!fe&&c.jsx(Wg,{preview:l.debugPreview,activeUrl:n,shareEnabled:!!h&&!!h.nonce&&!!h.siteUrl,onShare:re,onClear:()=>s(ee=>({...ee,debugPreview:void 0}))})]}),f&&c.jsx(Yg,{result:f,onClose:()=>v(null)}),t==="floating"&&c.jsx("div",{className:"lpe-resize-handle","data-resize-handle":"true","aria-label":N.lblResizePanel,title:N.lblResizePanel,role:"separator"})]})}function Ug({settings:e,error:t,onPatch:n}){return c.jsxs("details",{className:"lpe-settings",open:!0,children:[c.jsx("summary",{children:N.settingsHeader}),c.jsxs("div",{className:"lpe-settings-body",children:[t&&c.jsx("div",{className:"lpe-not-available",role:"alert",children:t}),c.jsxs("div",{className:"lpe-field",children:[c.jsx("label",{htmlFor:"lpe-format",children:N.lblImageFormat}),c.jsxs("select",{id:"lpe-format",className:"lpe-select",value:e.imageFormat,onChange:r=>n({imageFormat:r.target.value}),children:[c.jsx("option",{value:"png",children:"PNG"}),c.jsx("option",{value:"jpeg",children:"JPEG"})]})]}),e.imageFormat==="jpeg"&&c.jsxs("div",{className:"lpe-field",children:[c.jsxs("label",{htmlFor:"lpe-quality",children:[N.lblJpegQuality,": ",e.jpegQuality]}),c.jsx("input",{id:"lpe-quality",type:"range",min:60,max:100,value:e.jpegQuality,onChange:r=>n({jpegQuality:Number(r.target.value)})})]}),c.jsxs("label",{className:"lpe-field-row",children:[c.jsx("input",{type:"checkbox",checked:e.redactPasswordFields,onChange:r=>n({redactPasswordFields:r.target.checked})}),c.jsx("span",{children:N.lblRedact})]}),c.jsxs("label",{className:"lpe-field-row",children:[c.jsx("input",{type:"checkbox",checked:e.includeComputedStyles,onChange:r=>n({includeComputedStyles:r.target.checked})}),c.jsx("span",{children:N.lblComputed})]}),c.jsxs("label",{className:"lpe-field-row",children:[c.jsx("input",{type:"checkbox",checked:e.includeMatchedRules,onChange:r=>n({includeMatchedRules:r.target.checked})}),c.jsx("span",{children:N.lblMatched})]}),c.jsxs("div",{className:"lpe-field",children:[c.jsx("label",{htmlFor:"lpe-name-full",children:N.lblNameFull}),c.jsx("input",{id:"lpe-name-full",className:"lpe-input",value:e.namingTemplateFullPage,onChange:r=>n({namingTemplateFullPage:r.target.value})})]}),c.jsxs("div",{className:"lpe-field",children:[c.jsx("label",{htmlFor:"lpe-name-elem",children:N.lblNameElem}),c.jsx("input",{id:"lpe-name-elem",className:"lpe-input",value:e.namingTemplateElement,onChange:r=>n({namingTemplateElement:r.target.value})})]})]})]})}function Hg({counts:e}){const t=Em(e);return t.length===0?null:c.jsxs("div",{className:"lpe-telemetry","aria-label":N.telemetryHeader,children:[c.jsx("div",{className:"lpe-telemetry-header",children:N.telemetryHeader}),c.jsx("ul",{className:"lpe-telemetry-list",children:t.map(([n,r])=>c.jsxs("li",{className:"lpe-telemetry-row",children:[c.jsx("span",{className:"lpe-telemetry-label",children:n}),c.jsx("span",{className:"lpe-telemetry-value",children:r})]},n))})]})}function Wg({preview:e,activeUrl:t,shareEnabled:n,onShare:r,onClear:o}){const[i,a]=G.useState("html"),[l,s]=G.useState("raw"),u=e[i],y=G.useCallback(async()=>{try{await navigator.clipboard.writeText(u)}catch{}},[u]),x=()=>(e.selectorPath||"element").split(" > ").pop().replace(/[^a-z0-9_-]+/gi,"_").slice(0,40)||"element",w=()=>new Date().toISOString().replace(/[:.]/g,"-").slice(0,19),h=(g,S)=>{const C=document.createElement("a");C.href=URL.createObjectURL(g),C.download=S,C.click(),setTimeout(()=>URL.revokeObjectURL(C.href),1e3)},b=g=>g==="js"?"javascript":g,f=(g,S)=>`# Element — ${e.selectorPath}

## ${g.toUpperCase()}

\`\`\`${b(g)}
${S}
\`\`\`
`,v=()=>`# Element — ${e.selectorPath}

## HTML

\`\`\`html
${e.html||""}
\`\`\`

## CSS

\`\`\`css
${e.css||""}
\`\`\`

## JS

\`\`\`javascript
${e.js||""}
\`\`\`
`,p=G.useCallback(()=>{try{const g=x(),S=w();if(l==="md"){const C=f(i,u||"");h(new Blob([C],{type:"text/markdown;charset=utf-8"}),`inspect-page-element-${g}-${i}-${S}.md`)}else{const C=i==="html"?"text/html":i==="css"?"text/css":"text/javascript";h(new Blob([u||""],{type:`${C};charset=utf-8`}),`inspect-page-element-${g}-${S}.${i}`)}}catch{}},[e,i,u,l]),d=G.useCallback(async()=>{try{const g=x(),S=w(),C=new Fi;l==="md"?C.file("element.md",v()):(C.file("element.html",e.html||""),C.file("element.css",e.css||""),C.file("element.js",e.js||"")),C.file("selector.txt",`${e.selectorPath}
`);const A=await C.generateAsync({type:"blob"});h(A,`inspect-page-element-${g}-${S}.zip`)}catch{}},[e,l]);return c.jsxs("div",{className:"lpe-debug","aria-label":N.debugHeader,children:[c.jsxs("div",{className:"lpe-debug-header",children:[c.jsx("span",{className:"lpe-debug-title",children:N.debugHeader}),c.jsx("button",{type:"button",className:"lpe-header-btn",onClick:o,"aria-label":N.debugClear,children:"✕"})]}),c.jsxs("div",{className:"lpe-debug-selector",title:e.selectorPath,children:[c.jsxs("span",{className:"lpe-telemetry-label",children:[N.debugSelector,": "]}),c.jsx("code",{children:e.selectorPath})]}),c.jsx("div",{className:"lpe-debug-tabs",role:"tablist",children:["html","css","js"].map(g=>c.jsxs("button",{type:"button",role:"tab","aria-selected":i===g,className:`lpe-debug-tab${i===g?" is-active":""}`,onClick:()=>a(g),children:[g==="html"?N.debugTabHtml:g==="css"?N.debugTabCss:N.debugTabJs,c.jsx("span",{className:"lpe-debug-count",children:e[g].length})]},g))}),c.jsxs("div",{className:"lpe-debug-actions",children:[c.jsxs("span",{className:"lpe-debug-fmt",role:"group","aria-label":N.debugFormatLabel,children:[c.jsxs("span",{children:[N.debugFormatLabel,":"]}),c.jsx("button",{type:"button",className:"lpe-debug-fmt-btn","aria-pressed":l==="raw",onClick:()=>s("raw"),children:N.debugFormatRaw}),c.jsx("button",{type:"button",className:"lpe-debug-fmt-btn","aria-pressed":l==="md",onClick:()=>s("md"),children:N.debugFormatMd})]}),c.jsx("span",{className:"lpe-spacer"}),c.jsx("button",{type:"button",className:"lpe-btn",onClick:y,children:N.debugCopy}),c.jsx("button",{type:"button",className:"lpe-btn",onClick:p,children:N.debugDownloadCurrent}),c.jsx("button",{type:"button",className:"lpe-btn lpe-btn-primary",onClick:d,children:N.debugDownloadAll})]}),i==="js"&&c.jsx("div",{className:"lpe-debug-note",children:N.debugJsEmpty}),c.jsx("pre",{className:"lpe-debug-pre",children:c.jsx("code",{children:u||"(empty)"})}),c.jsx(as,{artifacts:gs(e,t),shareEnabled:n,onShare:r})]})}function Vg(e){if(!e)return"page";try{return new URL(e).hostname.replace(/^www\./,"")}catch{return"page"}}function gs(e,t){return{flow:co.Element,domain:Vg(t),html:e.html||"",css:e.css||"",js:e.js||"",images:[],meta:{}}}function Gg({artifacts:e,activeUrl:t,shareEnabled:n,onShare:r}){const[o,i]=G.useState("raw"),a=()=>{try{return new URL(e.meta.url).hostname.replace(/^www\./,"").replace(/[^a-z0-9_-]+/gi,"_")}catch{return"page"}},l=()=>new Date().toISOString().replace(/[:.]/g,"-").slice(0,19),s=(v,p)=>{const d=document.createElement("a");d.href=URL.createObjectURL(v),d.download=p,d.click(),setTimeout(()=>URL.revokeObjectURL(d.href),1e3)},u=async v=>(await fetch(v)).blob(),y=v=>v==="js"?"javascript":v,x=v=>`# Page — ${e.meta.url}

## ${v.toUpperCase()}

\`\`\`${y(v)}
${e[v]||""}
\`\`\`
`,w=()=>`# Page — ${e.meta.url}

_Captured ${e.meta.capturedAtIso}_

## HTML

\`\`\`html
${e.html}
\`\`\`

## CSS

\`\`\`css
${e.css}
\`\`\`

## JS

\`\`\`javascript
${e.js}
\`\`\`
`,h=G.useCallback(v=>{const p=a(),d=l();if(o==="md")s(new Blob([x(v)],{type:"text/markdown;charset=utf-8"}),`inspect-page-fullpage-${p}-${v}-${d}.md`);else{const g=v==="html"?"text/html":v==="css"?"text/css":"text/javascript";s(new Blob([e[v]||""],{type:`${g};charset=utf-8`}),`inspect-page-fullpage-${p}-${d}.${v}`)}},[e,o]),b=G.useCallback(async()=>{try{const v=await u(e.screenshotDataUrl),p=v.type.includes("jpeg")?"jpg":"png";s(v,`inspect-page-fullpage-${a()}-${l()}.${p}`)}catch{}},[e]),f=G.useCallback(async()=>{try{const v=a(),p=l(),d=new Fi;o==="md"?d.file("page.md",w()):(d.file("page.html",e.html),d.file("styles.css",e.css),d.file("scripts.js",e.js));try{const S=await u(e.screenshotDataUrl),C=S.type.includes("jpeg")?"jpg":"png";d.file(`screenshot.${C}`,S)}catch{}d.file("manifest.json",`${JSON.stringify(e.meta,null,2)}
`);const g=await d.generateAsync({type:"blob"});s(g,`inspect-page-fullpage-${v}-${p}.zip`)}catch{}},[e,o]);return c.jsxs("div",{className:"lpe-debug","aria-label":N.fullPageActionsHeader,children:[c.jsx("div",{className:"lpe-debug-header",children:c.jsx("span",{className:"lpe-debug-title",children:N.fullPageActionsHeader})}),c.jsxs("div",{className:"lpe-debug-actions",children:[c.jsxs("span",{className:"lpe-debug-fmt",role:"group","aria-label":N.debugFormatLabel,children:[c.jsxs("span",{children:[N.debugFormatLabel,":"]}),c.jsx("button",{type:"button",className:"lpe-debug-fmt-btn","aria-pressed":o==="raw",onClick:()=>i("raw"),children:N.debugFormatRaw}),c.jsx("button",{type:"button",className:"lpe-debug-fmt-btn","aria-pressed":o==="md",onClick:()=>i("md"),children:N.debugFormatMd})]}),c.jsx("span",{className:"lpe-spacer"}),c.jsx("button",{type:"button",className:"lpe-btn",onClick:()=>h("html"),children:N.fullPageDownloadHtml}),c.jsx("button",{type:"button",className:"lpe-btn",onClick:()=>h("css"),children:N.fullPageDownloadCss}),c.jsx("button",{type:"button",className:"lpe-btn",onClick:()=>h("js"),children:N.fullPageDownloadJs}),c.jsx("button",{type:"button",className:"lpe-btn",onClick:b,children:N.fullPageDownloadScreenshot}),c.jsx("button",{type:"button",className:"lpe-btn lpe-btn-primary",onClick:f,children:N.fullPageDownloadAllZip})]}),c.jsx(as,{artifacts:xd(e,t),shareEnabled:n,onShare:r})]})}function xd(e,t){const n=t||e.meta.url||"";let r="page";try{r=new URL(n).hostname.replace(/^www\./,"")}catch{}let o="image/png",i="";const a=/^data:([^;]+);base64,(.*)$/.exec(e.screenshotDataUrl||"");a&&a[1]&&a[2]!==void 0&&(o=a[1],i=a[2]);const l=o.includes("jpeg")?"jpg":"png";return{flow:co.FullPage,domain:r,html:e.html,css:e.css,js:e.js,images:i?[{name:`screenshot.${l}`,mime:o,base64:i}]:[],meta:e.meta}}function Zg({settings:e,onPatch:t}){const[n,r]=G.useState(""),[o,i]=G.useState(!1),[a,l]=G.useState(""),[s,u]=G.useState(null),[y,x]=G.useState([]),[w,h]=G.useState(void 0),f=!1;return y.find(v=>v.id===w)??y[0],G.useEffect(()=>{},[f]),G.useEffect(()=>{{x([]),h(void 0);return}},[f]),c.jsxs("details",{className:"lpe-settings",open:!0,children:[c.jsx("summary",{children:N.shareSettingsHeader}),c.jsxs("div",{className:"lpe-settings-body",children:[c.jsx("div",{className:"lpe-debug-note",role:"status",children:N.shareNotConfiguredMsg}),a&&c.jsx("div",{className:"lpe-debug-note",children:a}),n&&c.jsx("div",{className:"lpe-debug-note",role:"alert",children:n}),c.jsx("div",{className:"lpe-debug-note",children:N.shareHelp}),f,f]})]})}function Yg({result:e,onClose:t}){const n=G.useMemo(()=>{const g=Date.parse(e.expiresAt);return Number.isFinite(g)?g:Date.now()},[e.expiresAt]),[r,o]=G.useState(()=>Date.now());G.useEffect(()=>{const g=window.setInterval(()=>o(Date.now()),1e3);return()=>window.clearInterval(g)},[]);const i=Math.max(0,n-r),a=i===0,[l,s]=G.useState(!1),[u,y]=G.useState(!1),[x,w]=G.useState(""),[h,b]=G.useState(""),f=G.useMemo(()=>Kp({htmlRef:e.urls.html,cssRef:e.urls.css,jsRef:e.urls.js,imageRef:e.urls.image}),[e]),v=G.useCallback(async(g,S)=>{try{await navigator.clipboard.writeText(g),b(S)}catch{}window.setTimeout(()=>b(C=>C===S?"":C),1500)},[]),p=G.useCallback(async()=>{s(!0),w("");try{await Me(xe.RevokeShareSession,{sessionId:e.sessionId}),y(!0)}catch(g){w(g instanceof Error?g.message:String(g))}finally{s(!1)}},[e.sessionId]),d=[{key:"html",label:N.shareLblHtml},{key:"css",label:N.shareLblCss},{key:"js",label:N.shareLblJs},{key:"image",label:N.shareLblImage}];return c.jsx("div",{className:"lpe-modal-overlay",role:"dialog","aria-modal":"true","aria-label":N.shareDialogHeader,children:c.jsxs("div",{className:"lpe-modal",children:[c.jsxs("div",{className:"lpe-modal-header",children:[c.jsx("span",{className:"lpe-debug-title",children:N.shareDialogHeader}),c.jsx("button",{type:"button",className:"lpe-header-btn",onClick:t,"aria-label":N.shareCloseBtn,children:"✕"})]}),c.jsxs("div",{className:"lpe-modal-body",children:[c.jsx("div",{className:"lpe-debug-note",style:{background:"transparent"},children:N.shareDialogIntro}),c.jsx("div",{className:"lpe-share-countdown","data-expired":a?"true":"false",children:a?N.shareExpiredMsg:`${N.shareExpiresInPrefix} ${Qg(i)}`}),u&&c.jsx("div",{className:"lpe-debug-note",role:"status",children:N.shareRevokedMsg}),c.jsx("ul",{className:"lpe-share-urls",children:d.map(({key:g,label:S})=>c.jsxs("li",{className:"lpe-share-url-row",children:[c.jsx("span",{className:"lpe-share-url-label",children:S}),c.jsx("input",{className:"lpe-input lpe-share-url-input",readOnly:!0,value:e.urls[g],onFocus:C=>C.currentTarget.select()}),c.jsx("button",{type:"button",className:"lpe-btn",onClick:()=>v(e.urls[g],g),disabled:u||a,children:h===g?N.shareCopyOneDone:N.shareCopyOne})]},g))}),c.jsxs("div",{className:"lpe-row",style:{marginTop:10},children:[c.jsx("button",{type:"button",className:"lpe-btn lpe-btn-primary",onClick:()=>v(f,"all"),disabled:u||a,children:h==="all"?N.shareCopyAllDone:N.shareCopyAll}),c.jsx("button",{type:"button",className:"lpe-btn",onClick:p,disabled:l||u||a,children:l?N.shareRevokingMsg:N.shareRevokeBtn}),c.jsx("button",{type:"button",className:"lpe-btn",onClick:t,children:N.shareCloseBtn})]}),x&&c.jsx("div",{className:"lpe-debug-note",role:"alert",children:x})]})]})})}function Qg(e){const t=Math.floor(e/1e3),n=Math.floor(t/3600),r=Math.floor(t%3600/60),o=t%60,i=a=>a.toString().padStart(2,"0");return n>0?`${n}h ${i(r)}m ${i(o)}s`:`${r}m ${i(o)}s`}function Xg({snapshot:e,onBack:t,preview:n,activeUrl:r,shareEnabled:o,onShare:i}){const[a,l]=G.useState(!1),s=n?gs(n,r):null;return c.jsxs(c.Fragment,{children:[c.jsx(Ag,{snapshot:e,onBack:t,onShowCode:()=>l(!0)}),a&&c.jsx(Rg,{snapshot:e,onClose:()=>l(!1)}),s&&c.jsx("div",{className:"lpe-eli-export",children:c.jsx(as,{artifacts:s,shareEnabled:o,onShare:i})})]})}function vd(e){const{shareSettings:t,hasArtifacts:n,busy:r,artifacts:o,onShare:i,onSignIn:a}=e;return!!t&&!!t.nonce&&!!t.siteUrl?c.jsxs("button",{type:"button",className:"lpe-btn lpe-btn-hero lpe-btn-secondary",onClick:()=>{o&&i(o)},disabled:r||!n||!o,title:n?N.exportModeShare:"Run export first",children:[c.jsxs("svg",{className:"lpe-btn-ico",viewBox:"0 0 20 20",fill:"none","aria-hidden":"true",children:[c.jsx("path",{d:"M13 7V5.5A1.5 1.5 0 0 0 11.5 4h-6A1.5 1.5 0 0 0 4 5.5v9A1.5 1.5 0 0 0 5.5 16h6a1.5 1.5 0 0 0 1.5-1.5V13",stroke:"currentColor",strokeWidth:"1.6",strokeLinecap:"round"}),c.jsx("path",{d:"M8 10h9m0 0-3-3m3 3-3 3",stroke:"currentColor",strokeWidth:"1.6",strokeLinecap:"round",strokeLinejoin:"round"})]}),c.jsx("span",{children:N.exportModeShare})]}):c.jsxs("button",{type:"button",className:"lpe-btn lpe-btn-hero lpe-btn-secondary",onClick:a,disabled:r,title:N.shareSignInBtn,children:[c.jsxs("svg",{className:"lpe-btn-ico",viewBox:"0 0 20 20",fill:"none","aria-hidden":"true",children:[c.jsx("path",{d:"M11 4h4a1.5 1.5 0 0 1 1.5 1.5v9A1.5 1.5 0 0 1 15 16h-4",stroke:"currentColor",strokeWidth:"1.6",strokeLinecap:"round"}),c.jsx("path",{d:"M3 10h9m0 0-3-3m3 3-3 3",stroke:"currentColor",strokeWidth:"1.6",strokeLinecap:"round",strokeLinejoin:"round"})]}),c.jsxs("span",{children:[N.shareSignInBtn," — ",N.exportModeShare]})]})}const Kg=`/**
 * Inline CSS for <ExportPanel/>. Used by both popup (global) and floating
 * panel (Shadow DOM, injected at mount time). All selectors scoped to .lpe-*.
 * Source: spec/21-app/02-ui-panel.md.
 */
:host, .lpe-root {
  all: initial;
  display: block;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
  font-size: 13px;
  line-height: 1.45;
  color: var(--lpe-fg, #1f2328);
}
.lpe-root * { box-sizing: border-box; }
.lpe-root {
  width: 360px;
  background: var(--lpe-bg, #ffffff);
  border: 1px solid var(--lpe-border, #d0d7de);
  border-radius: 8px;
  box-shadow: 0 6px 24px rgba(0,0,0,0.12);
  overflow: hidden;
  position: relative;
}
/* Popup surface uses the full practical MV3 footprint so Settings / Inspect
   overlays have enough width and vertical reading room. */
.lpe-root[data-lpe-surface="popup"] {
  width: 600px;
  height: 600px;
  min-height: 600px;
  border: none;
  border-radius: 0;
  box-shadow: none;
  background: var(--ext-bg, #F5F7F6);
  display: flex;
  flex-direction: column;
}
.lpe-root[data-lpe-surface="floating"] {
  width: 100%;
  height: 100%;
  min-width: 0;
  min-height: 0;
  display: flex;
  flex-direction: column;
}

/* ---------- Theme tokens (Phase A1) ---------- */
.lpe-root[data-lpe-theme="light"],
.lpe-root[data-lpe-theme="dark"] {
  /* Blueprint light-mint theme (extension v2.6.3) */
  --ext-bg: #F5F7F6;
  --ext-card: #FFFFFF;
  --ext-fg: #111714;
  --ext-muted: #5B6B66;
  --ext-border: #E4ECE9;
  --ext-mint: #2DD4A8;
  --ext-mint-hover: #1FB892;
  --ext-mint-soft: rgba(45, 212, 168, 0.14);
  --ext-mint-fg: #06241C;
  --ext-shadow-card: 0 12px 28px -16px rgba(17, 23, 20, 0.18);
  --ext-shadow-glow: 0 0 0 3px rgba(45, 212, 168, 0.25);

  /* Legacy token aliases — keep existing components working */
  --lpe-bg: var(--ext-bg);
  --lpe-fg: var(--ext-fg);
  --lpe-muted: var(--ext-muted);
  --lpe-surface: var(--ext-card);
  --lpe-surface-2: #F0F4F2;
  --lpe-border: var(--ext-border);
  --lpe-accent: var(--ext-mint);
  --lpe-accent-hover: var(--ext-mint-hover);
  --lpe-accent-fg: #FFFFFF;
  --lpe-accent-glow: 0 0 0 1px rgba(45, 212, 168, 0.35), 0 8px 24px -8px rgba(45, 212, 168, 0.45);
}

/* ---------- Tabs (Phase A1) ---------- */
.lpe-tabs {
  display: flex;
  background: var(--lpe-surface);
  border-bottom: 1px solid var(--lpe-border);
}
.lpe-tab {
  flex: 1;
  padding: 8px 10px;
  border: none;
  background: transparent;
  font: inherit;
  color: var(--lpe-muted);
  cursor: pointer;
  border-bottom: 2px solid transparent;
}
.lpe-tab:hover { color: var(--lpe-fg); }
.lpe-tab[data-active="true"] {
  color: var(--lpe-fg);
  font-weight: 600;
  border-bottom-color: var(--lpe-accent);
}

/* ---------- Inspect Mode placeholder (Phase A1) ---------- */
.lpe-inspect-shell { display: flex; flex-direction: column; gap: 10px; }
.lpe-inspect-empty {
  display: flex; flex-direction: column; gap: 4px;
  padding: 14px; border-radius: 6px;
  background: var(--lpe-surface);
  border: 1px dashed var(--lpe-border);
  color: var(--lpe-muted);
}
.lpe-inspect-empty strong { color: var(--lpe-fg); font-size: 14px; }

/* B2 — Inspect skeleton (paints instantly while the snapshot is collected) */
.lpe-inspect-skeleton {
  display: flex; flex-direction: column; gap: 8px;
  padding: 12px; border-radius: 8px;
  background: var(--lpe-surface);
  border: 1px solid var(--lpe-border);
}
.lpe-inspect-skeleton-label {
  font-size: 11px; letter-spacing: 0.04em; text-transform: uppercase;
  color: var(--lpe-muted); margin-bottom: 4px;
}
.lpe-skel {
  border-radius: 6px;
  background: linear-gradient(90deg, var(--lpe-surface-2) 0%, var(--lpe-border) 50%, var(--lpe-surface-2) 100%);
  background-size: 200% 100%;
  animation: lpe-skel-shimmer 1.2s ease-in-out infinite;
}
.lpe-skel-block { height: 56px; }
.lpe-skel-line  { height: 12px; }
@keyframes lpe-skel-shimmer {
  0%   { background-position: 200% 0; }
  100% { background-position: -200% 0; }
}
@media (prefers-reduced-motion: reduce) {
  .lpe-skel { animation: none; }
}

/* ---------- Overview (Phase A3) ---------- */
.lpe-overview { display: flex; flex-direction: column; gap: 10px; }
.lpe-overview-header { display: flex; align-items: center; }
.lpe-overview-title {
  margin: 0; font-size: 12px; font-weight: 600; letter-spacing: 0.04em;
  text-transform: uppercase; color: var(--lpe-muted);
}
.lpe-overview-hero {
  border: 1px solid var(--lpe-border); border-radius: 6px;
  background: var(--lpe-surface); overflow: hidden;
}
.lpe-overview-hero-empty { aspect-ratio: 16 / 9; }
.lpe-overview-thumb {
  display: block; width: 100%; height: auto; max-height: 180px; object-fit: cover;
}
.lpe-overview-meta { display: flex; flex-direction: column; gap: 2px; min-width: 0; }
.lpe-overview-page-title {
  font-weight: 600; color: var(--lpe-fg);
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.lpe-overview-url {
  color: var(--lpe-accent); text-decoration: none; font-size: 12px;
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.lpe-overview-url:hover { text-decoration: underline; }

/* ---------- Shared section header (A4+) ---------- */
.lpe-section-header {
  display: flex; align-items: center; justify-content: space-between; gap: 8px;
}
.lpe-section-title {
  margin: 0; font-size: 12px; font-weight: 600; letter-spacing: 0.04em;
  text-transform: uppercase; color: var(--lpe-muted);
}
.lpe-link {
  border: none; background: transparent; cursor: pointer;
  color: var(--lpe-accent); font: inherit; padding: 2px 4px; border-radius: 4px;
}
.lpe-link:hover { background: var(--lpe-surface-2); }

/* ---------- Typography (Phase A4) ---------- */
.lpe-typo { display: flex; flex-direction: column; gap: 8px; }
.lpe-typo-grid {
  display: grid; grid-template-columns: 1fr 1fr; gap: 8px;
}
.lpe-typo-card {
  display: flex; flex-direction: column; gap: 4px;
  padding: 10px; border: 1px solid var(--lpe-border); border-radius: 6px;
  background: var(--lpe-surface); min-width: 0;
}
.lpe-typo-card-empty { opacity: 0.6; }
.lpe-typo-card-label {
  font-size: 11px; font-weight: 600; letter-spacing: 0.04em;
  text-transform: uppercase; color: var(--lpe-muted);
}
.lpe-typo-card-family {
  font-size: 16px; font-weight: 600; color: var(--lpe-fg);
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.lpe-typo-chip {
  display: inline-block; align-self: flex-start;
  padding: 1px 6px; border-radius: 999px; font-size: 11px;
  background: var(--lpe-surface-2); color: var(--lpe-muted);
  border: 1px solid var(--lpe-border);
}
.lpe-typo-meta { font-size: 11px; color: var(--lpe-muted); }

/* ---------- Modal (Phase A4+) ---------- */
.lpe-modal-backdrop {
  position: fixed; inset: 0; background: rgba(0,0,0,0.4);
  display: flex; align-items: center; justify-content: center; z-index: 2147483646;
}
.lpe-modal {
  width: min(420px, 90vw); max-height: 80vh; display: flex; flex-direction: column;
  background: var(--lpe-bg); color: var(--lpe-fg);
  border: 1px solid var(--lpe-border); border-radius: 8px; overflow: hidden;
  box-shadow: 0 12px 40px rgba(0,0,0,0.3);
}
.lpe-modal-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 8px 12px; background: var(--lpe-surface);
  border-bottom: 1px solid var(--lpe-border);
}
.lpe-modal-header h3 { margin: 0; font-size: 13px; }
.lpe-modal-body { padding: 8px 12px; overflow-y: auto; display: flex; flex-direction: column; gap: 6px; }
.lpe-typo-row {
  display: grid; grid-template-columns: 60px 1fr auto auto; gap: 8px;
  align-items: center; padding: 6px 0; border-bottom: 1px solid var(--lpe-border);
}
.lpe-typo-row:last-child { border-bottom: none; }
.lpe-typo-row-group {
  font-size: 10px; text-transform: uppercase; color: var(--lpe-muted); letter-spacing: 0.05em;
}
.lpe-typo-row-family {
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis; font-weight: 600;
}

/* ---------- Subtabs (A5+) ---------- */
.lpe-subtabs {
  display: inline-flex; gap: 2px; padding: 2px;
  background: var(--lpe-surface-2); border-radius: 6px;
  align-self: flex-start;
}
.lpe-subtab {
  border: none; background: transparent; cursor: pointer;
  padding: 4px 10px; font: inherit; font-size: 12px;
  color: var(--lpe-muted); border-radius: 4px;
}
.lpe-subtab[data-active="true"] {
  background: var(--lpe-bg); color: var(--lpe-fg);
  box-shadow: 0 1px 2px rgba(0,0,0,0.06);
}

/* ---------- Colors · Palette (Phase A5) ---------- */
.lpe-colors { display: flex; flex-direction: column; gap: 8px; }
.lpe-color-grid {
  display: flex; flex-direction: column; gap: 4px;
  border: 1px solid var(--lpe-border); border-radius: 6px;
  background: var(--lpe-surface);
  max-height: 240px; overflow-y: auto;
}
.lpe-color-row {
  display: grid;
  grid-template-columns: 24px 1fr auto auto auto;
  align-items: center; gap: 8px;
  padding: 6px 10px;
  border-bottom: 1px solid var(--lpe-border);
}
.lpe-color-row:last-child { border-bottom: none; }
.lpe-color-swatch {
  display: inline-block; width: 20px; height: 20px;
  border-radius: 4px;
  border: 1px solid rgba(0,0,0,0.15);
}
.lpe-color-swatch.is-transparent {
  background-image:
    linear-gradient(45deg, #ccc 25%, transparent 25%),
    linear-gradient(-45deg, #ccc 25%, transparent 25%),
    linear-gradient(45deg, transparent 75%, #ccc 75%),
    linear-gradient(-45deg, transparent 75%, #ccc 75%);
  background-size: 8px 8px;
  background-position: 0 0, 0 4px, 4px -4px, -4px 0;
  background-color: #fff;
}
.lpe-color-hex {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 12px; color: var(--lpe-fg);
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.lpe-color-instances { font-size: 11px; color: var(--lpe-muted); }
.lpe-color-btn {
  border: 1px solid transparent; background: transparent; cursor: pointer;
  width: 24px; height: 24px; border-radius: 4px;
  color: var(--lpe-muted); font-size: 14px; line-height: 1;
  display: inline-flex; align-items: center; justify-content: center;
}
.lpe-color-btn:hover { background: var(--lpe-surface-2); color: var(--lpe-fg); }

/* ---------- Colors · Categories (Phase A5b) ---------- */
.lpe-color-categories { display: flex; flex-direction: column; gap: 10px; }
.lpe-color-category { display: flex; flex-direction: column; gap: 4px; }
.lpe-color-category-header {
  display: flex; align-items: center; gap: 8px;
  font-size: 11px; font-weight: 600; letter-spacing: 0.04em;
  text-transform: uppercase; color: var(--lpe-muted);
}
.lpe-color-category-count {
  display: inline-flex; align-items: center; justify-content: center;
  min-width: 22px; height: 18px; padding: 0 6px;
  border-radius: 999px; font-size: 11px;
  background: var(--lpe-surface-2); color: var(--lpe-fg);
  border: 1px solid var(--lpe-border);
}

/* ---------- Contrast Scanner (Phase A6) ---------- */
.lpe-contrast { display: flex; flex-direction: column; gap: 8px; }
.lpe-contrast-summary { display: flex; gap: 8px; }
.lpe-contrast-badge {
  display: inline-flex; align-items: center; gap: 4px;
  padding: 2px 8px; border-radius: 999px; font-size: 11px; font-weight: 600;
  border: 1px solid var(--lpe-border);
}
.lpe-contrast-badge-fail { background: rgba(239, 68, 68, 0.12); color: #b91c1c; border-color: rgba(239,68,68,0.4); }
.lpe-contrast-badge-pass { background: rgba(34, 197, 94, 0.12); color: #15803d; border-color: rgba(34,197,94,0.4); }
.lpe-root[data-lpe-theme="dark"] .lpe-contrast-badge-fail { background: rgba(239, 68, 68, 0.18); color: #f87171; border-color: rgba(239,68,68,0.35); }
.lpe-root[data-lpe-theme="dark"] .lpe-contrast-badge-pass { background: rgba(34, 197, 94, 0.18); color: #4ade80; border-color: rgba(34,197,94,0.35); }

.lpe-modal-wide { width: min(520px, 95vw); }

.lpe-pair-card {
  border: 1px solid var(--lpe-border); border-radius: 6px;
  background: var(--lpe-surface);
  padding: 8px; display: flex; flex-direction: column; gap: 8px;
}
.lpe-pair-head { display: flex; align-items: center; gap: 10px; }
.lpe-pair-preview {
  width: 40px; height: 40px; border-radius: 6px;
  display: flex; align-items: center; justify-content: center;
  font-weight: 700; font-size: 18px; border: 1px solid var(--lpe-border);
}
.lpe-pair-stats { flex: 1; display: flex; flex-direction: column; gap: 1px; min-width: 0; }
.lpe-pair-ratio { font-size: 16px; font-weight: 700; color: var(--lpe-fg); }
.lpe-pair-verdict { font-size: 11px; }
.lpe-pair-verdict-fail { color: #b91c1c; }
.lpe-pair-verdict-poor { color: #b45309; }
.lpe-pair-verdict-good { color: #15803d; }
.lpe-pair-verdict-excellent { color: #047857; }
.lpe-root[data-lpe-theme="dark"] .lpe-pair-verdict-fail { color: #f87171; }
.lpe-root[data-lpe-theme="dark"] .lpe-pair-verdict-poor { color: #fbbf24; }
.lpe-root[data-lpe-theme="dark"] .lpe-pair-verdict-good { color: #4ade80; }
.lpe-root[data-lpe-theme="dark"] .lpe-pair-verdict-excellent { color: #34d399; }
.lpe-pair-instances { font-size: 11px; color: var(--lpe-muted); }

.lpe-pair-details { display: flex; flex-direction: column; gap: 8px; padding-top: 4px; border-top: 1px solid var(--lpe-border); }
.lpe-pair-swatches { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
.lpe-pair-swatch { display: flex; flex-direction: column; gap: 4px; }
.lpe-pair-swatch-label {
  font-size: 10px; text-transform: uppercase; color: var(--lpe-muted); letter-spacing: 0.05em;
}
.lpe-pair-swatch-row { display: flex; align-items: center; gap: 6px; }

.lpe-aa-grid {
  width: 100%; border-collapse: collapse; font-size: 12px;
}
.lpe-aa-grid th, .lpe-aa-grid td {
  padding: 4px 6px; text-align: center; border: 1px solid var(--lpe-border);
}
.lpe-aa-grid th[scope="row"] { text-align: left; color: var(--lpe-muted); font-weight: 600; }
.lpe-aa-pill {
  display: inline-block; padding: 1px 8px; border-radius: 999px;
  font-size: 11px; font-weight: 600;
}
.lpe-aa-pill.is-pass { background: rgba(34,197,94,0.15); color: #15803d; }
.lpe-aa-pill.is-fail { background: rgba(239,68,68,0.15); color: #b91c1c; }
.lpe-root[data-lpe-theme="dark"] .lpe-aa-pill.is-pass { background: rgba(34,197,94,0.22); color: #4ade80; }
.lpe-root[data-lpe-theme="dark"] .lpe-aa-pill.is-fail { background: rgba(239,68,68,0.22); color: #f87171; }

.lpe-header {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 10px;
  background: var(--lpe-surface);
  border-bottom: 1px solid var(--lpe-border);
  cursor: default;
  user-select: none;
}
.lpe-header[data-draggable="true"] { cursor: move; }
.lpe-header-title { flex: 1; font-weight: 600; }
.lpe-header-btn {
  border: none; background: transparent; cursor: pointer;
  padding: 2px 6px; border-radius: 4px; font-size: 14px;
  color: var(--lpe-fg);
}
.lpe-header-btn:hover { background: var(--lpe-surface-2); }
.lpe-body {
  padding: 12px;
  display: flex; flex-direction: column; gap: 10px;
  /* Phase A1: scrollable body fix — keep the panel from overflowing the page */
  max-height: 70vh;
  overflow-y: auto;
  overscroll-behavior: contain;
}
.lpe-root[data-lpe-surface="popup"] .lpe-body {
  flex: 1;
  min-height: 0;
  max-height: none;
  overflow-y: auto;
}
.lpe-root[data-lpe-surface="floating"] .lpe-body {
  flex: 1;
  min-height: 0;
  max-height: none;
  overflow-y: auto;
}
.lpe-btn {
  display: block; width: 100%;
  padding: 8px 12px;
  border: 1px solid var(--lpe-border);
  border-radius: 10px;
  background: var(--lpe-surface);
  font: inherit;
  cursor: pointer;
  color: var(--lpe-fg);
  transition: background 120ms ease, border-color 120ms ease, box-shadow 120ms ease, transform 80ms ease;
}
.lpe-btn:hover:not([disabled]) {
  background: var(--lpe-surface-2);
  border-color: rgba(45, 212, 168, 0.35);
}
.lpe-btn-primary {
  background: linear-gradient(135deg, #2DD4A8 0%, #73FFB8 100%);
  color: var(--lpe-accent-fg);
  border-color: transparent;
  font-weight: 600;
  box-shadow: var(--lpe-accent-glow);
}
.lpe-btn-primary:hover:not([disabled]) {
  filter: brightness(1.05);
  transform: translateY(-1px);
}
.lpe-btn[disabled] { opacity: 0.55; cursor: not-allowed; }
.lpe-root[data-lpe-theme="dark"] .lpe-btn { background: #161b22; border-color: #30363d; color: #e6edf3; }
.lpe-root[data-lpe-theme="dark"] .lpe-btn:hover:not([disabled]) { background: #1f242c; }
.lpe-root[data-lpe-theme="dark"] .lpe-btn-primary { background: var(--lpe-accent); color: var(--lpe-accent-fg); border-color: var(--lpe-accent); }
.lpe-root[data-lpe-theme="dark"] .lpe-btn-primary:hover:not([disabled]) { background: #1f6feb; }
.lpe-status {
  padding: 8px 10px;
  border: 1px solid var(--lpe-border);
  border-radius: 8px;
  background: var(--lpe-surface);
  min-height: 36px;
  color: var(--lpe-fg);
}
.lpe-status[data-status="Error"] { background: #ffebe9; border-color: #ff8182; color: #1f2328; }
.lpe-status[data-status="Success"] { background: #dafbe1; border-color: #2da44e; color: #1f2328; }
.lpe-root[data-lpe-theme="dark"] .lpe-status { background: #161b22; border-color: #30363d; color: #e6edf3; }
.lpe-root[data-lpe-theme="dark"] .lpe-status[data-status="Error"] { background: #450a0a; border-color: #ef4444; color: #fecaca; }
.lpe-root[data-lpe-theme="dark"] .lpe-status[data-status="Success"] { background: #052e16; border-color: #22c55e; color: #bbf7d0; }
.lpe-progress {
  height: 6px; width: 100%; background: var(--lpe-surface-2); border-radius: 3px; overflow: hidden;
  margin-top: 6px;
}
.lpe-progress-bar { height: 100%; background: linear-gradient(90deg, #2DD4A8, #73FFB8); transition: width 120ms ease; }
.lpe-root[data-lpe-theme="dark"] .lpe-progress { background: #30363d; }
.lpe-root[data-lpe-theme="dark"] .lpe-progress-bar { background: var(--lpe-accent); }
.lpe-row { display: flex; align-items: center; gap: 8px; }
.lpe-settings {
  margin-top: 4px;
  border-top: 1px solid #eaeef2;
  padding-top: 10px;
}
.lpe-settings summary {
  cursor: pointer; font-weight: 600; padding: 6px 2px;
  list-style: none; display: flex; align-items: center; gap: 6px;
  color: var(--lpe-fg); font-size: 13px;
  border-radius: 6px;
}
.lpe-settings summary:hover { background: var(--lpe-surface-2); }
.lpe-settings summary::-webkit-details-marker { display: none; }
.lpe-settings summary::before {
  content: ""; width: 6px; height: 6px;
  border-right: 1.5px solid var(--lpe-muted); border-bottom: 1.5px solid var(--lpe-muted);
  transform: rotate(-45deg); transition: transform 150ms ease;
  margin-left: 4px;
}
.lpe-settings[open] summary::before { transform: rotate(45deg); }
.lpe-root[data-lpe-theme="dark"] .lpe-settings { border-top-color: #30363d; }
.lpe-root[data-lpe-theme="dark"] .lpe-settings summary { color: #e6edf3; }
.lpe-root[data-lpe-theme="dark"] .lpe-settings summary:hover { background: #161b22; }
.lpe-root[data-lpe-theme="dark"] .lpe-settings summary::before { border-color: #8b949e; }
.lpe-settings-body {
  display: flex; flex-direction: column; gap: 12px;
  padding: 10px 2px 4px;
}
.lpe-field { display: flex; flex-direction: column; gap: 5px; }
.lpe-field > label {
  font-size: 11px; font-weight: 500; letter-spacing: 0.02em;
  color: #57606a; text-transform: uppercase;
}
.lpe-field-row {
  display: flex; align-items: center; gap: 10px;
  padding: 8px 10px;
  border: 1px solid #eaeef2; border-radius: 8px;
  background: #fbfcfd;
  cursor: pointer;
  transition: background 120ms ease, border-color 120ms ease;
}
.lpe-field-row:hover { background: #f6f8fa; border-color: #d0d7de; }
.lpe-field-row > span { font-size: 12.5px; color: #1f2328; flex: 1; }
.lpe-field-row input[type="checkbox"] {
  appearance: none; -webkit-appearance: none;
  width: 16px; height: 16px; margin: 0;
  border: 1.5px solid #afb8c1; border-radius: 4px;
  background: white; cursor: pointer; flex-shrink: 0;
  display: inline-grid; place-content: center;
  transition: background 120ms ease, border-color 120ms ease;
}
.lpe-field-row input[type="checkbox"]:hover { border-color: #0969da; }
.lpe-field-row input[type="checkbox"]:checked {
  background: #0969da; border-color: #0969da;
}
.lpe-field-row input[type="checkbox"]:checked::after {
  content: ""; width: 9px; height: 5px;
  border-left: 2px solid white; border-bottom: 2px solid white;
  transform: rotate(-45deg) translate(1px, -1px);
}
.lpe-root[data-lpe-theme="dark"] .lpe-field > label { color: #8b949e; }
.lpe-root[data-lpe-theme="dark"] .lpe-field-row { background: #0d1117; border-color: #30363d; }
.lpe-root[data-lpe-theme="dark"] .lpe-field-row:hover { background: #161b22; border-color: #30363d; }
.lpe-root[data-lpe-theme="dark"] .lpe-field-row > span { color: #e6edf3; }
.lpe-root[data-lpe-theme="dark"] .lpe-field-row input[type="checkbox"] { background: #0d1117; border-color: #30363d; }
.lpe-root[data-lpe-theme="dark"] .lpe-field-row input[type="checkbox"]:hover { border-color: var(--lpe-accent); }
.lpe-root[data-lpe-theme="dark"] .lpe-field-row input[type="checkbox"]:checked { background: var(--lpe-accent); border-color: var(--lpe-accent); }
.lpe-input, .lpe-select {
  width: 100%; padding: 7px 10px;
  border: 1px solid #d0d7de; border-radius: 6px;
  font: inherit; font-size: 12.5px; background: white;
  color: #1f2328;
  transition: border-color 120ms ease, box-shadow 120ms ease;
}
.lpe-input:focus, .lpe-select:focus {
  outline: none; border-color: #0969da;
  box-shadow: 0 0 0 3px rgba(9,105,218,0.15);
}
.lpe-select {
  appearance: none; -webkit-appearance: none;
  background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'><path fill='none' stroke='%2357606a' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round' d='M1 1l4 4 4-4'/></svg>");
  background-repeat: no-repeat;
  background-position: right 10px center;
  padding-right: 28px;
}
.lpe-root[data-lpe-theme="dark"] .lpe-input, .lpe-root[data-lpe-theme="dark"] .lpe-select {
  background-color: #0d1117; border-color: #30363d; color: #e6edf3;
}
.lpe-root[data-lpe-theme="dark"] .lpe-input:focus, .lpe-root[data-lpe-theme="dark"] .lpe-select:focus {
  border-color: var(--lpe-accent);
  box-shadow: 0 0 0 3px rgba(47,129,247,0.25);
}
.lpe-root[data-lpe-theme="dark"] .lpe-select {
  background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='6' viewBox='0 0 10 6'><path fill='none' stroke='%238b949e' stroke-width='1.5' stroke-linecap='round' stroke-linejoin='round' d='M1 1l4 4 4-4'/></svg>");
  background-repeat: no-repeat;
  background-position: right 10px center;
}
.lpe-field input[type="range"] {
  width: 100%; accent-color: #0969da;
}
.lpe-root[data-lpe-theme="dark"] .lpe-field input[type="range"] { accent-color: var(--lpe-accent); }
.lpe-not-available {
  padding: 8px 10px; background: #fff8c5; border: 1px solid #d4a72c;
  border-radius: 6px;
  color: #1f2328;
}
.lpe-root[data-lpe-theme="dark"] .lpe-not-available { background: #422006; border-color: #a16207; color: #fef08a; }
.lpe-error-detail { font-family: ui-monospace, SFMono-Regular, monospace; font-size: 12px; }

/* v1.1 — "Captured in this export" telemetry block. */
.lpe-telemetry {
  margin-top: 8px;
  padding: 6px 8px;
  border: 1px solid #cfead4;
  background: #f6fef8;
  border-radius: 6px;
  font-size: 12px;
}
.lpe-telemetry-header {
  font-weight: 600; color: #1a7f37; margin-bottom: 4px;
}
.lpe-telemetry-list {
  list-style: none; margin: 0; padding: 0;
  display: flex; flex-direction: column; gap: 2px;
}
.lpe-telemetry-row {
  display: flex; justify-content: space-between; gap: 12px;
}
.lpe-telemetry-label { color: #57606a; }
.lpe-telemetry-value {
  font-variant-numeric: tabular-nums; font-weight: 500; color: #1f2328;
}
.lpe-root[data-lpe-theme="dark"] .lpe-telemetry { background: #052e16; border-color: #166534; }
.lpe-root[data-lpe-theme="dark"] .lpe-telemetry-header { color: #4ade80; }
.lpe-root[data-lpe-theme="dark"] .lpe-telemetry-label { color: #8b949e; }
.lpe-root[data-lpe-theme="dark"] .lpe-telemetry-value { color: #e6edf3; }

/* v1.2 — picked-element debug preview (HTML / CSS / JS tabs). */
.lpe-debug {
  margin-top: 4px;
  border: 1px solid #d0d7de;
  border-radius: 6px;
  background: #fbfcfd;
  color: #1f2328;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
.lpe-debug-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 6px 8px;
  background: #f6f8fa;
  border-bottom: 1px solid #d0d7de;
}
.lpe-debug-title { font-weight: 600; font-size: 12px; }
.lpe-debug-selector {
  padding: 4px 8px; font-size: 11px; color: #57606a;
  border-bottom: 1px solid #eaeef2;
  word-break: break-all;
}
.lpe-debug-selector code {
  font-family: ui-monospace, SFMono-Regular, monospace;
  color: #1f2328;
}
.lpe-debug-tabs {
  display: flex; align-items: center; gap: 4px; flex-wrap: wrap;
  padding: 6px 8px;
  border-bottom: 1px solid #eaeef2;
}
.lpe-debug-tab {
  border: 1px solid #d0d7de; background: white;
  padding: 3px 8px; border-radius: 4px;
  cursor: pointer; font: inherit; font-size: 12px;
  display: inline-flex; align-items: center; gap: 4px;
}
.lpe-debug-tab.is-active {
  background: #0969da; color: white; border-color: #0969da;
}
.lpe-root[data-lpe-theme="dark"] .lpe-debug-tab.is-active {
  background: var(--lpe-accent); color: var(--lpe-accent-fg); border-color: var(--lpe-accent);
}
.lpe-debug-count {
  font-size: 10px; opacity: 0.7;
  font-variant-numeric: tabular-nums;
}
.lpe-debug-copy {
  width: auto !important; padding: 3px 10px !important;
  font-size: 12px;
}
.lpe-debug-copy:first-of-type {
  margin-left: auto;
}
.lpe-debug-actions {
  display: flex; flex-wrap: wrap; gap: 6px; align-items: center;
  padding: 6px 8px;
  border-bottom: 1px solid #eaeef2;
  background: #fbfcfd;
}
.lpe-debug-fmt {
  display: inline-flex; align-items: center; gap: 4px;
  font-size: 11px; color: #57606a;
}
.lpe-debug-fmt-btn {
  border: 1px solid #d0d7de; background: white;
  padding: 2px 8px; border-radius: 4px;
  cursor: pointer; font: inherit; font-size: 11px;
}
.lpe-debug-fmt-btn[aria-pressed="true"] {
  background: #0969da; color: white; border-color: #0969da;
}
.lpe-debug-actions .lpe-btn {
  width: auto; padding: 3px 10px; font-size: 12px;
  margin-left: 0;
}
.lpe-debug-actions .lpe-spacer { flex: 1 1 auto; }
.lpe-debug-note {
  padding: 6px 8px; font-size: 11px; color: #57606a;
  background: #fff8c5; border-bottom: 1px solid #eaeef2;
}
.lpe-debug-pre {
  margin: 0; padding: 8px;
  max-height: 240px; overflow: auto;
  font-family: ui-monospace, SFMono-Regular, monospace;
  font-size: 11px; line-height: 1.4;
  background: #ffffff;
  white-space: pre-wrap; word-break: break-word;
}

/* v2.2 — onboarding banner in popup */
.lpe-onboarding {
  margin: 10px 12px 0;
  padding: 10px 12px;
  border: 1px solid #bfdbfe;
  border-radius: 8px;
  background: #eff6ff;
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.lpe-onboarding strong {
  display: block;
  font-size: 13px;
  color: #1e3a8a;
  margin-bottom: 2px;
}
.lpe-onboarding span {
  font-size: 12px;
  color: #1e40af;
}
.lpe-onboarding-actions {
  display: flex;
  gap: 8px;
}
.lpe-onboarding-actions .lpe-btn {
  width: auto;
  flex: 1;
  padding: 6px 10px;
  font-size: 12px;
}
.lpe-root[data-lpe-theme="dark"] .lpe-onboarding { background: #172554; border-color: #3b82f6; }
.lpe-root[data-lpe-theme="dark"] .lpe-onboarding strong { color: #bfdbfe; }
.lpe-root[data-lpe-theme="dark"] .lpe-onboarding span { color: #93c5fd; }

.lpe-export-modes {
  margin-top: 10px;
  padding-top: 10px;
  border-top: 1px dashed #d0d7de;
  color: #1f2328;
}
.lpe-export-modes .lpe-debug-title { margin-bottom: 6px; color: inherit; }
.lpe-root[data-lpe-theme="dark"] .lpe-debug,
.lpe-root[data-lpe-theme="dark"] .lpe-export-modes { color: #e6edf3; }
.lpe-root[data-lpe-theme="dark"] .lpe-debug { background: #0d1117; border-color: #30363d; }
.lpe-root[data-lpe-theme="dark"] .lpe-debug-header { background: #161b22; border-bottom-color: #30363d; }
.lpe-root[data-lpe-theme="dark"] .lpe-debug-actions { background: #0d1117; border-bottom-color: #30363d; }
.lpe-root[data-lpe-theme="dark"] .lpe-debug-pre { background: #010409; color: #e6edf3; }
.lpe-root[data-lpe-theme="dark"] .lpe-debug-tab { background: #0d1117; border-color: #30363d; color: #e6edf3; }
.lpe-root[data-lpe-theme="dark"] .lpe-debug-fmt-btn { background: #0d1117; border-color: #30363d; color: #e6edf3; }
.lpe-root[data-lpe-theme="dark"] .lpe-debug-fmt-btn[aria-pressed="true"] { background: var(--lpe-accent); color: var(--lpe-accent-fg); border-color: var(--lpe-accent); }
.lpe-root[data-lpe-theme="dark"] .lpe-debug-selector { border-bottom-color: #30363d; color: #8b949e; }
.lpe-root[data-lpe-theme="dark"] .lpe-debug-selector code { color: #e6edf3; }


/* ---- Smart Share dialog (v2.2) ---- */
.lpe-modal-overlay {
  position: absolute; inset: 0;
  background: rgba(15, 23, 42, 0.55);
  display: flex; align-items: flex-start; justify-content: center;
  padding: 20px; z-index: 9999;
  overflow: auto;
}
.lpe-modal {
  background: white; border: 1px solid #d0d7de; border-radius: 8px;
  width: 100%; max-width: 520px;
  box-shadow: 0 8px 24px rgba(15, 23, 42, 0.25);
  display: flex; flex-direction: column;
}
.lpe-modal-header {
  display: flex; align-items: center; justify-content: space-between;
  gap: 8px; padding: 8px 10px;
  border-bottom: 1px solid #eaeef2; background: #fbfcfd;
  border-radius: 8px 8px 0 0;
}
.lpe-modal-body { padding: 10px 12px 12px; }
.lpe-share-countdown {
  margin: 6px 0; font-size: 12px; color: #1f2937;
  font-variant-numeric: tabular-nums;
}
.lpe-share-countdown[data-expired="true"] { color: #b42318; font-weight: 600; }
.lpe-share-urls { list-style: none; margin: 8px 0 0; padding: 0; }
.lpe-share-url-row {
  display: flex; align-items: center; gap: 6px; margin-bottom: 6px;
}
.lpe-share-url-label {
  flex: 0 0 48px; font-size: 11px; color: #57606a; font-weight: 600;
}
.lpe-share-url-input {
  flex: 1 1 auto; font-family: ui-monospace, SFMono-Regular, monospace;
  font-size: 11px;
}
.lpe-share-url-row .lpe-btn { width: auto; padding: 3px 10px; font-size: 12px; }
/* (removed duplicate .lpe-link override that was clobbering inspector buttons) */
.lpe-recent-shares { margin-top: 10px; padding-top: 8px; border-top: 1px dashed #d0d7de; }
.lpe-recent-header {
  display: flex; align-items: center; justify-content: space-between;
  margin-bottom: 6px; font-size: 12px;
}
.lpe-recent-header .lpe-btn { width: auto; padding: 2px 8px; font-size: 11px; }
.lpe-recent-list { list-style: none; margin: 0; padding: 0; }
.lpe-recent-row {
  display: flex; align-items: center; gap: 8px;
  padding: 4px 0; border-bottom: 1px solid #f0f3f5; font-size: 11px;
}
.lpe-recent-row:last-child { border-bottom: 0; }
.lpe-recent-meta { flex: 1 1 auto; display: flex; gap: 6px; align-items: baseline; min-width: 0; }
.lpe-recent-host {
  flex: 1 1 auto; color: #1f2937; font-weight: 500;
  overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
}
.lpe-recent-kind { color: #6b7280; font-size: 10px; text-transform: uppercase; }
.lpe-recent-status { color: #2563eb; font-size: 10px; font-weight: 600; }
.lpe-recent-status[data-expired="true"] { color: #b42318; }
.lpe-recent-row .lpe-btn { width: auto; padding: 2px 8px; font-size: 11px; }

/* Smart Share preview thumbnail (Option E) */
.lpe-share-thumb {
  flex: 0 0 auto;
  width: 36px; height: 36px;
  object-fit: cover;
  border-radius: 4px;
  border: 1px solid #e5e7eb;
  background: #f9fafb;
  display: inline-flex; align-items: center; justify-content: center;
  font-size: 12px; font-weight: 600; color: #6b7280; text-transform: uppercase;
}
.lpe-share-thumb-empty { font-style: normal; }

/* Views badge + per-file breakdown (Option A — Phase 4) */
.lpe-views-badge {
  background: #f3f4f6; border: 1px solid #e5e7eb; border-radius: 10px;
  padding: 1px 7px; font-size: 10px; color: #374151; cursor: pointer;
  display: inline-flex; align-items: center; gap: 3px; line-height: 1.4;
}
.lpe-views-badge:hover { background: #e5e7eb; }
.lpe-views-badge[aria-expanded="true"] { background: #dbeafe; border-color: #93c5fd; color: #1e40af; }
.lpe-views-breakdown {
  flex: 1 0 100%; display: flex; flex-wrap: wrap; gap: 8px;
  margin-top: 4px; padding: 6px 8px; background: #f9fafb;
  border: 1px solid #e5e7eb; border-radius: 4px; font-size: 10px; color: #4b5563;
}
.lpe-views-breakdown b { color: #111827; font-weight: 600; }
.lpe-views-last { margin-left: auto; color: #6b7280; font-style: italic; }

/* ---------- CSS Information (Phase A7) ---------- */
.lpe-cssinfo { display: flex; flex-direction: column; gap: 8px; }
.lpe-cssinfo-grid {
  display: grid; grid-template-columns: 1fr 1fr; gap: 8px;
}
.lpe-cssinfo-stat {
  display: flex; flex-direction: column; gap: 2px;
  padding: 10px; border: 1px solid var(--lpe-border); border-radius: 6px;
  background: var(--lpe-surface); min-width: 0;
}
.lpe-cssinfo-stat-value {
  font-size: 18px; font-weight: 600; color: var(--lpe-fg);
  font-variant-numeric: tabular-nums;
}
.lpe-cssinfo-stat-label {
  font-size: 11px; color: var(--lpe-muted);
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.lpe-cssinfo-warn {
  display: flex; flex-direction: column; gap: 2px;
  padding: 8px 10px; border: 1px solid var(--lpe-border); border-radius: 6px;
  background: var(--lpe-surface-2);
  font-size: 11px; color: var(--lpe-muted);
}
.lpe-cssinfo-warn strong { color: var(--lpe-fg); font-size: 12px; }

/* ---------- Element Inspector (Phase A8) ---------- */
.lpe-inspector { display: flex; flex-direction: column; gap: 8px; }
.lpe-inspector-hint { margin: 0; font-size: 11px; color: var(--lpe-muted); }
.lpe-inspector-list {
  list-style: none; margin: 0; padding: 0;
  display: flex; flex-direction: column;
  border: 1px solid var(--lpe-border); border-radius: 6px;
  background: var(--lpe-surface);
  overflow: hidden;
}
.lpe-inspector-item { border-bottom: 1px solid var(--lpe-border); }
.lpe-inspector-item:last-child { border-bottom: none; }
.lpe-inspector-row {
  display: grid;
  grid-template-columns: auto 1fr auto 14px;
  align-items: center; gap: 8px;
  width: 100%; padding: 6px 10px;
  border: none; background: transparent; cursor: pointer;
  font: inherit; text-align: left; color: var(--lpe-fg);
}
.lpe-inspector-row:hover { background: var(--lpe-surface-2); }
.lpe-inspector-tag {
  display: inline-flex; align-items: center;
  padding: 1px 6px; border-radius: 4px;
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 10px; text-transform: uppercase;
  background: var(--lpe-surface-2); color: var(--lpe-muted);
  border: 1px solid var(--lpe-border);
}
.lpe-inspector-selector {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 12px; color: var(--lpe-fg);
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis; min-width: 0;
}
.lpe-inspector-dims {
  font-size: 11px; color: var(--lpe-muted);
  font-variant-numeric: tabular-nums;
}
.lpe-inspector-caret { font-size: 10px; color: var(--lpe-muted); }
.lpe-inspector-detail {
  padding: 8px 10px 10px; background: var(--lpe-surface-2);
  display: flex; flex-direction: column; gap: 6px;
}
.lpe-inspector-styles { margin: 0; display: flex; flex-direction: column; gap: 2px; }
.lpe-inspector-style-row {
  display: grid; grid-template-columns: 110px 1fr; gap: 8px;
  font-size: 11px; min-width: 0;
}
.lpe-inspector-style-row dt {
  margin: 0; color: var(--lpe-muted);
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
}
.lpe-inspector-style-row dd {
  margin: 0; color: var(--lpe-fg);
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis; min-width: 0;
}
.lpe-inspector-actions {
  display: flex; flex-wrap: wrap; gap: 6px;
  margin-top: 4px; padding-top: 6px;
  border-top: 1px solid var(--lpe-border);
}
.lpe-inspector-actions .lpe-link {
  border: 1px solid var(--lpe-border);
  background: var(--lpe-bg);
  color: var(--lpe-fg);
  padding: 4px 10px;
  border-radius: 4px;
  font-size: 11px;
  text-decoration: none;
  font-weight: 500;
}
.lpe-inspector-actions .lpe-link:hover {
  background: var(--lpe-surface);
  border-color: var(--lpe-accent);
  color: var(--lpe-accent);
}

/* ---------- Distance guides (Phase A8b) ---------- */
.lpe-inspector-row.is-anchor {
  background: color-mix(in srgb, var(--lpe-accent) 10%, transparent);
}
.lpe-inspector-anchor-banner {
  display: flex; align-items: center; justify-content: space-between; gap: 8px;
  padding: 6px 10px; border: 1px dashed var(--lpe-border); border-radius: 6px;
  background: var(--lpe-surface);
  font-size: 11px; color: var(--lpe-fg);
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
}
.lpe-inspector-anchor-banner > span {
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis; min-width: 0;
}
.lpe-inspector-dist {
  margin-top: 2px; padding: 6px 8px; border-radius: 4px;
  background: var(--lpe-bg); border: 1px solid var(--lpe-border);
  display: flex; flex-direction: column; gap: 4px;
}
.lpe-inspector-dist-title {
  font-size: 10px; text-transform: uppercase; letter-spacing: 0.05em;
  color: var(--lpe-muted); font-weight: 600;
}
.lpe-inspector-dist-grid {
  margin: 0; display: grid; grid-template-columns: 1fr 1fr; gap: 2px 12px;
}
.lpe-inspector-dist-row {
  display: grid; grid-template-columns: 1fr auto; gap: 8px;
  font-size: 11px; font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
}
.lpe-inspector-dist-row dt { margin: 0; color: var(--lpe-muted); }
.lpe-inspector-dist-row dd { margin: 0; color: var(--lpe-fg); font-variant-numeric: tabular-nums; }
.lpe-inspector-dist-chip {
  align-self: flex-start; font-size: 10px;
  padding: 1px 6px; border-radius: 999px;
  background: color-mix(in srgb, var(--lpe-accent) 15%, transparent);
  color: var(--lpe-accent); border: 1px solid var(--lpe-border);
}
.lpe-inspector-dist-self {
  margin: 0; font-size: 11px; color: var(--lpe-muted); font-style: italic;
}

/* ---------- Show Code drawer (Phase A9) ---------- */
.lpe-modal-code { width: min(560px, 92vw); max-height: 80vh; }
.lpe-modal-code-selector {
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  color: var(--lpe-muted); font-weight: 400;
}
.lpe-modal-code-pre {
  margin: 0; padding: 10px;
  background: var(--lpe-surface-2);
  border: 1px solid var(--lpe-border); border-radius: 6px;
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  font-size: 12px; color: var(--lpe-fg);
  white-space: pre-wrap; word-break: break-word;
  overflow-y: auto; max-height: 50vh;
}
.lpe-modal-code-footer {
  display: flex; align-items: flex-start; gap: 8px;
}
.lpe-modal-code-note {
  flex: 1; font-size: 11px; color: var(--lpe-muted);
}

/* ---------- Detail drawer (Phase A10) ---------- */
.lpe-modal-detail { width: min(440px, 92vw); }
.lpe-detail-body { gap: 10px; }
.lpe-detail-swatch {
  width: 100%; height: 80px; border-radius: 6px;
  border: 1px solid var(--lpe-border);
}
.lpe-detail-swatch.is-transparent {
  background-image:
    linear-gradient(45deg, #ccc 25%, transparent 25%),
    linear-gradient(-45deg, #ccc 25%, transparent 25%),
    linear-gradient(45deg, transparent 75%, #ccc 75%),
    linear-gradient(-45deg, transparent 75%, #ccc 75%);
  background-size: 16px 16px;
  background-position: 0 0, 0 8px, 8px -8px, -8px 0;
  background-color: #fff;
}
.lpe-detail-grid { margin: 0; display: flex; flex-direction: column; gap: 4px; }
.lpe-detail-row {
  display: grid; grid-template-columns: 80px 1fr auto; gap: 8px;
  align-items: center;
  padding: 4px 0; border-bottom: 1px solid var(--lpe-border);
  font-size: 12px;
}
.lpe-detail-row:last-child { border-bottom: none; }
.lpe-detail-row dt { margin: 0; color: var(--lpe-muted); }
.lpe-detail-row dd {
  margin: 0; color: var(--lpe-fg);
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis; min-width: 0;
}
.lpe-color-hex-btn {
  border: none; background: transparent; padding: 0; cursor: pointer;
  font: inherit; text-align: left; color: var(--lpe-fg);
}
.lpe-color-hex-btn:hover { text-decoration: underline; }
.lpe-color-swatch[role="button"], button.lpe-color-swatch { cursor: pointer; padding: 0; }

/* ---------- Export menu (Phase A11) ---------- */
.lpe-inspect-shell-header {
  display: flex; justify-content: flex-end; align-items: center;
}
.lpe-export-menu { position: relative; }
.lpe-export-menu-pop {
  position: absolute; top: 100%; right: 0; z-index: 10;
  margin: 4px 0 0; padding: 4px;
  list-style: none;
  min-width: 180px;
  background: var(--lpe-bg);
  border: 1px solid var(--lpe-border); border-radius: 6px;
  box-shadow: 0 8px 24px rgba(0,0,0,0.18);
  display: flex; flex-direction: column; gap: 2px;
}
.lpe-export-menu-item {
  width: 100%; text-align: left;
  border: none; background: transparent; cursor: pointer;
  padding: 6px 10px; border-radius: 4px;
  font: inherit; font-size: 12px; color: var(--lpe-fg);
}
.lpe-export-menu-item:hover { background: var(--lpe-surface-2); }

/* ---------- Resize handle (Phase A12) ---------- */
.lpe-resize-handle {
  position: absolute;
  right: 0; bottom: 0;
  width: 14px; height: 14px;
  cursor: nwse-resize;
  background:
    linear-gradient(135deg, transparent 0 50%, var(--lpe-muted) 50% 60%, transparent 60% 70%, var(--lpe-muted) 70% 80%, transparent 80% 100%);
  opacity: 0.6;
}
.lpe-resize-handle:hover { opacity: 1; }
/* When the wrapper has explicit width/height (drag/resize set), let
   .lpe-root fill it instead of falling back to its 360px default. */
.lpe-root { position: relative; max-width: 100%; max-height: 100%; }

/* ---------- Footer (Phase A13) ---------- */
.lpe-inspect-footer {
  display: flex; align-items: center; justify-content: center;
  padding: 8px 10px;
  font-size: 11px; color: var(--lpe-muted);
  border-top: 1px solid var(--lpe-border);
  margin-top: 2px;
}

/* ---------- Free quota progress bar ---------- */
.lpe-quota-bar {
  margin-top: 6px;
  width: 100%;
  height: 6px;
  background: var(--lpe-surface-2);
  border-radius: 999px;
  overflow: hidden;
}
.lpe-quota-bar-fill {
  height: 100%;
  border-radius: inherit;
  transition: width 200ms ease;
  background: var(--lpe-accent, #3b82f6);
}
.lpe-quota-bar-fill[data-state="warning"] { background: #d97706; }
.lpe-quota-bar-fill[data-state="exhausted"] { background: #dc2626; }
.lpe-root[data-lpe-theme="dark"] .lpe-quota-bar-fill[data-state="warning"] { background: #f59e0b; }
.lpe-root[data-lpe-theme="dark"] .lpe-quota-bar-fill[data-state="exhausted"] { background: #ef4444; }

/* ============ C3 — Pick Element Inspector ============ */
.lpe-eli {
  border: 1px solid var(--lpe-border);
  border-radius: 8px;
  background: var(--lpe-surface);
  padding: 10px 12px;
  display: flex; flex-direction: column; gap: 12px;
}
.lpe-eli-header { display: flex; align-items: center; gap: 8px; }
.lpe-eli-title { font-weight: 600; font-size: 14px; }
.lpe-eli-show-code { padding: 4px 10px; }

.lpe-eli-identity { display: flex; flex-direction: column; gap: 2px; }
.lpe-eli-label { font-size: 12px; color: var(--lpe-muted); }
.lpe-eli-selector { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 16px; font-weight: 700; }
.lpe-eli-tag { color: #a78bfa; }
.lpe-root[data-lpe-theme="light"] .lpe-eli-tag { color: #7c3aed; }
.lpe-eli-class { color: var(--lpe-fg); }

.lpe-eli-toggle { display: flex; align-items: center; gap: 8px; font-size: 13px; cursor: pointer; }
.lpe-eli-toggle input { width: 14px; height: 14px; }

.lpe-eli-section { display: flex; flex-direction: column; gap: 6px; }
.lpe-eli-h4 { margin: 0 0 4px 0; font-size: 13px; font-weight: 700; }

.lpe-eli-row { display: grid; grid-template-columns: 110px 1fr; gap: 8px; align-items: center; font-size: 12px; }
.lpe-eli-rowlabel { color: var(--lpe-muted); }
.lpe-eli-rowvalue { display: flex; align-items: center; gap: 6px; min-width: 0; }
.lpe-eli-rowvalue.is-mono { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; }
.lpe-eli-rowtext { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.lpe-eli-swatch { width: 14px; height: 14px; border-radius: 3px; border: 1px solid var(--lpe-border); flex: 0 0 auto; }
.lpe-eli-copy {
  background: none; border: 1px solid var(--lpe-border); border-radius: 4px;
  color: var(--lpe-muted); cursor: pointer; padding: 0 6px; font-size: 12px; line-height: 18px;
}
.lpe-eli-copy:hover { color: var(--lpe-fg); }

/* ---- Box-model diagram ---- */
.lpe-bm { display: flex; justify-content: center; padding: 4px 0; }
.lpe-bm-margin, .lpe-bm-border, .lpe-bm-padding {
  position: relative; padding: 22px 36px;
  border-radius: 8px;
}
.lpe-bm-margin  { background: rgba(255,165,0,0.10); border: 1px dashed rgba(255,165,0,0.55); }
.lpe-bm-border  { background: rgba(255,255,255,0.04); border: 1px solid var(--lpe-border); }
.lpe-bm-padding { background: rgba(60,200,140,0.10); border: 1px dashed rgba(60,200,140,0.6); }
.lpe-bm-content {
  background: var(--lpe-fg); color: var(--lpe-bg);
  padding: 8px 14px; border-radius: 4px;
  font: 12px ui-monospace, SFMono-Regular, Menlo, monospace;
  text-align: center; min-width: 80px;
}
.lpe-bm-tag {
  position: absolute; top: 4px; left: 8px;
  font-size: 10px; color: var(--lpe-muted); text-transform: lowercase;
}
.lpe-bm-tl, .lpe-bm-tr, .lpe-bm-bl, .lpe-bm-br {
  position: absolute; font-size: 10px; color: var(--lpe-muted);
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
}
.lpe-bm-tl { top: 4px; right: 8px; left: auto; }
.lpe-bm-tr { top: 50%; right: 4px; transform: translateY(-50%); }
.lpe-bm-br { bottom: 4px; right: 8px; }
.lpe-bm-bl { top: 50%; left: 4px; transform: translateY(-50%); }
/* override .tag corner — keep tag top-left, numbers go top-center / etc */
.lpe-bm-margin > .lpe-bm-tl,
.lpe-bm-border > .lpe-bm-tl,
.lpe-bm-padding > .lpe-bm-tl { top: 4px; left: 50%; right: auto; transform: translateX(-50%); }
.lpe-bm-margin > .lpe-bm-br,
.lpe-bm-border > .lpe-bm-br,
.lpe-bm-padding > .lpe-bm-br { bottom: 4px; left: 50%; right: auto; transform: translateX(-50%); }

/* ---- C4: Selection colors + contrast ---- */
.lpe-eli-sample {
  display: inline-flex; align-items: center; justify-content: center;
  min-width: 28px; height: 22px; padding: 0 6px;
  border: 1px solid var(--lpe-border); border-radius: 4px;
  font-weight: 700; font-size: 13px;
}
.lpe-eli-verdict {
  font-size: 11px; font-weight: 600; padding: 1px 6px; border-radius: 999px;
  border: 1px solid var(--lpe-border);
}
.lpe-eli-verdict.is-excellent { color: #16a34a; border-color: rgba(22,163,74,0.5); background: rgba(22,163,74,0.10); }
.lpe-eli-verdict.is-good      { color: #65a30d; border-color: rgba(101,163,13,0.5); background: rgba(101,163,13,0.10); }
.lpe-eli-verdict.is-poor      { color: #d97706; border-color: rgba(217,119,6,0.5); background: rgba(217,119,6,0.10); }
.lpe-eli-verdict.is-fail      { color: #dc2626; border-color: rgba(220,38,38,0.5); background: rgba(220,38,38,0.10); }
.lpe-eli-wcag {
  display: flex; align-items: center; gap: 6px; margin-top: 2px;
  padding-left: 118px; font-size: 11px;
}
.lpe-eli-wcag-note { color: var(--lpe-muted); margin-left: 4px; }
.lpe-eli-tagpill {
  font-size: 11px; font-weight: 700; padding: 1px 6px; border-radius: 4px;
  border: 1px solid var(--lpe-border);
}
.lpe-eli-tagpill.is-pass { color: #16a34a; border-color: rgba(22,163,74,0.5); background: rgba(22,163,74,0.10); }
.lpe-eli-tagpill.is-fail { color: #dc2626; border-color: rgba(220,38,38,0.5); background: rgba(220,38,38,0.10); }

/* ---- C5: Code drawer ---- */
.lpe-cdr {
  display: flex; flex-direction: column; gap: 10px;
  background: var(--lpe-surface, rgba(255,255,255,0.03));
  border: 1px solid var(--lpe-border);
  border-radius: 10px; padding: 10px;
}
.lpe-cdr-header { display: flex; align-items: center; gap: 8px; }
.lpe-cdr-title { font-weight: 600; font-size: 14px; }
.lpe-cdr-section { display: flex; flex-direction: column; gap: 6px; }
.lpe-cdr-tabs { display: flex; align-items: center; gap: 4px; flex-wrap: wrap; }
.lpe-cdr-tab {
  font-size: 11px; text-transform: capitalize; padding: 3px 8px;
  border-radius: 4px; border: 1px solid var(--lpe-border);
  background: transparent; color: var(--lpe-muted); cursor: pointer;
}
.lpe-cdr-tab.is-active {
  background: var(--lpe-fg); color: var(--lpe-bg); border-color: var(--lpe-fg);
}
.lpe-cdr-copy {
  font-size: 11px; padding: 3px 8px; border-radius: 4px;
  border: 1px solid var(--lpe-border); background: transparent;
  color: var(--lpe-fg); cursor: pointer;
}
.lpe-cdr-pre {
  margin: 0; padding: 8px 10px;
  background: rgba(0,0,0,0.35);
  border: 1px solid var(--lpe-border); border-radius: 6px;
  font: 11px/1.45 ui-monospace, SFMono-Regular, Menlo, monospace;
  color: var(--lpe-fg);
  max-height: 240px; overflow: auto; white-space: pre;
}
.lpe-root[data-lpe-theme="light"] .lpe-cdr-pre { background: rgba(0,0,0,0.04); }

/* C6: inspector-docked export modes */
.lpe-eli-export { margin-top: 8px; }

/* Phase 2 — Settings popover anchored under header */
.lpe-settings-popover {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  z-index: 10;
  background: #ffffff;
  border-top: 1px solid #d0d7de;
  box-shadow: 0 -4px 24px rgba(0,0,0,0.18);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
.lpe-root[data-lpe-theme="dark"] .lpe-settings-popover {
  background: #161b22;
  border-top-color: #30363d;
  box-shadow: 0 12px 32px rgba(0,0,0,0.6);
}
.lpe-settings-popover-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  min-height: 58px;
  padding: 10px 16px;
  border-bottom: 1px solid #d0d7de;
  font-size: 18px;
  flex-shrink: 0;
}
.lpe-root[data-lpe-theme="dark"] .lpe-settings-popover-head {
  border-bottom-color: #30363d;
  color: #e6edf3;
}
.lpe-settings-popover-body {
  padding: 18px 22px 28px;
  flex: 1;
  min-height: 0;
  overflow-y: auto;
  overscroll-behavior: contain;
}
.lpe-settings-popover .lpe-settings { border-top: none; }
.lpe-settings-popover .lpe-settings summary { display: none; }
.lpe-settings-popover .lpe-settings-body { gap: 16px; padding-top: 10px; }
.lpe-settings-popover .lpe-field { gap: 8px; }
.lpe-settings-popover .lpe-field > label { font-size: 13px; font-weight: 700; letter-spacing: 0.08em; }
.lpe-settings-popover .lpe-input,
.lpe-settings-popover .lpe-select {
  min-height: 52px;
  padding: 12px 16px;
  font-size: 18px;
  border-radius: 10px;
}
.lpe-settings-popover .lpe-select { padding-right: 42px; background-position: right 16px center; }
.lpe-settings-popover .lpe-field-row {
  min-height: 52px;
  padding: 12px 16px;
  border-radius: 10px;
}
.lpe-settings-popover .lpe-field-row > span { font-size: 15px; }
.lpe-settings-popover .lpe-field-row input[type="checkbox"] { width: 22px; height: 22px; }

/* Phase 5 — palette refresh: route hardcoded surfaces through tokens + add depth */
.lpe-root { box-shadow: 0 10px 30px rgba(0,0,0,0.18); border-radius: 10px; }
.lpe-root[data-lpe-theme="dark"] { box-shadow: 0 14px 40px rgba(0,0,0,0.55); }

.lpe-btn {
  border-radius: 10px;
  transition: background 150ms ease, border-color 150ms ease, transform 80ms ease;
}
.lpe-btn:active:not([disabled]) { transform: translateY(1px); }
.lpe-btn-primary { box-shadow: 0 1px 0 rgba(255,255,255,0.18) inset, 0 6px 16px rgba(37, 99, 235, 0.28); }
.lpe-root[data-lpe-theme="dark"] .lpe-btn-primary { box-shadow: 0 1px 0 rgba(255,255,255,0.10) inset, 0 6px 16px rgba(59,130,246,0.35); }
.lpe-btn-primary:hover:not([disabled]) { background: var(--lpe-accent-hover) !important; border-color: var(--lpe-accent-hover) !important; }

/* Tabs polish — active tab gets 2px accent underline + soft glow */
.lpe-tab[data-active="true"] {
  position: relative;
  color: var(--lpe-fg);
}
.lpe-tab[data-active="true"]::after {
  content: "";
  position: absolute;
  left: 12%; right: 12%; bottom: 0;
  height: 2px;
  background: var(--lpe-accent);
  border-radius: 2px;
  box-shadow: 0 0 8px var(--lpe-accent);
}

/* Header */
.lpe-header { background: var(--lpe-surface); border-bottom: 1px solid var(--lpe-border); }
.lpe-header-btn { color: var(--lpe-muted); border-radius: 8px; transition: background 120ms ease, color 120ms ease; }
.lpe-header-btn:hover { background: var(--lpe-surface-2); color: var(--lpe-fg); }

/* Settings popover — re-skin to tokens */
.lpe-settings-popover { background: var(--lpe-surface); border-color: var(--lpe-border); }
.lpe-root[data-lpe-theme="dark"] .lpe-settings-popover { background: var(--lpe-surface); border-color: var(--lpe-border); }
.lpe-settings-popover-head { border-bottom-color: var(--lpe-border); color: var(--lpe-fg); background: var(--lpe-surface-2); }

/* Phase 3 — Billing plan panel */
.lpe-billing-panel {
  display: flex;
  flex-direction: column;
  gap: 4px;
  padding: 8px 10px;
  border-radius: 8px;
  background: var(--lpe-surface);
  border: 1px solid var(--lpe-border);
}
.lpe-billing-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}
.lpe-billing-label {
  color: var(--lpe-muted);
  font-size: 12px;
}
.lpe-billing-badge {
  display: inline-block;
  padding: 2px 8px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 600;
  background: var(--lpe-surface-2);
  color: var(--lpe-fg);
  border: 1px solid var(--lpe-border);
}
.lpe-billing-badge[data-plan="pro"] {
  background: var(--lpe-accent);
  color: #fff;
  border-color: var(--lpe-accent);
}
.lpe-billing-sub {
  font-size: 11px;
  color: var(--lpe-muted);
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
}
.lpe-billing-tagline {
  font-size: 11px;
  color: var(--lpe-muted);
}
/* 2.6.0 — Pricing card feature bullets + post-checkout success toast. */
.lpe-billing-features {
  margin: 4px 0 0;
  padding: 0 0 0 16px;
  font-size: 11px;
  color: var(--lpe-fg);
  line-height: 1.5;
}
.lpe-billing-features li { margin: 0; padding: 0; }
.lpe-billing-toast {
  margin-top: 6px;
  padding: 6px 10px;
  border-radius: 6px;
  background: var(--lpe-accent);
  color: #fff;
  font-size: 12px;
  font-weight: 600;
  animation: lpe-billing-toast-in 200ms ease-out;
}
@keyframes lpe-billing-toast-in {
  from { opacity: 0; transform: translateY(-4px); }
  to   { opacity: 1; transform: translateY(0); }
}
@media (prefers-reduced-motion: reduce) {
  .lpe-billing-toast { animation: none; }
}

/* Phase A8b — Locate toast (color match feedback) */
.lpe-locate-toast {
  position: sticky;
  bottom: 8px;
  margin: 8px auto 0;
  align-self: center;
  max-width: 90%;
  padding: 6px 12px;
  border-radius: 999px;
  background: rgba(20, 20, 20, 0.92);
  color: #fff;
  font-size: 12px;
  text-align: center;
  pointer-events: none;
  box-shadow: 0 6px 20px rgba(0, 0, 0, 0.35);
}

/* ============================================================
   Blueprint primitives (extension v2.6.3)
   Reusable surface/card/button/chip classes that mirror the
   wireframe-style reference (light surface, white cards, soft
   mint fills, full-pill CTAs, decorative floating circles).
   ============================================================ */

.lpe-surface { background: var(--ext-bg); }

.lpe-card {
  background: var(--ext-card);
  border: 1px solid var(--ext-border);
  border-radius: 18px;
  box-shadow: var(--ext-shadow-card);
  padding: 18px;
  position: relative;
}
.lpe-card + .lpe-card { margin-top: 12px; }

.lpe-pill-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  width: 100%;
  min-height: 44px;
  padding: 0 20px;
  border: none;
  border-radius: 999px;
  background: var(--ext-mint);
  color: #FFFFFF;
  font: inherit;
  font-weight: 600;
  cursor: pointer;
  transition: background .15s ease, box-shadow .15s ease, transform .05s ease;
}
.lpe-pill-btn:hover { background: var(--ext-mint-hover); }
.lpe-pill-btn:active { transform: translateY(1px); }
.lpe-pill-btn:focus-visible { outline: none; box-shadow: var(--ext-shadow-glow); }
.lpe-pill-btn:disabled { opacity: .55; cursor: not-allowed; }

.lpe-pill-btn--ghost {
  background: transparent;
  color: var(--ext-mint);
  border: 1.5px solid var(--ext-mint);
}
.lpe-pill-btn--ghost:hover { background: var(--ext-mint-soft); }

.lpe-chip {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  height: 22px;
  padding: 0 10px;
  border-radius: 999px;
  background: var(--ext-mint-soft);
  color: var(--ext-fg);
  font-size: 12px;
  font-weight: 600;
  line-height: 1;
  white-space: nowrap;
}
.lpe-chip--solid { background: var(--ext-mint); color: #FFFFFF; }

.lpe-input {
  width: 100%;
  height: 40px;
  padding: 0 14px;
  background: var(--ext-card);
  border: 1px solid var(--ext-border);
  border-radius: 12px;
  font: inherit;
  color: var(--ext-fg);
  transition: border-color .15s ease, box-shadow .15s ease;
}
.lpe-input:focus { outline: none; border-color: var(--ext-mint); border-width: 2px; padding: 0 13px; }

.lpe-thumb {
  width: 36px;
  height: 36px;
  border-radius: 10px;
  background: var(--ext-mint-soft);
  border: 1px solid var(--ext-border);
  display: inline-flex;
  align-items: center;
  justify-content: center;
  overflow: hidden;
  flex-shrink: 0;
}
.lpe-thumb img { width: 100%; height: 100%; object-fit: cover; }

/* Decorative floating circles — purely visual, never interactive. */
.lpe-decor {
  position: absolute;
  border-radius: 50%;
  background: var(--ext-mint);
  pointer-events: none;
  z-index: 0;
}
.lpe-decor--xs { width: 12px;  height: 12px;  opacity: 0.85; }
.lpe-decor--sm { width: 28px;  height: 28px;  opacity: 0.70; }
.lpe-decor--md { width: 64px;  height: 64px;  opacity: 0.18; }
.lpe-decor--lg { width: 120px; height: 120px; opacity: 0.10; }

/* ============================================================
   Blueprint repaint — popup surface (extension v2.6.3 / Phase B)
   CSS-only overrides scoped to the popup. Re-skins the existing
   .lpe-btn/.lpe-header/.lpe-status/.lpe-typo-card/.lpe-progress
   to match the wireframe-blueprint reference (white cards, soft
   shadows, pill CTAs, mint-soft fills) — no JSX changes.
   ============================================================ */
.lpe-root[data-lpe-surface="popup"] {
  color: var(--ext-fg);
}

/* Decorative floating circles (top-right cluster + bottom-left) */
.lpe-root[data-lpe-surface="popup"]::before,
.lpe-root[data-lpe-surface="popup"]::after {
  content: "";
  position: absolute;
  border-radius: 50%;
  background: var(--ext-mint);
  pointer-events: none;
  z-index: 0;
}
.lpe-root[data-lpe-surface="popup"]::before {
  top: -36px; right: -28px;
  width: 120px; height: 120px;
  opacity: 0.10;
}
.lpe-root[data-lpe-surface="popup"]::after {
  bottom: -40px; left: -32px;
  width: 100px; height: 100px;
  opacity: 0.08;
}

/* Push real content above the decoration */
.lpe-root[data-lpe-surface="popup"] > * { position: relative; z-index: 1; }

/* Header → flat white strip with mint brand dot */
.lpe-root[data-lpe-surface="popup"] .lpe-header {
  background: var(--ext-card);
  border-bottom: 1px solid var(--ext-border);
  padding: 12px 16px;
  gap: 10px;
}
.lpe-root[data-lpe-surface="popup"] .lpe-header-title {
  color: var(--ext-fg);
  font-weight: 700;
  letter-spacing: -0.005em;
}
.lpe-root[data-lpe-surface="popup"] .lpe-header-title::before {
  content: "";
  display: inline-block;
  width: 10px; height: 10px;
  border-radius: 50%;
  background: var(--ext-mint);
  margin-right: 8px;
  vertical-align: middle;
  box-shadow: 0 0 0 4px var(--ext-mint-soft);
}
.lpe-root[data-lpe-surface="popup"] .lpe-header-btn {
  color: var(--ext-muted);
  border-radius: 999px;
  width: 32px; height: 32px;
  display: inline-flex; align-items: center; justify-content: center;
}
.lpe-root[data-lpe-surface="popup"] .lpe-header-btn:hover {
  background: var(--ext-mint-soft);
  color: var(--ext-fg);
}

/* Tabs → soft pill row */
.lpe-root[data-lpe-surface="popup"] .lpe-tabs {
  background: var(--ext-card);
  border-bottom: 1px solid var(--ext-border);
  padding: 6px 12px;
  gap: 4px;
}
.lpe-root[data-lpe-surface="popup"] .lpe-tab {
  border-radius: 999px;
  border-bottom: none;
  padding: 8px 14px;
  font-weight: 600;
  color: var(--ext-muted);
}
.lpe-root[data-lpe-surface="popup"] .lpe-tab:hover { background: var(--ext-mint-soft); color: var(--ext-fg); }
.lpe-root[data-lpe-surface="popup"] .lpe-tab[aria-selected="true"],
.lpe-root[data-lpe-surface="popup"] .lpe-tab.is-active {
  background: var(--ext-mint);
  color: #FFFFFF;
}

/* Body → padded gutter on the blueprint canvas */
.lpe-root[data-lpe-surface="popup"] .lpe-body {
  padding: 16px;
  gap: 14px;
  background: var(--ext-bg);
}

/* Primary buttons → mint pill */
.lpe-root[data-lpe-surface="popup"] .lpe-btn {
  background: var(--ext-card);
  border: 1px solid var(--ext-border);
  color: var(--ext-fg);
  border-radius: 999px;
  padding: 10px 18px;
  font-weight: 600;
  box-shadow: none;
}
.lpe-root[data-lpe-surface="popup"] .lpe-btn:hover:not([disabled]) {
  background: var(--ext-mint-soft);
  border-color: var(--ext-mint);
}
.lpe-root[data-lpe-surface="popup"] .lpe-btn-primary {
  background: var(--ext-mint);
  color: #FFFFFF;
  border-color: var(--ext-mint);
  box-shadow: 0 6px 16px -8px rgba(45, 212, 168, 0.55);
}
.lpe-root[data-lpe-surface="popup"] .lpe-btn-primary:hover:not([disabled]) {
  background: var(--ext-mint-hover);
  border-color: var(--ext-mint-hover);
  filter: none;
  transform: translateY(-1px);
}

/* Status panel → soft white card */
.lpe-root[data-lpe-surface="popup"] .lpe-status {
  background: var(--ext-card);
  border: 1px solid var(--ext-border);
  border-radius: 14px;
  padding: 12px 14px;
}
.lpe-root[data-lpe-surface="popup"] .lpe-status[data-status="Success"] {
  background: var(--ext-mint-soft);
  border-color: var(--ext-mint);
  color: var(--ext-fg);
}

/* Progress bar → mint pill */
.lpe-root[data-lpe-surface="popup"] .lpe-progress {
  background: var(--ext-mint-soft);
  border-radius: 999px;
  height: 6px;
}
.lpe-root[data-lpe-surface="popup"] .lpe-progress-bar {
  background: var(--ext-mint);
}

/* Inline cards (typography preview, contrast cards, etc.) → white card */
.lpe-root[data-lpe-surface="popup"] .lpe-typo-card {
  background: var(--ext-card);
  border: 1px solid var(--ext-border);
  border-radius: 14px;
  padding: 12px;
  box-shadow: 0 8px 22px -18px rgba(17, 23, 20, 0.18);
}
.lpe-root[data-lpe-surface="popup"] .lpe-typo-chip {
  background: var(--ext-mint-soft);
  color: var(--ext-fg);
  border: none;
}

/* Section title — uppercase muted label, blueprint style */
.lpe-root[data-lpe-surface="popup"] .lpe-section-title {
  color: var(--ext-muted);
  font-size: 11px;
  letter-spacing: 0.08em;
}

/* Settings disclosure */
.lpe-root[data-lpe-surface="popup"] .lpe-settings {
  border-top: 1px solid var(--ext-border);
}
.lpe-root[data-lpe-surface="popup"] .lpe-settings summary {
  color: var(--ext-fg);
  border-radius: 12px;
  padding: 10px 12px;
}
.lpe-root[data-lpe-surface="popup"] .lpe-settings summary:hover {
  background: var(--ext-mint-soft);
}

/* ============================================================
   Blueprint repaint — inspect + element sub-panels (Phase C/D)
   Scoped to \`.lpe-root\` so both popup and floating surface
   pick it up. White cards, soft mint-tinted accents, pill
   subtabs, rounded modals/drawers.
   ============================================================ */

/* Subtabs → pill row */
.lpe-root .lpe-subtabs {
  display: flex; gap: 4px;
  background: var(--ext-mint-soft);
  padding: 4px;
  border-radius: 999px;
}
.lpe-root .lpe-subtab {
  flex: 1;
  border: none; background: transparent;
  font: inherit; font-weight: 600;
  padding: 6px 12px; border-radius: 999px;
  color: var(--ext-muted); cursor: pointer;
}
.lpe-root .lpe-subtab:hover { color: var(--ext-fg); }
.lpe-root .lpe-subtab[aria-selected="true"],
.lpe-root .lpe-subtab.is-active {
  background: var(--ext-card);
  color: var(--ext-fg);
  box-shadow: 0 2px 6px -2px rgba(17,23,20,0.18);
}

/* Generic "card-y" inspect blocks */
.lpe-root .lpe-overview-hero,
.lpe-root .lpe-color-category,
.lpe-root .lpe-color-row,
.lpe-root .lpe-pair-card,
.lpe-root .lpe-cssinfo-stat,
.lpe-root .lpe-detail-row,
.lpe-root .lpe-eli-section,
.lpe-root .lpe-inspector-item,
.lpe-root .lpe-inspector-detail,
.lpe-root .lpe-inspector-styles,
.lpe-root .lpe-cdr-section {
  background: var(--ext-card);
  border: 1px solid var(--ext-border);
  border-radius: 14px;
  padding: 12px;
}

/* Overview thumb → mint-soft frame */
.lpe-root .lpe-overview-thumb,
.lpe-root .lpe-overview-hero-empty {
  background: var(--ext-mint-soft);
  border-radius: 12px;
  border: 1px solid var(--ext-border);
  overflow: hidden;
}

/* Color swatches keep their actual color but get a hairline border */
.lpe-root .lpe-color-swatch,
.lpe-root .lpe-detail-swatch,
.lpe-root .lpe-pair-swatch,
.lpe-root .lpe-eli-swatch {
  border: 1px solid var(--ext-border);
  border-radius: 8px;
}

/* AA pills + contrast badges → mint chips */
.lpe-root .lpe-aa-pill,
.lpe-root .lpe-contrast-badge {
  background: var(--ext-mint-soft);
  color: var(--ext-fg);
  border: none;
  border-radius: 999px;
  padding: 2px 10px;
  font-size: 11px;
  font-weight: 600;
}
.lpe-root .lpe-aa-pill.is-pass,
.lpe-root .lpe-contrast-badge-pass {
  background: var(--ext-mint);
  color: #FFFFFF;
}
.lpe-root .lpe-aa-pill.is-fail,
.lpe-root .lpe-contrast-badge-fail {
  background: rgba(239, 68, 68, 0.16);
  color: #b1271b;
}

/* Modals + drawers → white rounded panels */
.lpe-root .lpe-modal-backdrop {
  background: rgba(17, 23, 20, 0.45);
  backdrop-filter: blur(2px);
}
.lpe-root .lpe-modal {
  background: var(--ext-card);
  border: 1px solid var(--ext-border);
  border-radius: 18px;
  box-shadow: 0 24px 56px -28px rgba(17, 23, 20, 0.45);
  overflow: hidden;
}
.lpe-root .lpe-modal-header {
  background: var(--ext-card);
  border-bottom: 1px solid var(--ext-border);
  padding: 12px 16px;
}
.lpe-root .lpe-modal-body { padding: 14px 16px; background: var(--ext-bg); }

/* Code drawer (cdr) */
.lpe-root .lpe-cdr {
  background: var(--ext-card);
  border: 1px solid var(--ext-border);
  border-radius: 18px;
  overflow: hidden;
}
.lpe-root .lpe-cdr-header {
  background: var(--ext-mint-soft);
  border-bottom: 1px solid var(--ext-border);
  padding: 10px 14px;
}
.lpe-root .lpe-cdr-title { color: var(--ext-fg); font-weight: 700; }
.lpe-root .lpe-cdr-tabs { gap: 4px; padding: 8px 12px; background: var(--ext-card); }
.lpe-root .lpe-cdr-tab {
  border: none; background: transparent;
  padding: 6px 12px; border-radius: 999px;
  font: inherit; font-weight: 600; color: var(--ext-muted);
  cursor: pointer;
}
.lpe-root .lpe-cdr-tab[aria-selected="true"],
.lpe-root .lpe-cdr-tab.is-active {
  background: var(--ext-mint); color: #FFFFFF;
}
.lpe-root .lpe-cdr-pre,
.lpe-root .lpe-modal-code-pre {
  background: #F7FAF9;
  border: 1px solid var(--ext-border);
  border-radius: 12px;
  padding: 12px;
  color: var(--ext-fg);
  font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
}
.lpe-root .lpe-cdr-copy { border-radius: 999px; }

/* Element inspector */
.lpe-root .lpe-eli-tagpill {
  background: var(--ext-mint-soft);
  color: var(--ext-fg);
  border-radius: 999px;
  padding: 2px 10px;
  font-weight: 700;
}
.lpe-root .lpe-eli-show-code,
.lpe-root .lpe-eli-copy {
  border-radius: 999px;
}

/* Box model preview */
.lpe-root .lpe-bm {
  background: var(--ext-card);
  border: 1px solid var(--ext-border);
  border-radius: 14px;
  padding: 12px;
}
.lpe-root .lpe-bm-margin { background: rgba(45, 212, 168, 0.08); border-radius: 10px; }
.lpe-root .lpe-bm-border { background: rgba(45, 212, 168, 0.16); border-radius: 8px; }
.lpe-root .lpe-bm-padding { background: rgba(45, 212, 168, 0.28); border-radius: 6px; }
.lpe-root .lpe-bm-content { background: var(--ext-mint); color: #FFFFFF; border-radius: 4px; }

/* Inspect shell header */
.lpe-root .lpe-inspect-shell-header {
  background: var(--ext-card);
  border: 1px solid var(--ext-border);
  border-radius: 14px;
  padding: 10px 14px;
}
.lpe-root .lpe-inspect-footer {
  background: var(--ext-card);
  border-top: 1px solid var(--ext-border);
  padding: 10px 14px;
}

/* Skeleton shimmer */
.lpe-root .lpe-skel-block,
.lpe-root .lpe-skel-line {
  background: var(--ext-mint-soft);
  border-radius: 8px;
}

/* Locate toast → mint pill */
.lpe-root .lpe-locate-toast {
  background: var(--ext-fg);
  color: #FFFFFF;
  border-radius: 999px;
  padding: 8px 14px;
  box-shadow: 0 12px 28px -12px rgba(17,23,20,0.5);
}

/* ============================================================
   Blueprint repaint — floating in-page panel (Phase E)
   ============================================================ */
.lpe-root[data-lpe-surface="floating"] {
  background: var(--ext-card);
  border: 1px solid var(--ext-border);
  border-radius: 18px;
  box-shadow: 0 20px 48px -20px rgba(17, 23, 20, 0.35);
  overflow: hidden;
  color: var(--ext-fg);
}

/* Header → white pill strip with mint brand dot + circular controls */
.lpe-root[data-lpe-surface="floating"] .lpe-header {
  background: var(--ext-card);
  border-bottom: 1px solid var(--ext-border);
  padding: 10px 14px;
  gap: 8px;
}
.lpe-root[data-lpe-surface="floating"] .lpe-header-title {
  color: var(--ext-fg);
  font-weight: 700;
}
.lpe-root[data-lpe-surface="floating"] .lpe-header-title::before {
  content: "";
  display: inline-block;
  width: 8px; height: 8px;
  border-radius: 50%;
  background: var(--ext-mint);
  margin-right: 8px;
  vertical-align: middle;
  box-shadow: 0 0 0 3px var(--ext-mint-soft);
}
.lpe-root[data-lpe-surface="floating"] .lpe-header-btn {
  color: var(--ext-muted);
  border-radius: 999px;
  width: 28px; height: 28px;
  display: inline-flex; align-items: center; justify-content: center;
}
.lpe-root[data-lpe-surface="floating"] .lpe-header-btn:hover {
  background: var(--ext-mint-soft);
  color: var(--ext-fg);
}

/* Body uses the page-gutter color so cards float on a soft surface */
.lpe-root[data-lpe-surface="floating"] .lpe-body {
  padding: 14px;
  gap: 12px;
  background: var(--ext-bg);
}

/* Primary + secondary buttons mirror the popup pill treatment */
.lpe-root[data-lpe-surface="floating"] .lpe-btn {
  background: var(--ext-card);
  border: 1px solid var(--ext-border);
  color: var(--ext-fg);
  border-radius: 999px;
  padding: 10px 18px;
  font-weight: 600;
  box-shadow: none;
}
.lpe-root[data-lpe-surface="floating"] .lpe-btn:hover:not([disabled]) {
  background: var(--ext-mint-soft);
  border-color: var(--ext-mint);
}
.lpe-root[data-lpe-surface="floating"] .lpe-btn-primary {
  background: var(--ext-mint);
  color: #FFFFFF;
  border-color: var(--ext-mint);
  box-shadow: 0 6px 16px -8px rgba(45, 212, 168, 0.55);
}
.lpe-root[data-lpe-surface="floating"] .lpe-btn-primary:hover:not([disabled]) {
  background: var(--ext-mint-hover);
  border-color: var(--ext-mint-hover);
  filter: none;
  transform: translateY(-1px);
}

/* Status + progress mirror popup styling */
.lpe-root[data-lpe-surface="floating"] .lpe-status {
  background: var(--ext-card);
  border: 1px solid var(--ext-border);
  border-radius: 14px;
  padding: 12px 14px;
}
.lpe-root[data-lpe-surface="floating"] .lpe-progress {
  background: var(--ext-mint-soft);
  border-radius: 999px;
  height: 6px;
}
.lpe-root[data-lpe-surface="floating"] .lpe-progress-bar { background: var(--ext-mint); }

/* =====================================================================
 * Popup reskin — clean white card, blue accents, segmented tabs, pill
 * groups and section panels (#F9FAFB / #E5E7EB). Scoped to popup surface
 * only; floating panel keeps the Blueprint mint theme.
 * ===================================================================== */
.lpe-root[data-lpe-surface="popup"] {
  /* override token aliases */
  --ext-bg: #FFFFFF;
  --ext-card: #FFFFFF;
  --ext-fg: #1F2937;
  --ext-muted: #6B7280;
  --ext-border: #E5E7EB;
  --ext-mint: #2563EB;
  --ext-mint-hover: #1D4ED8;
  --ext-mint-soft: #EFF6FF;
  --ext-mint-fg: #1E3A8A;
  --ext-shadow-card: 0 1px 2px rgba(17, 24, 39, 0.04);
  --ext-shadow-glow: 0 0 0 3px rgba(37, 99, 235, 0.18);
  --lpe-bg: #FFFFFF;
  --lpe-fg: #1F2937;
  --lpe-muted: #6B7280;
  --lpe-surface: #FFFFFF;
  --lpe-surface-2: #F9FAFB;
  --lpe-border: #E5E7EB;
  --lpe-accent: #2563EB;
  --lpe-accent-hover: #1D4ED8;
  --lpe-accent-fg: #FFFFFF;
  --lpe-accent-glow: 0 0 0 1px rgba(37, 99, 235, 0.25), 0 8px 24px -10px rgba(37, 99, 235, 0.35);

  width: 640px;
  height: 640px;
  min-height: 640px;
  background: #FFFFFF;
  font-family: "Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
  color: #1F2937;
}

/* Header (top brand strip) — slim white with bottom rule */
.lpe-root[data-lpe-surface="popup"] .lpe-header {
  background: #FFFFFF !important;
  border-bottom: 1px solid #E5E7EB !important;
  padding: 12px 18px !important;
}
.lpe-root[data-lpe-surface="popup"] .lpe-header-title {
  color: #1F2937 !important;
  font-weight: 700 !important;
  letter-spacing: -0.01em;
}

/* Tabs — segmented look: active = white card, inactive = light-gray */
.lpe-root[data-lpe-surface="popup"] .lpe-tabs {
  background: #F3F4F6 !important;
  border-bottom: 1px solid #E5E7EB !important;
  padding: 8px 18px !important;
  gap: 0 !important;
  display: flex !important;
}
.lpe-root[data-lpe-surface="popup"] .lpe-tab {
  flex: 1 !important;
  padding: 10px 14px !important;
  background: #F3F4F6 !important;
  color: #6B7280 !important;
  border: 1px solid #E5E7EB !important;
  border-bottom: 1px solid #E5E7EB !important;
  font-weight: 600 !important;
  font-size: 13px !important;
  border-radius: 0 !important;
  border-right-width: 0 !important;
}
.lpe-root[data-lpe-surface="popup"] .lpe-tab:first-child { border-radius: 10px 0 0 10px !important; }
.lpe-root[data-lpe-surface="popup"] .lpe-tab:last-child  { border-radius: 0 10px 10px 0 !important; border-right-width: 1px !important; }
.lpe-root[data-lpe-surface="popup"] .lpe-tab[data-active="true"] {
  background: #FFFFFF !important;
  color: #111827 !important;
  font-weight: 700 !important;
  box-shadow: 0 1px 2px rgba(17,24,39,0.06);
}

/* Section / card panels */
.lpe-root[data-lpe-surface="popup"] .lpe-card,
.lpe-root[data-lpe-surface="popup"] .lpe-section {
  background: #F9FAFB !important;
  border: 1px solid #E5E7EB !important;
  border-radius: 14px !important;
  padding: 16px 18px !important;
  box-shadow: none !important;
}
.lpe-root[data-lpe-surface="popup"] .lpe-section-title,
.lpe-root[data-lpe-surface="popup"] .lpe-card-title {
  color: #1F2937 !important;
  font-weight: 700 !important;
  font-size: 13px !important;
  letter-spacing: 0 !important;
  margin-bottom: 10px !important;
}

/* Primary action — black pill (reference) */
.lpe-root[data-lpe-surface="popup"] .lpe-btn {
  background: #FFFFFF !important;
  border: 1px solid #E5E7EB !important;
  color: #1F2937 !important;
  border-radius: 12px !important;
  padding: 10px 16px !important;
  font-weight: 600 !important;
  font-size: 13px !important;
  box-shadow: none !important;
  transition: background 120ms, border-color 120ms, color 120ms;
}
.lpe-root[data-lpe-surface="popup"] .lpe-btn:hover:not([disabled]) {
  background: #F3F4F6 !important;
  border-color: #D1D5DB !important;
}
.lpe-root[data-lpe-surface="popup"] .lpe-btn-primary {
  background: #111827 !important;
  border-color: #111827 !important;
  color: #FFFFFF !important;
}
.lpe-root[data-lpe-surface="popup"] .lpe-btn-primary:hover:not([disabled]) {
  background: #1F2937 !important;
  border-color: #1F2937 !important;
}
.lpe-root[data-lpe-surface="popup"] .lpe-btn-danger,
.lpe-root[data-lpe-surface="popup"] .lpe-btn[data-variant="danger"] {
  background: #DC2626 !important;
  border-color: #DC2626 !important;
  color: #FFFFFF !important;
}

/* Hero CTA buttons — refined typography, icon, soft depth, hover lift */
.lpe-root[data-lpe-surface="popup"] .lpe-btn-hero {
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  gap: 10px !important;
  width: 100% !important;
  min-height: 48px !important;
  padding: 0 18px !important;
  border-radius: 12px !important;
  font-size: 14px !important;
  font-weight: 600 !important;
  letter-spacing: -0.005em !important;
  position: relative !important;
  transition: transform 140ms cubic-bezier(.2,.7,.3,1), box-shadow 140ms, background 140ms, border-color 140ms, color 140ms !important;
}
.lpe-root[data-lpe-surface="popup"] .lpe-btn-hero .lpe-btn-ico {
  width: 18px; height: 18px; flex: 0 0 18px;
}
.lpe-root[data-lpe-surface="popup"] .lpe-btn-hero .lpe-btn-kbd {
  margin-left: auto;
  font-size: 11px;
  font-weight: 500;
  letter-spacing: 0.02em;
  padding: 3px 7px;
  border-radius: 6px;
  background: rgba(255,255,255,0.14);
  color: rgba(255,255,255,0.82);
  font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
}
.lpe-root[data-lpe-surface="popup"] .lpe-btn-hero:focus-visible {
  outline: 2px solid #2563EB !important;
  outline-offset: 2px !important;
}
/* Primary hero (Export Full Page) — deep black with subtle gradient + lift */
.lpe-root[data-lpe-surface="popup"] .lpe-btn-primary.lpe-btn-hero {
  background: linear-gradient(180deg, #1F2937 0%, #0B0F14 100%) !important;
  border: 1px solid #0B0F14 !important;
  color: #FFFFFF !important;
  box-shadow:
    0 1px 0 rgba(255,255,255,0.06) inset,
    0 1px 2px rgba(17,24,39,0.18),
    0 6px 16px -8px rgba(17,24,39,0.45) !important;
}
.lpe-root[data-lpe-surface="popup"] .lpe-btn-primary.lpe-btn-hero:hover:not([disabled]) {
  transform: translateY(-1px);
  box-shadow:
    0 1px 0 rgba(255,255,255,0.08) inset,
    0 2px 4px rgba(17,24,39,0.22),
    0 10px 22px -8px rgba(17,24,39,0.55) !important;
}
.lpe-root[data-lpe-surface="popup"] .lpe-btn-primary.lpe-btn-hero:active:not([disabled]) {
  transform: translateY(0);
  box-shadow: 0 1px 2px rgba(17,24,39,0.22) !important;
}
/* Secondary hero (Sign in — Share Links) — crisp white card */
.lpe-root[data-lpe-surface="popup"] .lpe-btn-secondary.lpe-btn-hero {
  background: #FFFFFF !important;
  border: 1px solid #E5E7EB !important;
  color: #111827 !important;
  box-shadow: 0 1px 2px rgba(17,24,39,0.04) !important;
}
.lpe-root[data-lpe-surface="popup"] .lpe-btn-secondary.lpe-btn-hero:hover:not([disabled]) {
  transform: translateY(-1px);
  border-color: #111827 !important;
  box-shadow: 0 6px 14px -8px rgba(17,24,39,0.25) !important;
}
.lpe-root[data-lpe-surface="popup"] .lpe-btn-secondary.lpe-btn-hero .lpe-btn-kbd {
  background: #F3F4F6;
  color: #6B7280;
}
.lpe-root[data-lpe-surface="popup"] .lpe-btn-hero[disabled] {
  opacity: 0.55 !important;
  cursor: not-allowed !important;
  transform: none !important;
}

/* Pill buttons (mode selectors) — segmented row, dark active */
.lpe-root[data-lpe-surface="popup"] .lpe-pill-btn {
  background: transparent !important;
  border: 1px solid #E5E7EB !important;
  color: #1F2937 !important;
  border-radius: 999px !important;
  padding: 8px 14px !important;
  font-weight: 600 !important;
  font-size: 12px !important;
  box-shadow: none !important;
}
.lpe-root[data-lpe-surface="popup"] .lpe-pill-btn:hover:not(:disabled) {
  background: #F3F4F6 !important;
}
.lpe-root[data-lpe-surface="popup"] .lpe-pill-btn[data-active="true"],
.lpe-root[data-lpe-surface="popup"] .lpe-pill-btn--active {
  background: #111827 !important;
  border-color: #111827 !important;
  color: #FFFFFF !important;
}
.lpe-root[data-lpe-surface="popup"] .lpe-pill-btn--ghost {
  background: transparent !important;
  border: 1px dashed #D1D5DB !important;
  color: #6B7280 !important;
}

/* Selectable "card" tiles (mode/source grids) — blue accent when active */
.lpe-root[data-lpe-surface="popup"] [role="radio"],
.lpe-root[data-lpe-surface="popup"] .lpe-mode-card,
.lpe-root[data-lpe-surface="popup"] .lpe-tile {
  background: #FFFFFF !important;
  border: 1px solid #E5E7EB !important;
  border-radius: 12px !important;
  padding: 12px 14px !important;
}
.lpe-root[data-lpe-surface="popup"] [role="radio"][aria-checked="true"],
.lpe-root[data-lpe-surface="popup"] .lpe-mode-card[data-active="true"],
.lpe-root[data-lpe-surface="popup"] .lpe-tile[data-active="true"] {
  background: #EFF6FF !important;
  border-color: #2563EB !important;
  border-left: 3px solid #2563EB !important;
  color: #1E3A8A !important;
}

/* Status / progress */
.lpe-root[data-lpe-surface="popup"] .lpe-status {
  background: #F9FAFB !important;
  border: 1px solid #E5E7EB !important;
  border-radius: 12px !important;
  color: #1F2937 !important;
  padding: 10px 14px !important;
  font-size: 13px !important;
}
.lpe-root[data-lpe-surface="popup"] .lpe-status[data-status="Success"] {
  background: #ECFDF5 !important;
  border-color: #10B981 !important;
  color: #065F46 !important;
}
.lpe-root[data-lpe-surface="popup"] .lpe-status[data-status="Error"] {
  background: #FEF2F2 !important;
  border-color: #DC2626 !important;
  color: #991B1B !important;
}
.lpe-root[data-lpe-surface="popup"] .lpe-progress {
  background: #E5E7EB !important;
  border-radius: 999px !important;
  height: 6px !important;
}
.lpe-root[data-lpe-surface="popup"] .lpe-progress-bar {
  background: #2563EB !important;
}

/* Inputs / selects */
.lpe-root[data-lpe-surface="popup"] input[type="text"],
.lpe-root[data-lpe-surface="popup"] input[type="number"],
.lpe-root[data-lpe-surface="popup"] input[type="email"],
.lpe-root[data-lpe-surface="popup"] select,
.lpe-root[data-lpe-surface="popup"] textarea {
  background: #FFFFFF !important;
  border: 1px solid #E5E7EB !important;
  border-radius: 10px !important;
  color: #1F2937 !important;
  font-size: 13px !important;
  padding: 8px 10px !important;
}
.lpe-root[data-lpe-surface="popup"] input:focus,
.lpe-root[data-lpe-surface="popup"] select:focus,
.lpe-root[data-lpe-surface="popup"] textarea:focus {
  outline: none !important;
  border-color: #2563EB !important;
  box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.18) !important;
}

/* Checkboxes — modern square with blue check */
.lpe-root[data-lpe-surface="popup"] input[type="checkbox"] {
  accent-color: #2563EB;
}

/* Footer toggle row */
.lpe-root[data-lpe-surface="popup"] .lpe-footer,
.lpe-root[data-lpe-surface="popup"] .lpe-toggle-row {
  border-top: 1px solid #E5E7EB !important;
  background: #FFFFFF !important;
  padding: 12px 18px !important;
  font-size: 13px !important;
  color: #6B7280 !important;
}

/* Scrollbar polish */
.lpe-root[data-lpe-surface="popup"] *::-webkit-scrollbar { width: 8px; height: 8px; }
.lpe-root[data-lpe-surface="popup"] *::-webkit-scrollbar-thumb { background: #D1D5DB; border-radius: 8px; }
.lpe-root[data-lpe-surface="popup"] *::-webkit-scrollbar-track { background: transparent; }

/* ---------- WorkspacePicker (W7) ---------- */
.lpe-ws-chip {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 6px 10px;
  border-radius: 999px;
  border: 1px solid var(--lpe-border);
  background: var(--lpe-surface);
  color: var(--lpe-fg);
  font: inherit;
  font-weight: 600;
  cursor: pointer;
  max-width: 100%;
}
.lpe-ws-chip:hover { background: var(--lpe-surface-2); }
.lpe-ws-chip:focus-visible {
  outline: none;
  box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.25);
  border-color: var(--lpe-accent);
}
.lpe-ws-chip-name {
  max-width: 180px;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.lpe-ws-chip-caret { color: var(--lpe-muted); font-size: 11px; }
.lpe-ws-chip-badge {
  display: inline-block;
  padding: 2px 8px;
  border-radius: 999px;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.02em;
  background: #E5E7EB;
  color: #1F2937;
  border: 1px solid #D1D5DB;
}
.lpe-ws-chip-badge[data-license="active"] {
  background: #ECFDF5; color: #065F46; border-color: #6EE7B7;
}
.lpe-ws-chip-badge[data-license="past_due"] {
  background: #FFFBEB; color: #92400E; border-color: #FCD34D;
}
.lpe-ws-chip-badge[data-license="canceled"] {
  background: #FEF2F2; color: #991B1B; border-color: #FCA5A5;
}
.lpe-ws-chip-badge[data-role="owner"] {
  background: #EFF6FF; color: #1E3A8A; border-color: #93C5FD;
}
.lpe-ws-chip-badge[data-role="admin"] {
  background: #F5F3FF; color: #5B21B6; border-color: #C4B5FD;
}

.lpe-ws-overlay {
  position: fixed;
  inset: 0;
  background: rgba(17, 24, 39, 0.45);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 2147483647;
  padding: 16px;
}
.lpe-ws-dialog {
  background: #FFFFFF;
  border: 1px solid var(--lpe-border);
  border-radius: 14px;
  width: 100%;
  max-width: 420px;
  max-height: 80vh;
  display: flex;
  flex-direction: column;
  box-shadow: 0 24px 48px -16px rgba(17,24,39,0.30);
  overflow: hidden;
}
.lpe-ws-dialog-header {
  display: flex; align-items: center; justify-content: space-between;
  padding: 14px 18px;
  border-bottom: 1px solid var(--lpe-border);
  color: var(--lpe-fg);
}
.lpe-ws-dialog-close {
  background: transparent; border: none; cursor: pointer;
  font-size: 22px; line-height: 1; color: var(--lpe-muted);
  padding: 2px 8px; border-radius: 8px;
}
.lpe-ws-dialog-close:hover { background: var(--lpe-surface-2); color: var(--lpe-fg); }
.lpe-ws-list { list-style: none; margin: 0; padding: 8px; overflow-y: auto; }
.lpe-ws-row {
  width: 100%;
  display: flex; align-items: center; justify-content: space-between;
  gap: 12px;
  padding: 10px 12px;
  border-radius: 10px;
  border: 1px solid transparent;
  background: transparent;
  text-align: left;
  font: inherit;
  color: var(--lpe-fg);
  cursor: pointer;
}
.lpe-ws-row:hover { background: var(--lpe-surface-2); }
.lpe-ws-row[data-active="true"] {
  background: #EFF6FF;
  border-color: #2563EB;
}
.lpe-ws-row-name { font-weight: 600; }
.lpe-ws-row-current { color: var(--lpe-muted); font-weight: 500; margin-left: 4px; }
.lpe-ws-row-meta { display: inline-flex; gap: 6px; flex-shrink: 0; }
.lpe-ws-dialog-footer {
  padding: 12px 18px;
  border-top: 1px solid var(--lpe-border);
  background: var(--lpe-surface-2);
}
.lpe-ws-manage {
  color: var(--lpe-accent);
  font-weight: 600;
  text-decoration: none;
  font-size: 13px;
}
.lpe-ws-manage:hover { text-decoration: underline; }
`;function vt(e,t,n){return Number.isNaN(e)||n<t?t:Math.max(t,Math.min(n,e))}const Jg="inspect-page-panel-host",yd=520,qg=720,bd=520,wd=640,kd=720,Sd=900,dr=16;let Pi=null;function ex(){if(Pi){Pi.host.style.display="block";return}const e=document.createElement("div");e.id=Jg,e.style.cssText=["position: fixed","top: 0","left: 0","width: 0","height: 0",`z-index: ${Cs}`,"pointer-events: none"].join(";"),document.documentElement.appendChild(e);const t=e.attachShadow({mode:"open"}),n=document.createElement("style");n.textContent=Kg,t.appendChild(n);const r=document.createElement("div"),o=vt(yd,320,Math.max(320,window.innerWidth-dr*2)),i=vt(qg,420,Math.max(420,window.innerHeight-dr*2));r.style.cssText=["position: fixed","pointer-events: auto",`width: ${o}px`,`height: ${i}px`].join(";"),t.appendChild(r);const a=Qp(r),l=tx(r),s=nx(r);Me(xe.GetPanelPosition,{}).then(b=>{if(!b)return;if(b.minimized){e.style.display="none",y();return}const f=Math.min(kd,Math.max(320,window.innerWidth-dr*2)),v=Math.min(Sd,Math.max(420,window.innerHeight-dr*2)),p=Math.min(bd,f),d=Math.min(wd,v);typeof b.wPx=="number"&&(r.style.width=`${vt(b.wPx,p,f)}px`),typeof b.hPx=="number"&&(r.style.height=`${vt(b.hPx,d,v)}px`);const g=r.getBoundingClientRect().width||320,S=r.getBoundingClientRect().height||240;r.style.left=`${vt(b.xPx,0,window.innerWidth-g)}px`,r.style.top=`${vt(b.yPx,0,window.innerHeight-S)}px`}).catch(()=>{});let u=null;const y=()=>{u||(u=document.createElement("div"),u.id="inspect-page-restore-pill",u.style.cssText=["position: fixed","bottom: 16px","right: 16px",`z-index: ${Cs}`,"background: #1f6feb","color: #fff","font: 600 12px/1 system-ui, -apple-system, Segoe UI, Roboto, sans-serif","padding: 8px 12px","border-radius: 999px","box-shadow: 0 4px 14px rgba(0,0,0,0.25)","cursor: pointer","user-select: none"].join(";"),u.textContent="Inspect Page",u.setAttribute("role","button"),u.setAttribute("aria-label","Restore Inspect Page panel"),u.addEventListener("click",()=>{e.style.display="block",Ri({minimized:!1}).catch(()=>{}),u?.remove(),u=null}),document.documentElement.appendChild(u))},x=()=>{try{a.unmount()}catch{}l(),s(),e.remove(),u?.remove(),u=null,Pi=null,Ri({minimized:!1}).catch(()=>{})},w=()=>{e.style.display="none",y(),Ri({minimized:!0}).catch(()=>{})},h=()=>{try{const b=chrome.runtime?.getURL?.("popup/index.html");if(!b)return;chrome.windows?.create?.({url:b,type:"popup",width:540,height:760,focused:!0}),x()}catch{}};a.render(c.jsx(G.StrictMode,{children:c.jsx($g,{surface:"floating",activeUrl:location.href,onMinimize:w,onClose:x,onPopOut:h})})),Pi={host:e,root:a,cleanup:()=>{l(),s()}},be.info(ve.Lifecycle,"Floating panel mounted")}function tx(e){const t=e.getBoundingClientRect().width||yd,n=Math.max(0,window.innerWidth-t-dr);e.style.top=`${dr}px`,e.style.left=`${n}px`;let r=!1,o=0,i=0,a=0,l=0,s=-1;const u=h=>{const b=h.target;if(b?.closest("button, a, input, select, textarea, [role='button']"))return;const f=b?.closest("[data-drag-handle='true']");f&&(r=!0,s=h.pointerId,o=h.clientX,i=h.clientY,a=parseFloat(e.style.left||"0"),l=parseFloat(e.style.top||"0"),f.setPointerCapture?.(s),h.preventDefault())},y=h=>{if(!r)return;const b=h.clientX-o,f=h.clientY-i,v=e.getBoundingClientRect(),p=vt(a+b,0,window.innerWidth-v.width),d=vt(l+f,0,window.innerHeight-v.height);e.style.left=`${p}px`,e.style.top=`${d}px`},x=()=>{if(!r)return;r=!1,s=-1;const h=parseFloat(e.style.left||"0"),b=parseFloat(e.style.top||"0");xs({xPx:h,yPx:b,minimized:!1})},w=()=>{const h=e.getBoundingClientRect(),b=vt(parseFloat(e.style.left||"0"),0,window.innerWidth-h.width),f=vt(parseFloat(e.style.top||"0"),0,window.innerHeight-h.height);e.style.left=`${b}px`,e.style.top=`${f}px`,xs({xPx:b,yPx:f})};return e.addEventListener("pointerdown",u),window.addEventListener("pointermove",y),window.addEventListener("pointerup",x),window.addEventListener("resize",w),()=>{e.removeEventListener("pointerdown",u),window.removeEventListener("pointermove",y),window.removeEventListener("pointerup",x),window.removeEventListener("resize",w)}}let Ii=null,zi={};function xs(e){zi={...zi,...e},Ii&&clearTimeout(Ii),Ii=setTimeout(()=>{const t=zi;zi={},Ii=null,Ri(t).catch(()=>{})},$d)}async function Ri(e){await Me(xe.SetPanelPosition,e)}function nx(e){let t=!1,n=0,r=0,o=0,i=0,a=-1;const l=y=>{const w=y.target?.closest("[data-resize-handle='true']");if(!w)return;t=!0,a=y.pointerId;const h=e.getBoundingClientRect();n=h.width,r=h.height,o=y.clientX,i=y.clientY,w.setPointerCapture?.(a),y.preventDefault(),y.stopPropagation()},s=y=>{if(!t)return;const x=parseFloat(e.style.left||"0"),w=parseFloat(e.style.top||"0"),h=Math.min(kd,Math.max(320,window.innerWidth-x)),b=Math.min(Sd,Math.max(420,window.innerHeight-w)),f=Math.min(bd,h),v=Math.min(wd,b),p=vt(n+(y.clientX-o),f,h),d=vt(r+(y.clientY-i),v,b);e.style.width=`${p}px`,e.style.height=`${d}px`},u=()=>{if(!t)return;t=!1,a=-1;const y=e.getBoundingClientRect();xs({wPx:Math.round(y.width),hPx:Math.round(y.height)})};return e.addEventListener("pointerdown",l),window.addEventListener("pointermove",s),window.addEventListener("pointerup",u),()=>{e.removeEventListener("pointerdown",l),window.removeEventListener("pointermove",s),window.removeEventListener("pointerup",u)}}const rx=new Set(["area","base","br","col","embed","hr","img","input","link","meta","param","source","track","wbr"]);function ox(e){return e.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;")}function ix(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function io(e){let t="";for(const n of Array.from(e.attributes))t+=` ${n.name}="${ox(n.value)}"`;return t}function _d(e,t={}){const n=t.expandShadowRoots!==!1,r=!!t.redactPasswordFields,o=t.captureAdoptedStyleSheets!==!1,i=u=>{try{const y=u.cssRules;let x="";for(let w=0;w<y.length;w+=1)x+=y[w].cssText;return x}catch{return""}},a=u=>{if(!o)return"";const y=u.adoptedStyleSheets;if(!y||y.length===0)return"";let x="";for(const w of y)x+=i(w);return x?`<style data-adopted-stylesheet="true">${x}</style>`:""},l=u=>{if(u.nodeType===Node.TEXT_NODE)return ix(u.data);if(u.nodeType===Node.COMMENT_NODE)return`<!--${u.data}-->`;if(u.nodeType===Node.CDATA_SECTION_NODE)return`<![CDATA[${u.data}]]>`;if(u.nodeType!==Node.ELEMENT_NODE)return"";const y=u,x=y.tagName.toLowerCase();if(r&&x==="input"&&(y.getAttribute("type")||"").toLowerCase()==="password"){const b=y.cloneNode(!1);return b.setAttribute("value",""),b.setAttribute("data-redacted","true"),`<input${io(b)}>`}if(rx.has(x))return`<${x}${io(y)}>`;if(x==="template"){const b=y;let f="";for(const v of Array.from(b.content.childNodes))f+=l(v);return`<template${io(y)}>${f}</template>`}if(x==="script"||x==="style")return`<${x}${io(y)}>${y.textContent??""}</${x}>`;let w="";const h=n?y.shadowRoot:null;if(h&&h.mode==="open"){let b="";b+=a(h);for(const f of Array.from(h.childNodes))b+=l(f);w+=`<template shadowrootmode="open">${b}</template>`}for(const b of Array.from(y.childNodes))w+=l(b);return`<${x}${io(y)}>${w}</${x}>`};let s=l(e);if(o&&e.nodeType===Node.ELEMENT_NODE&&e.ownerDocument?.documentElement===e){const x=a(e.ownerDocument);if(x){const w=s.match(/<head(\s[^>]*)?>/i);if(w){const h=(w.index??0)+w[0].length;s=s.slice(0,h)+x+s.slice(h)}else s=s.replace(/<html(\s[^>]*)?>/i,h=>`${h}<head>${x}</head>`)}}return s}function ax(e){let t=0;const n=r=>{const o=r.shadowRoot;if(o&&o.mode==="open"){t+=1;for(const i of Array.from(o.children))n(i)}for(const i of Array.from(r.children))n(i)};return n(e),t}function lx(e,t=document){try{const n=new XMLSerializer,r=t.doctype?n.serializeToString(t.doctype):"<!DOCTYPE html>",o=e.expandShadowRoots!==!1,i=t.documentElement,a=o?ax(i):0;let l=_d(i,{redactPasswordFields:e.redactPasswordFields,expandShadowRoots:o});const s=l.match(/<head(\s[^>]*)?>/i),u=[];if(/<meta[^>]*charset=/i.test(l)||u.push('<meta charset="utf-8">'),!/<base[^>]*\shref=/i.test(l)){const y=t.location?.href??"/";u.push(`<base href="${y.replace(/"/g,"&quot;")}">`)}if(u.length)if(s){const y=(s.index??0)+s[0].length;l=l.slice(0,y)+u.join("")+l.slice(y)}else l=l.replace(/<html(\s[^>]*)?>/i,y=>`${y}<head>${u.join("")}</head>`);return a>0&&be.info(ve.HtmlSerialize,`expanded ${a} open shadow root(s)`),`${r}
${l}
`}catch(n){throw be.error(ve.HtmlSerialize,ke.E_HTML_SERIALIZE,"serialize failed",n),new He(ke.E_HTML_SERIALIZE,"Failed to serialize page HTML")}}async function sx(e=document){const t={inlineStyles:0,linkedStylesheets:0,unreachableStylesheets:0},n=[],r=Array.from(e.styleSheets);for(const o of r){let i=o.href??`inline #${++t.inlineStyles}`,a="";try{const l=o.cssRules;a=Array.from(l).map(s=>s.cssText).join(`
`),o.href&&t.linkedStylesheets++}catch{if(o.href)try{const l=await fetch(o.href,{credentials:"omit"});if(!l.ok)throw new Error(`HTTP ${l.status}`);a=await l.text(),t.linkedStylesheets++}catch(l){be.warn(ve.CssCollect,ke.W_CSS_FETCH_FAILED,o.href,l),t.unreachableStylesheets++,i=`unreachable: ${o.href}`,a=""}else be.warn(ve.CssCollect,ke.W_CSS_INLINE_UNREADABLE,"inline cross-origin"),a=""}n.push(`/* === <${i}> === */
${a}`)}return{css:`${n.join(`

`)}
`,counts:t}}const cx=new Set(["application/json","application/ld+json","importmap"]);async function ux(e=document){const t={inlineScripts:0,linkedScripts:0,unreachableScripts:0},n=[],r=Array.from(e.querySelectorAll("script"));for(const o of r){const i=(o.getAttribute("type")||"").toLowerCase();if(i&&cx.has(i))continue;const a=o.getAttribute("src");let l,s;if(!a)l=`inline #${++t.inlineScripts}`,s=o.textContent??"";else try{const u=new URL(a,e.location?.href??location.href).toString(),y=await fetch(u,{credentials:"omit"});if(!y.ok)throw new Error(`HTTP ${y.status}`);s=await y.text(),l=u,t.linkedScripts++}catch(u){be.warn(ve.JsCollect,ke.W_JS_FETCH_FAILED,a,u),t.unreachableScripts++,l=`unreachable: ${a}`,s=""}n.push(`/* === <${l}> === */
${s}`)}return{js:`${n.join(`

`)}
`,counts:t}}function px(e,t=document){const n=t.location?.href??"",r=typeof window<"u"?window:{innerWidth:0,innerHeight:0,devicePixelRatio:1},o=typeof navigator<"u"?navigator.userAgent:"",i=t.documentElement,a=t.body,l=Math.max(i?.scrollWidth??0,i?.offsetWidth??0,i?.clientWidth??0,a?.scrollWidth??0,a?.offsetWidth??0),s=Math.max(i?.scrollHeight??0,i?.offsetHeight??0,i?.clientHeight??0,a?.scrollHeight??0,a?.offsetHeight??0);return{schemaVersion:1,kind:"fullPage",url:n,title:t.title??"",capturedAtIso:new Date().toISOString(),viewportCssPx:{w:r.innerWidth,h:r.innerHeight},pageCssPx:{w:l,h:s},devicePixelRatio:r.devicePixelRatio??1,userAgent:o,counts:{inlineStyles:e.css.inlineStyles,linkedStylesheets:e.css.linkedStylesheets,unreachableStylesheets:e.css.unreachableStylesheets,inlineScripts:e.js.inlineScripts,linkedScripts:e.js.linkedScripts,unreachableScripts:e.js.unreachableScripts,captureFrames:e.captureFrames},extensionVersion:e.extensionVersion}}const dx="#inspect-page-panel-host,#inspect-page-picker-host,[id^='inspect-page-'][id$='-host']",fx=214748e4;function vs(e,t=window){if(!e||e.nodeType!==1)return!1;if(e.matches?.(dx))return!0;const n=e.parentElement;if(!(n===e.ownerDocument?.body||n===e.ownerDocument?.documentElement))return!1;if(e.tagName.includes("-"))return!0;let i=null;try{i=t.getComputedStyle(e)}catch{i=null}const a=i?.position??"",l=a==="fixed"||a==="sticky";if(l&&e.shadowRoot)return!0;if(l){const s=Number(i?.zIndex);if(Number.isFinite(s)&&s>=fx)return!0}return!1}function hx(e=document,t=window){const n=[],r=[];e.documentElement&&r.push(...Array.from(e.documentElement.children)),e.body&&r.push(...Array.from(e.body.children));const o=new Set;for(const i of r)o.has(i)||(o.add(i),vs(i,t)&&n.push(i));return n}async function mx(e){const t=[];try{for(const s of hx(document,window)){const u=s.parentNode;u&&(t.push({node:s,parent:u,next:s.nextSibling}),u.removeChild(s))}}catch{}let n,r,o;try{n=lx({redactPasswordFields:e.redactPasswordFields}),r=await sx(),o=await ux(),gx()}finally{for(const s of t)try{s.parent.insertBefore(s.node,s.next)}catch{}}const i=r.counts,a=o.counts,l=px({css:i,js:a,captureFrames:0,extensionVersion:e.extensionVersion});return{html:n,css:r.css,js:o.js,meta:l}}function gx(){try{const e=document.querySelectorAll("*");let t=0;for(let n=0;n<e.length&&!(e[n].tagName.includes("-")&&(t+=1,t>=1));n+=1);t>0&&be.warn(ve.HtmlSerialize,ke.W_WEB_COMPONENT_SKIPPED,"page uses custom elements; behavior not bundled (HTML preserved)")}catch{}}let Gt=null;function xx(e){const t=getComputedStyle(e);return t.position==="fixed"||t.position==="sticky"}function vx(){const e=document.querySelectorAll("*"),t=[],n=Math.min(e.length,Wi);for(let o=0;o<n;o++){const i=e[o];i instanceof HTMLElement&&xx(i)&&(t.push({el:i,prevCss:i.style.cssText}),i.style.setProperty("visibility","hidden","important"))}e.length>Wi&&be.warn(ve.Capture,ke.W_STICKY_SCAN_TRUNCATED,`sticky scan capped at ${Wi}`);const r=document.documentElement.style.scrollBehavior;return document.documentElement.style.scrollBehavior="auto",{prevScroll:{x:window.scrollX,y:window.scrollY},prevScrollBehavior:r,stuck:t,startHref:location.href}}function yx(e){return new Promise(t=>{let n=e;const r=()=>{n--,n<=0?t():requestAnimationFrame(r)};requestAnimationFrame(r)})}function bx(e){return new Promise(t=>setTimeout(t,e))}async function wx(e){if(Gt||(Gt=vx()),location.href!==Gt.startHref)throw be.error(ve.Capture,ke.E_ROUTE_CHANGED,"href changed mid-capture"),new Error(ke.E_ROUTE_CHANGED);return window.scrollTo({top:e.y,left:0,behavior:"auto"}),await yx(Md),await bx(e.settleMs),{actualY:window.scrollY,dpr:window.devicePixelRatio}}function kx(){if(Gt){for(const{el:e,prevCss:t}of Gt.stuck)e.style.cssText=t;document.documentElement.style.scrollBehavior=Gt.prevScrollBehavior,window.scrollTo(Gt.prevScroll.x,Gt.prevScroll.y),Gt=null}}const Sx="inspect-page-picker-host";let V=null;const _x=`
:host { all: initial; }
.lpe-pk-box {
  position: fixed; pointer-events: none;
  outline: 2px solid #7c5cff;
  background: rgba(124,92,255,0.12);
  z-index: ${Qt};
  transition: none;
  display: none;
}
.lpe-pk-margin, .lpe-pk-padding {
  position: fixed; pointer-events: none;
  z-index: ${Qt};
  display: none;
  box-sizing: border-box;
}
.lpe-pk-margin { outline: 1px dashed rgba(255,165,0,0.55); background: rgba(255,165,0,0.07); }
.lpe-pk-padding { outline: 1px dashed rgba(60,200,140,0.6); background: rgba(60,200,140,0.07); }
.lpe-pk-badge {
  position: fixed; pointer-events: none;
  z-index: ${Qt};
  display: none;
  background: #1c1c1c; color: #f0f0f0;
  font: 10px ui-monospace, SFMono-Regular, Menlo, monospace;
  padding: 1px 4px; border-radius: 3px;
  box-shadow: 0 1px 2px rgba(0,0,0,0.35);
  white-space: nowrap;
}
.lpe-pk-size {
  background: #7c5cff; color: #ffffff;
  font: 10px ui-monospace, SFMono-Regular, Menlo, monospace;
  padding: 2px 6px; border-radius: 3px;
  white-space: nowrap;
}
/* P1: chip group with size + action icons (clickable) */
.lpe-pk-chip {
  position: fixed; z-index: ${Qt};
  display: none; align-items: center; gap: 4px;
  padding: 3px; border-radius: 5px;
  background: rgba(13,17,23,0.92); color: #f6f8fa;
  box-shadow: 0 4px 12px rgba(0,0,0,0.35);
  border: 1px solid rgba(255,255,255,0.08);
  pointer-events: auto;
  font: 11px ui-sans-serif, system-ui, sans-serif;
}
.lpe-pk-chip-btn {
  all: unset; box-sizing: border-box;
  display: inline-flex; align-items: center; justify-content: center;
  width: 22px; height: 22px; border-radius: 4px;
  cursor: pointer; color: #f6f8fa;
  font: 12px ui-sans-serif, system-ui, sans-serif;
}
.lpe-pk-chip-btn:hover { background: rgba(255,255,255,0.12); }
.lpe-pk-chip-btn:focus-visible { outline: 2px solid #7c5cff; outline-offset: 1px; }
.lpe-pk-chip-btn[data-variant="select"]:hover { background: rgba(60,200,140,0.25); color: #6dffb0; }
.lpe-pk-chip-btn[data-variant="cancel"]:hover { background: rgba(255,90,90,0.25); color: #ffb4b4; }
.lpe-pk-chip-flash {
  display: none; padding: 0 6px; border-radius: 3px;
  background: rgba(60,200,140,0.25); color: #6dffb0;
  font-size: 10px;
}
.lpe-pk-guide {
  position: fixed; pointer-events: none;
  z-index: ${Qt};
  display: none;
  background: rgba(124,92,255,0.55);
}
.lpe-pk-guide.h { height: 1px; }
.lpe-pk-guide.v { width: 1px; }
.lpe-pk-glabel {
  position: fixed; pointer-events: none;
  z-index: ${Qt};
  display: none;
  background: #7c5cff; color: #ffffff;
  font: 10px ui-monospace, SFMono-Regular, Menlo, monospace;
  padding: 1px 4px; border-radius: 3px;
  white-space: nowrap;
}
.lpe-pk-tip {
  position: fixed; pointer-events: none;
  background: #0d1117; color: #f6f8fa;
  font: 12px ui-sans-serif, system-ui, sans-serif;
  padding: 10px 12px; border-radius: 10px;
  box-shadow: 0 6px 18px rgba(0,0,0,0.32);
  border: 1px solid rgba(255,255,255,0.08);
  z-index: ${Qt};
  max-width: 360px; min-width: 240px;
  display: none;
}
.lpe-pk-tip b { color: #c4b5fd; font-weight: 600; }
.lpe-pk-tip i { color: #9ca3af; font-style: normal; margin-left: 6px; }
.lpe-pk-tip .lpe-pk-head { font: 600 13px ui-sans-serif, system-ui, sans-serif; color: #f6f8fa; margin-bottom: 2px; word-break: break-all; }
.lpe-pk-tip .lpe-pk-sub { font: 11px ui-monospace, SFMono-Regular, Menlo, monospace; color: #9ca3af; margin-bottom: 8px; }
.lpe-pk-tip .lpe-pk-rows { display: grid; grid-template-columns: 88px 1fr; row-gap: 4px; column-gap: 8px; align-items: center; }
.lpe-pk-tip .lpe-pk-k { color: #9ca3af; font-size: 11px; }
.lpe-pk-tip .lpe-pk-v { color: #f6f8fa; font: 11px ui-monospace, SFMono-Regular, Menlo, monospace; display: inline-flex; align-items: center; gap: 6px; word-break: break-all; }
.lpe-pk-tip .lpe-pk-sw { width: 12px; height: 12px; border-radius: 3px; border: 1px solid rgba(255,255,255,0.18); flex: none; background-image: linear-gradient(45deg, #555 25%, transparent 25%), linear-gradient(-45deg, #555 25%, transparent 25%), linear-gradient(45deg, transparent 75%, #555 75%), linear-gradient(-45deg, transparent 75%, #555 75%); background-size: 6px 6px; background-position: 0 0, 0 3px, 3px -3px, -3px 0; }
.lpe-pk-tip .lpe-pk-sw-fill { background-image: none; }
.lpe-pk-tip .lpe-pk-pill { display: inline-flex; align-items: center; gap: 4px; padding: 1px 8px; border-radius: 999px; font-size: 11px; font-weight: 600; }
.lpe-pk-tip .lpe-pk-pill.ok { background: rgba(60,200,140,0.18); color: #6dffb0; }
.lpe-pk-tip .lpe-pk-pill.warn { background: rgba(255,196,84,0.18); color: #ffd479; }
.lpe-pk-tip .lpe-pk-pill.bad { background: rgba(255,90,90,0.2); color: #ffb4b4; }
`;function Cx(e){if(V)return;const t=document.createElement("div");t.id=Sx,t.style.cssText=`position:fixed;inset:0;width:0;height:0;pointer-events:none;z-index:${Qt};`,document.documentElement.appendChild(t);const n=t.attachShadow({mode:"open"}),r=document.createElement("style");r.textContent=_x,n.appendChild(r);const o=document.createElement("div");o.className="lpe-pk-box",n.appendChild(o);const i=document.createElement("div");i.className="lpe-pk-margin",n.appendChild(i);const a=document.createElement("div");a.className="lpe-pk-padding",n.appendChild(a);const l=document.createElement("div");l.className="lpe-pk-size";const s=document.createElement("div");s.className="lpe-pk-chip",s.appendChild(l);const u=(O,P,I)=>{const re=document.createElement("button");return re.type="button",re.className="lpe-pk-chip-btn",re.dataset.variant=I,re.setAttribute("aria-label",O),re.title=O,re.textContent=P,re},y=u("Select element","✓","select"),x=u("Copy selector","⧉","copy"),w=u("Cancel picker","✕","cancel"),h=document.createElement("span");h.className="lpe-pk-chip-flash",h.textContent="Copied",s.append(y,x,w,h),n.appendChild(s);const b=()=>{const O=document.createElement("div");return O.className="lpe-pk-badge",n.appendChild(O),O},f=[b(),b(),b(),b()],v=[b(),b(),b(),b()],p=O=>{const P=document.createElement("div");return P.className=`lpe-pk-guide ${O}`,n.appendChild(P),P},d=[p("v"),p("h"),p("v"),p("h")],g=()=>{const O=document.createElement("div");return O.className="lpe-pk-glabel",n.appendChild(O),O},S=[g(),g(),g(),g()],C=document.createElement("div");C.className="lpe-pk-tip",n.appendChild(C);const A=document.body?.style.cursor??"";document.body&&(document.body.style.cursor="crosshair");const T=O=>{V&&(V.chipHover||(V.navTarget&&(V.navTarget=null),V.pendingEvent=O,!V.rafScheduled&&(V.rafScheduled=!0,requestAnimationFrame(()=>{if(!V)return;V.rafScheduled=!1;const P=V.pendingEvent;V.pendingEvent=null,P&&Oi(P.clientX,P.clientY)}))))};let R=0;const L=O=>{const P=performance.now();P-R<Bd||(R=P,T(O))},M=O=>{if(O.target?.closest?.("#inspect-page-panel-host")||O.composedPath().includes(s))return;O.preventDefault(),O.stopPropagation();const I=Di(O.clientX,O.clientY);if(!I)return;const re=I.getBoundingClientRect();Promise.resolve(e.onSelect({element:I,rect:re})).catch(te=>{be.warn(ve.Picker,"SELECT_FAIL","select handler threw",te)})},ie=O=>{if(O.target?.closest?.("#inspect-page-panel-host")||O.composedPath().includes(s))return;O.preventDefault(),O.stopPropagation();const I=Di(O.clientX,O.clientY);if(!I)return;const re=I.getBoundingClientRect();Promise.resolve(e.onSelect({element:I,rect:re})).catch(te=>{be.warn(ve.Picker,"SELECT_FAIL","select handler threw",te)})},F=()=>{V&&(V.chipHover=!0)},B=()=>{V&&(V.chipHover=!1)};s.addEventListener("pointerenter",F),s.addEventListener("pointerleave",B);const k=O=>{O.preventDefault(),O.stopPropagation();const P=V?.currentTarget??null;if(!P)return;const I=P.getBoundingClientRect();Promise.resolve(e.onSelect({element:P,rect:I})).catch(re=>{be.warn(ve.Picker,"SELECT_FAIL","select handler threw",re)})},H=async O=>{O.preventDefault(),O.stopPropagation();const P=V?.currentTarget??null;if(!P)return;const I=Px(P);try{await navigator.clipboard.writeText(I)}catch{}V&&(V.chipFlash.style.display="inline-block",window.setTimeout(()=>{V&&(V.chipFlash.style.display="none")},1100)),be.info(ve.Picker,"Copied selector via chip",I)},ce=O=>{O.preventDefault(),O.stopPropagation(),e.onCancel(),Li()};y.addEventListener("click",k),x.addEventListener("click",O=>{H(O)}),w.addEventListener("click",ce);const Q=O=>{if(O.key==="Escape"){O.preventDefault(),O.stopPropagation(),e.onCancel(),Li();return}if((O.key==="Alt"||O.altKey)&&V&&!V.altDown&&(V.altDown=!0,Oi(V.lastX,V.lastY)),!V||!["ArrowUp","ArrowDown","ArrowLeft","ArrowRight","Enter"].includes(O.key)||O.target?.closest?.("#inspect-page-panel-host"))return;O.preventDefault(),O.stopPropagation();const re=V.navTarget??Di(V.lastX,V.lastY);if(!re)return;if(O.key==="Enter"){const J=re.getBoundingClientRect();Promise.resolve(e.onSelect({element:re,rect:J})).catch(fe=>{be.warn(ve.Picker,"SELECT_FAIL","select handler threw",fe)});return}const te=Nx(re,O.key);te&&(V.navTarget=te,Ex(te))},Z=O=>{O.key==="Alt"&&V&&V.altDown&&(V.altDown=!1,Oi(V.lastX,V.lastY))};window.addEventListener("mousemove",L,!0),window.addEventListener("mouseover",L,!0),window.addEventListener("contextmenu",M,!0),window.addEventListener("click",ie,!0),window.addEventListener("keydown",Q,!0),window.addEventListener("keyup",Z,!0),V={host:t,shadow:n,box:o,marginBox:i,paddingBox:a,size:l,chip:s,chipBtnSelect:y,chipBtnCopy:x,chipBtnCancel:w,chipFlash:h,chipHover:!1,currentTarget:null,badges:f,mBadges:v,tip:C,guides:d,gBadges:S,altDown:!1,lastX:-1,lastY:-1,navTarget:null,prevCursor:A,rafScheduled:!1,pendingEvent:null,cleanup:()=>{window.removeEventListener("mousemove",L,!0),window.removeEventListener("mouseover",L,!0),window.removeEventListener("contextmenu",M,!0),window.removeEventListener("click",ie,!0),window.removeEventListener("keydown",Q,!0),window.removeEventListener("keyup",Z,!0),s.removeEventListener("pointerenter",F),s.removeEventListener("pointerleave",B)}},be.info(ve.Picker,"Picker active")}function Li(){V&&(V.cleanup(),document.body&&(document.body.style.cursor=V.prevCursor),V.host.remove(),V=null,be.info(ve.Picker,"Picker exited"))}function Di(e,t){if(!V)return null;const n=V.host.style.display;V.host.style.display="none";const r=document.elementFromPoint(e,t);return V.host.style.display=n,!r||r===V.host||r.closest("#inspect-page-panel-host")?null:r}function Oi(e,t){if(!V)return;V.lastX=e,V.lastY=t;const n=V.navTarget??Di(e,t);if(!n){Cd();return}const r=n.getBoundingClientRect();if(r.width===0&&r.height===0){Cd();return}V.currentTarget=n,V.box.style.left=`${r.left}px`,V.box.style.top=`${r.top}px`,V.box.style.width=`${r.width}px`,V.box.style.height=`${r.height}px`,V.box.style.display="block";let o=null;try{o=getComputedStyle(n)}catch{o=null}const i=C=>{const A=parseFloat(C??"0");return Number.isFinite(A)?A:0},a=i(o?.marginTop),l=i(o?.marginRight),s=i(o?.marginBottom),u=i(o?.marginLeft),y=i(o?.paddingTop),x=i(o?.paddingRight),w=i(o?.paddingBottom),h=i(o?.paddingLeft);a||l||s||u?(V.marginBox.style.left=`${r.left-u}px`,V.marginBox.style.top=`${r.top-a}px`,V.marginBox.style.width=`${r.width+u+l}px`,V.marginBox.style.height=`${r.height+a+s}px`,V.marginBox.style.display="block"):V.marginBox.style.display="none",y||x||w||h?(V.paddingBox.style.left=`${r.left+h}px`,V.paddingBox.style.top=`${r.top+y}px`,V.paddingBox.style.width=`${Math.max(0,r.width-h-x)}px`,V.paddingBox.style.height=`${Math.max(0,r.height-y-w)}px`,V.paddingBox.style.display="block"):V.paddingBox.style.display="none",yn(V.badges[0],y,r.left+r.width/2,r.top+2),yn(V.badges[1],x,r.right-2,r.top+r.height/2),yn(V.badges[2],w,r.left+r.width/2,r.bottom-2),yn(V.badges[3],h,r.left+2,r.top+r.height/2),yn(V.mBadges[0],a,r.left+r.width/2,r.top-a/2),yn(V.mBadges[1],l,r.right+l/2,r.top+r.height/2),yn(V.mBadges[2],s,r.left+r.width/2,r.bottom+s/2),yn(V.mBadges[3],u,r.left-u/2,r.top+r.height/2),V.size.textContent=`${Math.round(r.width)} × ${Math.round(r.height)}`,V.chip.style.display="inline-flex";const b=V.chip.offsetWidth||120,f=V.chip.offsetHeight||28;let v=Math.min(window.innerWidth-b-4,Math.max(4,r.right-b)),p=r.bottom+6;p+f>window.innerHeight&&(p=Math.max(4,r.top-f-6)),p>r.top&&p<r.bottom&&(p=r.bottom+6),V.chip.style.left=`${v}px`,V.chip.style.top=`${p}px`,V.tip.innerHTML=Tx(n),V.tip.style.display="block";const d=V.tip.getBoundingClientRect();let g=e+12,S=t+12;if(g+d.width>window.innerWidth&&(g=e-12-d.width),S+d.height>window.innerHeight&&(S=t-12-d.height),V.tip.style.left=`${Math.max(0,g)}px`,V.tip.style.top=`${Math.max(0,S)}px`,V.altDown){const C=window.innerWidth,A=window.innerHeight,T=r.left+r.width/2,R=r.top+r.height/2;Mi(V.guides[0],"v",T,0,r.top),Bi(V.gBadges[0],Math.round(r.top),T+6,r.top/2),Mi(V.guides[1],"h",r.right,R,C-r.right),Bi(V.gBadges[1],Math.round(C-r.right),(r.right+C)/2,R-14),Mi(V.guides[2],"v",T,r.bottom,A-r.bottom),Bi(V.gBadges[2],Math.round(A-r.bottom),T+6,(r.bottom+A)/2),Mi(V.guides[3],"h",0,R,r.left),Bi(V.gBadges[3],Math.round(r.left),r.left/2,R-14)}else{for(const C of V.guides)C.style.display="none";for(const C of V.gBadges)C.style.display="none"}}function Cd(){if(V){V.box.style.display="none",V.tip.style.display="none",V.marginBox.style.display="none",V.paddingBox.style.display="none",V.chip.style.display="none",V.currentTarget=null;for(const e of V.badges)e.style.display="none";for(const e of V.mBadges)e.style.display="none";for(const e of V.guides)e.style.display="none";for(const e of V.gBadges)e.style.display="none"}}function Mi(e,t,n,r,o,i){if(o<1){e.style.display="none";return}e.style.display="block",t==="v"?(e.style.left=`${Math.round(n)}px`,e.style.top=`${Math.round(r)}px`,e.style.height=`${Math.round(o)}px`,e.style.width="1px"):(e.style.left=`${Math.round(n)}px`,e.style.top=`${Math.round(r)}px`,e.style.width=`${Math.round(o)}px`,e.style.height="1px")}function Bi(e,t,n,r){if(t<1){e.style.display="none";return}e.textContent=`${t}px`,e.style.display="block";const o=e.getBoundingClientRect();e.style.left=`${Math.max(0,Math.round(n-o.width/2))}px`,e.style.top=`${Math.max(0,Math.round(r-o.height/2))}px`}function Ex(e){if(!V)return;const t=e.getBoundingClientRect();Oi(t.left+Math.min(40,t.width/2),t.top+Math.min(20,t.height/2))}function Nx(e,t){if(t==="ArrowUp"){const n=e.parentElement;return!n||n===document.documentElement?null:n}return t==="ArrowDown"?e.firstElementChild??null:t==="ArrowLeft"?e.previousElementSibling??null:e.nextElementSibling??null}function yn(e,t,n,r,o){if(!t||t<1){e.style.display="none";return}e.textContent=`${Math.round(t)}px`,e.style.display="block";const i=e.getBoundingClientRect();e.style.left=`${Math.max(0,n-i.width/2)}px`,e.style.top=`${Math.max(0,r-i.height/2)}px`}function ys(e){const t=(e||"").trim();if(!t||t==="transparent"||t==="rgba(0, 0, 0, 0)")return"transparent";if(t.startsWith("#"))return t.length===4?`#${t[1]}${t[1]}${t[2]}${t[2]}${t[3]}${t[3]}`.toUpperCase():t.toUpperCase();const n=/rgba?\(\s*(\d+)\s*[, ]\s*(\d+)\s*[, ]\s*(\d+)(?:\s*[,/ ]\s*([\d.]+))?\s*\)/i.exec(t);if(!n)return t;const r=(+n[1]).toString(16).padStart(2,"0"),o=(+n[2]).toString(16).padStart(2,"0"),i=(+n[3]).toString(16).padStart(2,"0"),a=n[4]!==void 0?Math.round(parseFloat(n[4])*255):255;if(a===0)return"transparent";const l=a<255?a.toString(16).padStart(2,"0"):"";return`#${r}${o}${i}${l}`.toUpperCase()}function jx(e){let t=e;for(;t;){let n=null;try{n=getComputedStyle(t)}catch{n=null}const r=ys(n?.backgroundColor??"");if(r!=="transparent")return r.length===9?r.slice(0,7):r;t=t.parentElement}return"#FFFFFF"}function Fx(e){return(e.split(",")[0]?.trim().replace(/^["']|["']$/g,"")??"")||e}function Tx(e){const t=e.tagName.toLowerCase(),n=e.id?`#${ut(e.id)}`:"",r=Array.from(e.classList).slice(0,2).map(F=>`.${ut(F)}`).join(""),o=`${t}${n}${r}`.slice(0,_s+32),i=e.getBoundingClientRect(),a=`${Math.round(i.width)} × ${Math.round(i.height)}`;let l=null;try{l=getComputedStyle(e)}catch{l=null}const s=ys(l?.color??""),u=ys(l?.backgroundColor??""),y=u==="transparent"?jx(e):u.length===9?u.slice(0,7):u,x=Fx(l?.fontFamily??""),w=l?.fontSize??"",h=l?.lineHeight??"",b=h==="normal"?"normal":h,f=l?.fontWeight??"",v=l?`${l.paddingTop} ${l.paddingRight} ${l.paddingBottom} ${l.paddingLeft}`:"",p=parseFloat(w)||0,d=parseInt(f,10)||400,g=s==="transparent"?"#000000":s.length===9?s.slice(0,7):s,S=ds(g,y),C=fs(S),A=hs(p,d),T=A?C.largeAA:C.normalAA,R=C.label==="Excellent"||C.label==="Good"?"ok":C.label==="Poor"?"warn":"bad",L=F=>F==="transparent"?'<span class="lpe-pk-sw" title="transparent"></span>':`<span class="lpe-pk-sw lpe-pk-sw-fill" style="background:${F.length===9?`#${F.slice(1,7)}`:F}"></span>`,M=(F,B)=>`<div class="lpe-pk-k">${ut(F)}</div><div class="lpe-pk-v">${B}</div>`,ie=[M("Text color",`${L(s)}${ut(s)}`),M("Background",`${L(y)}${ut(y)}`),M("Font family",ut(x)),M("Font size",ut(w)),M("Line height",ut(String(b))),M("Font weight",ut(f)),M("Padding",ut(v)),M("Contrast",`<span>${S.toFixed(2)}</span><span class="lpe-pk-pill ${R}" title="${A?"Large text":"Normal text"} · ${T?"Passes":"Fails"} WCAG AA">${ut(C.label)}</span>`)].join("");return`<div class="lpe-pk-head">${ut(o)}</div><div class="lpe-pk-sub">${ut(a)}</div><div class="lpe-pk-rows">${ie}</div>`}function ut(e){return e.replace(/[&<>"']/g,t=>t==="&"?"&amp;":t==="<"?"&lt;":t===">"?"&gt;":t==='"'?"&quot;":"&#39;")}function Ax(e){const t=e.tagName.toLowerCase(),n=e.id?`#${e.id}`:"",r=Array.from(e.classList).slice(0,3).map(o=>`.${o}`).join("");return`${t}${n}${r}`.slice(0,_s)}function Px(e){const t=e.tagName.toLowerCase();if(e.id)return`${t}#${e.id}`;const n=typeof e.className=="string"?e.className.trim().split(/\s+/).filter(Boolean).slice(0,2).join("."):"";return n?`${t}.${n}`:t}function Ed(e,t=e.ownerDocument){const n=[];let r=e,o=!1;for(;r&&r.nodeType===1&&r!==t.documentElement;){if(n.length>=Ud){o=!0;break}if(n.push(Ix(r,t)),r.id&&t.querySelectorAll(`#${Nd(r.id)}`).length===1)break;r=r.parentElement}return r===t.documentElement&&n.push("html"),n.reverse(),o?`… > ${n.join(" > ")}`:n.join(" > ")}function Ix(e,t){const n=e.tagName.toLowerCase();if(e.id&&t.querySelectorAll(`#${Nd(e.id)}`).length===1)return`${n}#${e.id}`;const r=e.parentElement?Array.from(e.parentElement.children).filter(o=>o.tagName===e.tagName):[];if(r.length>1){const o=r.indexOf(e)+1;return`${n}:nth-of-type(${o})`}return n}function Nd(e){const t=globalThis.CSS;return t?.escape?t.escape(e):e.replace(/[^a-zA-Z0-9_-]/g,n=>`\\${n}`)}async function jd(e,t){if(!t.include)return{css:""};const n=[];let r=!1;const o=Array.from(document.styleSheets);for(let i=0;i<o.length;i++){const a=o[i],l=a.href??`inline #${i+1}`;let s=null;try{s=Array.from(a.cssRules)}catch{if(a.href)try{const u=await(await fetch(a.href,{credentials:"omit"})).text();s=await zx(u)}catch(u){be.warn(ve.Element,ke.W_CSS_PARSE_FAILED,a.href,u);continue}else continue}s&&Fd(s,e,l,n,()=>{r=!0})}return r&&be.warn(ve.Element,ke.W_AT_RULE_SKIPPED,"ignored @supports/@layer/@container"),{css:n.join(`

`)}}function Fd(e,t,n,r,o){for(const i of e)if(i instanceof CSSStyleRule)try{t.matches(i.selectorText)&&r.push(`/* from: <${n}> */
${i.cssText}`)}catch(a){be.warn(ve.Element,ke.W_SELECTOR_INVALID,i.selectorText,a)}else i instanceof CSSMediaRule?window.matchMedia(i.conditionText).matches&&Fd(Array.from(i.cssRules),t,n,r,o):o()}async function zx(e){const t=document.implementation.createHTMLDocument("parse-css"),n=t.createElement("style");n.textContent=e,t.head.appendChild(n);const r=n.sheet;if(!r)return[];try{return Array.from(r.cssRules)}catch{return[]}}function Td(e,t){if(!t.include)return{};if(!document.body)return{};const n=document.createElement("iframe");n.style.cssText="position:absolute;left:-99999px;top:0;width:0;height:0;border:0",document.body.appendChild(n);try{const r=n.contentDocument;if(!r?.body)return{};const o=r.createElement(e.tagName.toLowerCase());r.body.appendChild(o);const i=(n.contentWindow??window).getComputedStyle(o),a=window.getComputedStyle(e),l={};for(let s=0;s<a.length;s++){const u=a[s],y=a.getPropertyValue(u),x=i.getPropertyValue(u);y!==x&&(l[u]=y)}return l}finally{n.remove()}}const Rx=Object.freeze(Object.defineProperty({__proto__:null,computedDiff:Td},Symbol.toStringTag,{value:"Module"}));function Lx(e){return["<!DOCTYPE html>",`<html><head><meta charset="utf-8"><base href="${Dx(e.baseHref)}">`,`<style>${e.matchedCss}</style>`,`</head><body style="margin:0;background:transparent">${e.outerHtml}</body></html>`].join("")}function Dx(e){return e.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;")}function Ox(e){return e.replace(/<input\b([^>]*\btype\s*=\s*["']password["'][^>]*)>/gi,(t,n)=>{const r=n.replace(/\bvalue\s*=\s*("[^"]*"|'[^']*')/gi,'value=""');return`<input${/\bdata-redacted\s*=/.test(r)?r:`${r} data-redacted="true"`}>`})}async function Mx(e,t,n,r){const o={x:n.x,y:n.y,width:n.width,height:n.height};if(o.width===0||o.height===0)throw new He(ke.E_ELEMENT_ZERO_SIZE,"Element has zero size");const i=Ed(t),a=r.expandShadowRoots!==!1;let l;a?l=_d(t,{redactPasswordFields:r.redactPasswordFields,expandShadowRoots:!0}):(l=t.outerHTML,r.redactPasswordFields&&(l=Ox(l)));const s=await jd(t,{include:r.includeMatchedRules}),u=Td(t,{include:r.includeComputedStyles}),y=Lx({baseHref:location.href,matchedCss:s.css,outerHtml:l});return{tabId:e,selectorPath:i,rect:o,outerHtml:l,matchedCss:s.css,computedDiff:u,isolatedHtml:y,pageInfo:{url:location.href,title:document.title,viewportCssPx:{w:window.innerWidth,h:window.innerHeight},dpr:window.devicePixelRatio||1}}}const Bx=new Set(["display","position","top","right","bottom","left","inset","float","clear","z-index","box-sizing","width","height","min-width","min-height","max-width","max-height","margin","margin-top","margin-right","margin-bottom","margin-left","padding","padding-top","padding-right","padding-bottom","padding-left","flex","flex-direction","flex-wrap","flex-grow","flex-shrink","flex-basis","justify-content","align-items","align-content","align-self","gap","row-gap","column-gap","grid","grid-template-columns","grid-template-rows","grid-area","grid-column","grid-row","place-items","place-content","overflow","overflow-x","overflow-y","visibility","order"]),$x=new Set(["font","font-family","font-size","font-weight","font-style","font-variant","line-height","letter-spacing","word-spacing","text-align","text-decoration","text-transform","text-indent","text-overflow","white-space","word-break","color","vertical-align"]),Ux=new Set(["background","background-color","background-image","background-size","background-position","background-repeat","background-clip","background-origin","background-attachment"]),Hx=new Set(["border","border-top","border-right","border-bottom","border-left","border-color","border-style","border-width","border-top-color","border-top-style","border-top-width","border-right-color","border-right-style","border-right-width","border-bottom-color","border-bottom-style","border-bottom-width","border-left-color","border-left-style","border-left-width","border-radius","border-top-left-radius","border-top-right-radius","border-bottom-left-radius","border-bottom-right-radius","outline","outline-color","outline-style","outline-width","outline-offset"]),Wx=new Set(["opacity","box-shadow","filter","backdrop-filter","transform","transform-origin","transition","animation","mix-blend-mode","isolation","will-change"]);function rt(e){const t=parseFloat(e??"");return Number.isFinite(t)?t:0}function Ad(e){const t=(e||"").trim();if(!t||t==="transparent"||t==="rgba(0, 0, 0, 0)")return"#00000000";if(t.startsWith("#"))return t.length===4?`#${t[1]}${t[1]}${t[2]}${t[2]}${t[3]}${t[3]}`.toLowerCase():t.toLowerCase();const n=/rgba?\(\s*(\d+)\s*[, ]\s*(\d+)\s*[, ]\s*(\d+)(?:\s*[,/ ]\s*([\d.]+))?\s*\)/i.exec(t);if(!n)return"#000000";const r=(+n[1]).toString(16).padStart(2,"0"),o=(+n[2]).toString(16).padStart(2,"0"),i=(+n[3]).toString(16).padStart(2,"0"),a=n[4]!==void 0?Math.round(parseFloat(n[4])*255):255,l=a<255?a.toString(16).padStart(2,"0"):"";return`#${r}${o}${i}${l}`.toLowerCase()}function Vx(e){let t=e;for(;t;){const n=getComputedStyle(t),r=Ad(n.backgroundColor);if(!r.endsWith("00"))return r.length===9?r.slice(0,7):r;t=t.parentElement}return"#ffffff"}function Gx(e,t){return t?t.charAt(0).toUpperCase()+t.slice(1):{a:"Link",button:"Button",input:"Input",textarea:"Textarea",select:"Select",img:"Image",svg:"SVG",h1:"Heading 1",h2:"Heading 2",h3:"Heading 3",h4:"Heading 4",h5:"Heading 5",h6:"Heading 6",p:"Paragraph",ul:"List",ol:"Ordered list",li:"List item",nav:"Navigation",header:"Header",footer:"Footer",main:"Main",section:"Section",article:"Article",aside:"Aside",form:"Form",label:"Label",div:"Container",span:"Text"}[e]??e.charAt(0).toUpperCase()+e.slice(1)}function Zx(e,t){const n=t.slice(0,1).map(r=>`.${r}`).join("");return`${e}${n}`}function Yx(e){const t={layout:{},typography:{},background:{},border:{},effects:{},other:{}};for(const[n,r]of Object.entries(e))Bx.has(n)?t.layout[n]=r:$x.has(n)?t.typography[n]=r:Ux.has(n)?t.background[n]=r:Hx.has(n)?t.border[n]=r:Wx.has(n)?t.effects[n]=r:t.other[n]=r;return t}function Qx(e){const t={base:[],hover:[],focus:[],active:[],disabled:[]},n=e.split(/\n(?=\/\* from:)/g);for(const r of n){if(!r.trim())continue;const o=r.split("{",1)[0]??"";/:hover\b/.test(o)?t.hover.push(r):/:focus(-visible|-within)?\b/.test(o)?t.focus.push(r):/:active\b/.test(o)?t.active.push(r):/:disabled\b/.test(o)?t.disabled.push(r):t.base.push(r)}return{base:t.base.join(`

`),hover:t.hover.join(`

`),focus:t.focus.join(`

`),active:t.active.join(`

`),disabled:t.disabled.join(`

`)}}async function Xx(e,t={}){const n=getComputedStyle(e),r=e.getBoundingClientRect(),o=e.tagName.toLowerCase(),i=e.id||null,a=Array.from(e.classList),l=e.getAttribute("role"),s={top:rt(n.marginTop),right:rt(n.marginRight),bottom:rt(n.marginBottom),left:rt(n.marginLeft)},u={top:rt(n.borderTopWidth),right:rt(n.borderRightWidth),bottom:rt(n.borderBottomWidth),left:rt(n.borderLeftWidth)},y={top:rt(n.paddingTop),right:rt(n.paddingRight),bottom:rt(n.paddingBottom),left:rt(n.paddingLeft)},x={w:Math.max(0,r.width-y.left-y.right-u.left-u.right),h:Math.max(0,r.height-y.top-y.bottom-u.top-u.bottom)},w=Ad(n.color),h=Vx(e),b=rt(n.fontSize),f=n.lineHeight,v=f==="normal"?null:rt(f),p=parseInt(n.fontWeight,10)||400,d=ds(w,h),g=hs(b,p),S=t.includeMatchedRules!==!1,C=t.includeComputedStyles!==!1;let A={base:"",hover:"",focus:"",active:"",disabled:""};if(S){const R=await jd(e,{include:!0});A=Qx(R.css)}let T={layout:{},typography:{},background:{},border:{},effects:{},other:{}};if(C){const{computedDiff:R}=await Promise.resolve().then(()=>Rx);T=Yx(R(e,{include:!0}))}return{identity:{tag:o,id:i,classList:a,role:l,selectorPath:Ed(e),label:Gx(o,l),selectorChip:Zx(o,a)},box:{rect:{x:r.x,y:r.y,w:r.width,h:r.height},margin:s,border:u,padding:y,content:x},text:{fontFamily:n.fontFamily,fontSizePx:b,lineHeightPx:v,fontWeight:p,letterSpacing:n.letterSpacing,color:w},selection:{fg:w,bg:h,contrast:{ratio:d,verdict:fs(d),isLarge:g}},matched:A,groupedDiff:T}}const Kx=6e3,Jx=400,qx=200,e0=new Set(["H1","H2","H3","H4","H5","H6"]);function bn(e){if(!e)return null;const t=e.trim().toLowerCase();if(!t||t==="transparent"||t==="none"||t==="currentcolor")return null;const n=t.match(/^rgba?\(\s*([\d.]+)[\s,]+([\d.]+)[\s,]+([\d.]+)(?:[\s,/]+([\d.]+%?))?\s*\)$/);if(n){const r=bs(Number(n[1])),o=bs(Number(n[2])),i=bs(Number(n[3])),a=n[4]===void 0?1:t0(n[4]);return a>=.999?`#${Rn(r)}${Rn(o)}${Rn(i)}`:a<=.001?null:`#${Rn(r)}${Rn(o)}${Rn(i)}${Rn(Math.round(a*255))}`}return/^#([0-9a-f]{3,8})$/.test(t)?n0(t):null}function bs(e){return Math.max(0,Math.min(255,Math.round(e)))}function Rn(e){return e.toString(16).padStart(2,"0")}function t0(e){return e.endsWith("%")?Number(e.slice(0,-1))/100:Number(e)}function n0(e){const t=e.slice(1);return t.length===3?`#${t[0]}${t[0]}${t[1]}${t[1]}${t[2]}${t[2]}`:t.length===4?`#${t[0]}${t[0]}${t[1]}${t[1]}${t[2]}${t[2]}${t[3]}${t[3]}`:`#${t}`}function r0(e){const t=e.toLowerCase();return t.includes("monospace")?"monospace":t.includes("system-ui")||t.includes("-apple-system")?"system-ui":t.includes("serif")&&!t.includes("sans-serif")?"serif":t.includes("sans-serif")?"sans-serif":t.includes("cursive")?"cursive":t.includes("fantasy")?"fantasy":"unknown"}function Pd(e){return(e.split(",")[0]?.trim()??"").replace(/^['"]|['"]$/g,"")}function Id(e){const t=e.tagName.toLowerCase();if(e.id)return`${t}#${e.id}`;const n=e.className&&typeof e.className=="string"?e.className.trim().split(/\s+/).slice(0,2).join("."):"";return n?`${t}.${n}`:t}function o0(e={}){const t=e.doc??globalThis.document,n=e.win??globalThis.window;if(!t||!n)throw new Error("collectSnapshot: no document/window available");const r={url:t.location?.href??"",title:t.title??"",origin:t.location?.origin??"",viewport:{w:n.innerWidth??0,h:n.innerHeight??0},documentSize:{w:t.documentElement?.scrollWidth??0,h:t.documentElement?.scrollHeight??0}},o=[];if(t.body)for(const f of Array.from(t.body.children))vs(f,n)&&o.push(f);if(t.documentElement)for(const f of Array.from(t.documentElement.children))f!==t.body&&vs(f,n)&&o.push(f);const i=f=>{for(const v of o)if(v===f||v.contains(f))return!0;return!1},a=Array.from(t.querySelectorAll("*")).filter(f=>!i(f)).slice(0,Kx),l=new Map,s=new Map,u=[],y=[],x=(f,v)=>{if(!f)return;const p=f.length===9,d=`${v}::${f}`,g=l.get(d);g?g.count++:l.set(d,{cat:v,count:1,transparent:p})};for(const f of a){const v=n.getComputedStyle(f);x(bn(v.color),"text"),x(bn(v.backgroundColor),"background"),v.borderTopWidth!=="0px"&&x(bn(v.borderTopColor),"border"),f instanceof SVGElement&&(x(bn(v.fill),"fill"),x(bn(v.stroke),"stroke"));const p=v.backgroundImage;if(p&&p.includes("gradient(")){const g=`gradient::${p}`,S=l.get(g);S?S.count++:l.set(g,{cat:"gradient",count:1,transparent:!1})}const d=v.fontFamily;if(d){const g=e0.has(f.tagName),S=Pd(d),C=g?"heading":"body",A=`${C}::${S}`;let T=s.get(A);T||(T={stack:d,group:C,weights:new Set,sizes:new Set,count:0},s.set(A,T));const R=Number(v.fontWeight)||400,L=Math.round(parseFloat(v.fontSize)||0);T.weights.add(R),L>0&&T.sizes.add(L),T.count++}if(u.length<Jx){const g=f.getBoundingClientRect();u.push({selector:Id(f),tagName:f.tagName.toLowerCase(),classList:Array.from(f.classList).slice(0,6),rect:{x:Math.round(g.x),y:Math.round(g.y),w:Math.round(g.width),h:Math.round(g.height)},styles:{display:v.display,position:v.position,color:v.color,backgroundColor:v.backgroundColor,fontFamily:v.fontFamily,fontSize:v.fontSize,fontWeight:v.fontWeight,lineHeight:v.lineHeight,margin:v.margin,padding:v.padding,border:v.border}})}y.length<qx&&i0(f)&&y.push({selector:Id(f),text:a0(f).slice(0,80),fontFamily:v.fontFamily,fontSizePx:Math.round(parseFloat(v.fontSize)||0),fontWeight:Number(v.fontWeight)||400,color:bn(v.color)??v.color,backgroundColor:bn(v.backgroundColor)??v.backgroundColor})}const w=Array.from(s.values()).map(f=>({family:Pd(f.stack),stack:f.stack,generic:r0(f.stack),weights:Array.from(f.weights).sort((v,p)=>v-p),sizesPx:Array.from(f.sizes).sort((v,p)=>v-p),group:f.group,sampleCount:f.count})).sort((f,v)=>v.sampleCount-f.sampleCount),h=Array.from(l.entries()).map(([f,v])=>({value:f.slice(f.indexOf("::")+2),category:v.cat,instances:v.count,transparent:v.transparent})).sort((f,v)=>v.instances-f.instances),b=l0(t);return{pageInfo:r,fonts:w,colors:h,cssStats:b,computedSamples:u,textNodes:y,collectedAt:Date.now()}}function i0(e){for(const t of Array.from(e.childNodes))if(t.nodeType===3&&(t.textContent??"").trim().length>0)return!0;return!1}function a0(e){let t="";for(const n of Array.from(e.childNodes))n.nodeType===3&&(t+=n.textContent??"");return t.trim()}function l0(e){let t=0,n=0,r=0,o=0,i=0;for(const a of Array.from(e.styleSheets))try{const l=a.cssRules;t+=l.length;for(const s of Array.from(l))n+=s.cssText?.length??0;a.href&&i++}catch{o++,a.href&&i++}return r=e.querySelectorAll("style").length,{ruleCount:t,cssBytes:n,inlineStyleTagCount:r,unreachableSheetCount:o,externalSheetCount:i}}const s0=8e3,zd="lpe-locate-style",ws="lpe-locate-ring",Rd=1500,c0=["background-color","color","border-top-color","border-right-color","border-bottom-color","border-left-color","outline-color","fill","stroke"];function u0(e,t=document){const n=(e||"").toLowerCase();if(!n)return[];const r=[],o=t.querySelectorAll("*"),i=Math.min(o.length,s0);for(let a=0;a<i;a++){const l=o[a],s=getComputedStyle(l);for(const u of c0){const y=bn(s.getPropertyValue(u));if(y&&y===n){r.push(l);break}}}return r}function p0(e){if(e.length===0)return;f0();const t=e[0];try{t.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{}for(const n of e)n.classList.add(ws);window.setTimeout(()=>{for(const n of e)n.classList.remove(ws)},Rd)}function d0(e){const t=u0(e);return p0(t),{count:t.length}}function f0(){if(document.getElementById(zd))return;const e=document.createElement("style");e.id=zd,e.textContent=`
.${ws} {
  outline: 2px solid #ff5b1f !important;
  outline-offset: 2px !important;
  box-shadow: 0 0 0 2px rgba(255, 91, 31, 0.35), 0 0 16px 4px rgba(255, 91, 31, 0.55) !important;
  animation: lpe-locate-pulse ${Rd}ms ease-out 1;
}
@keyframes lpe-locate-pulse {
  0%   { outline-color: #ff5b1f; box-shadow: 0 0 0 0 rgba(255, 91, 31, 0.7), 0 0 18px 4px rgba(255, 91, 31, 0.6); }
  60%  { outline-color: #ff5b1f; box-shadow: 0 0 0 6px rgba(255, 91, 31, 0.0), 0 0 18px 4px rgba(255, 91, 31, 0.5); }
  100% { outline-color: #ff5b1f; box-shadow: 0 0 0 0 rgba(255, 91, 31, 0.0), 0 0 0 0 rgba(255, 91, 31, 0.0); }
}
`.trim(),document.documentElement.appendChild(e)}be.debug(ve.Lifecycle,"Content script loaded");const Ld="inspect-page:status";function ks(e){try{window.dispatchEvent(new CustomEvent(Ld,{detail:e}))}catch{}}const It=new Yd;return It.on(xe.Ping,e=>(be.debug(ve.Messaging,`CS Ping rtt=${Date.now()-e.sentAtMs}ms`),{extensionVersion:"2.7.0",receivedAtMs:Date.now()})),It.on(xe.MountFloatingPanel,()=>{ex()}),It.on(xe.CollectPageArtifacts,async()=>{let e;try{e=await Me(xe.GetSettings,{})}catch(t){be.warn(ve.Settings,"GET_FAIL","falling back to defaults",t),e={redactPasswordFields:!0}}return mx({redactPasswordFields:e.redactPasswordFields,extensionVersion:"2.7.0"})}),It.on(xe.BeginScrollCapture,e=>wx(e)),It.on(xe.CollectInspectSnapshot,()=>({snapshot:o0()})),It.on(xe.LocateColor,({target:e})=>d0(e)),It.on(xe.RestoreAfterCapture,()=>{kx()}),It.on(xe.EnterPickerMode,()=>{Cx({onSelect:async({element:e,rect:t})=>{be.info(ve.Picker,`Picked ${Ax(e)}`),Li();try{const n=await Me(xe.GetSettings,{}),r=await Mx(-1,e,t,{redactPasswordFields:n.redactPasswordFields,includeComputedStyles:n.includeComputedStyles,includeMatchedRules:n.includeMatchedRules}),o={status:de.Selecting,message:r.selectorPath,debugPreview:{selectorPath:r.selectorPath,html:r.outerHtml,css:r.matchedCss,js:JSON.stringify(r.computedDiff,null,2)}};try{o.elementSnapshot=await Xx(e,{includeMatchedRules:n.includeMatchedRules,includeComputedStyles:n.includeComputedStyles})}catch(i){be.warn(ve.Element,"SNAPSHOT_FAIL","element snapshot failed",i)}ks(o);try{await chrome.runtime.sendMessage({kind:xe.StatusUpdate,requestId:`cs_dbg_${Date.now()}`,payload:o})}catch{}await Me(xe.RunElementExport,r)}catch(n){be.error(ve.Element,"EXPORT_FAIL","element export failed",n);const r=n instanceof He?n:null,o=r?.message??(n instanceof Error?n.message:String(n)),i=r?.detail??(n instanceof Error?n.stack:void 0),a=r?.code??ke.E_PERMISSION_DENIED,l={status:de.Error,message:o,errorCode:a,errorDetail:i};ks(l);try{await chrome.runtime.sendMessage({kind:xe.StatusUpdate,requestId:`cs_err_${Date.now()}`,payload:l})}catch{}}},onCancel:()=>{be.info(ve.Picker,"Picker cancelled"),ks({status:de.Idle}),chrome.runtime.sendMessage({kind:xe.StatusUpdate,requestId:`cs_cancel_${Date.now()}`,payload:{status:de.Idle}}).catch(()=>{})}})}),It.on(xe.ExitPickerMode,()=>{Li()}),It.attach(),Hi.LPE_STATUS_EVENT=Ld,Object.defineProperty(Hi,Symbol.toStringTag,{value:"Module"}),Hi}({});
